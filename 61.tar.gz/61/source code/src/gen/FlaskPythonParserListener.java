package gen;
// Generated from /tmp/tmp.SdsHqkGNgv/FlaskPythonParser.g4 by ANTLR 4.13.2
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link FlaskPythonParser}.
 */
public interface FlaskPythonParserListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by the {@code programRoot}
	 * labeled alternative in {@link FlaskPythonParser#program}.
	 * @param ctx the parse tree
	 */
	void enterProgramRoot(FlaskPythonParser.ProgramRootContext ctx);
	/**
	 * Exit a parse tree produced by the {@code programRoot}
	 * labeled alternative in {@link FlaskPythonParser#program}.
	 * @param ctx the parse tree
	 */
	void exitProgramRoot(FlaskPythonParser.ProgramRootContext ctx);
	/**
	 * Enter a parse tree produced by the {@code importItem}
	 * labeled alternative in {@link FlaskPythonParser#programItem}.
	 * @param ctx the parse tree
	 */
	void enterImportItem(FlaskPythonParser.ImportItemContext ctx);
	/**
	 * Exit a parse tree produced by the {@code importItem}
	 * labeled alternative in {@link FlaskPythonParser#programItem}.
	 * @param ctx the parse tree
	 */
	void exitImportItem(FlaskPythonParser.ImportItemContext ctx);
	/**
	 * Enter a parse tree produced by the {@code declarationItem}
	 * labeled alternative in {@link FlaskPythonParser#programItem}.
	 * @param ctx the parse tree
	 */
	void enterDeclarationItem(FlaskPythonParser.DeclarationItemContext ctx);
	/**
	 * Exit a parse tree produced by the {@code declarationItem}
	 * labeled alternative in {@link FlaskPythonParser#programItem}.
	 * @param ctx the parse tree
	 */
	void exitDeclarationItem(FlaskPythonParser.DeclarationItemContext ctx);
	/**
	 * Enter a parse tree produced by the {@code functionItem}
	 * labeled alternative in {@link FlaskPythonParser#programItem}.
	 * @param ctx the parse tree
	 */
	void enterFunctionItem(FlaskPythonParser.FunctionItemContext ctx);
	/**
	 * Exit a parse tree produced by the {@code functionItem}
	 * labeled alternative in {@link FlaskPythonParser#programItem}.
	 * @param ctx the parse tree
	 */
	void exitFunctionItem(FlaskPythonParser.FunctionItemContext ctx);
	/**
	 * Enter a parse tree produced by the {@code statementItem}
	 * labeled alternative in {@link FlaskPythonParser#programItem}.
	 * @param ctx the parse tree
	 */
	void enterStatementItem(FlaskPythonParser.StatementItemContext ctx);
	/**
	 * Exit a parse tree produced by the {@code statementItem}
	 * labeled alternative in {@link FlaskPythonParser#programItem}.
	 * @param ctx the parse tree
	 */
	void exitStatementItem(FlaskPythonParser.StatementItemContext ctx);
	/**
	 * Enter a parse tree produced by the {@code newlineItem}
	 * labeled alternative in {@link FlaskPythonParser#programItem}.
	 * @param ctx the parse tree
	 */
	void enterNewlineItem(FlaskPythonParser.NewlineItemContext ctx);
	/**
	 * Exit a parse tree produced by the {@code newlineItem}
	 * labeled alternative in {@link FlaskPythonParser#programItem}.
	 * @param ctx the parse tree
	 */
	void exitNewlineItem(FlaskPythonParser.NewlineItemContext ctx);
	/**
	 * Enter a parse tree produced by the {@code importModule}
	 * labeled alternative in {@link FlaskPythonParser#importStatement}.
	 * @param ctx the parse tree
	 */
	void enterImportModule(FlaskPythonParser.ImportModuleContext ctx);
	/**
	 * Exit a parse tree produced by the {@code importModule}
	 * labeled alternative in {@link FlaskPythonParser#importStatement}.
	 * @param ctx the parse tree
	 */
	void exitImportModule(FlaskPythonParser.ImportModuleContext ctx);
	/**
	 * Enter a parse tree produced by the {@code fromImport}
	 * labeled alternative in {@link FlaskPythonParser#importStatement}.
	 * @param ctx the parse tree
	 */
	void enterFromImport(FlaskPythonParser.FromImportContext ctx);
	/**
	 * Exit a parse tree produced by the {@code fromImport}
	 * labeled alternative in {@link FlaskPythonParser#importStatement}.
	 * @param ctx the parse tree
	 */
	void exitFromImport(FlaskPythonParser.FromImportContext ctx);
	/**
	 * Enter a parse tree produced by the {@code declarationStmt}
	 * labeled alternative in {@link FlaskPythonParser#declaration}.
	 * @param ctx the parse tree
	 */
	void enterDeclarationStmt(FlaskPythonParser.DeclarationStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code declarationStmt}
	 * labeled alternative in {@link FlaskPythonParser#declaration}.
	 * @param ctx the parse tree
	 */
	void exitDeclarationStmt(FlaskPythonParser.DeclarationStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code functionDecleration}
	 * labeled alternative in {@link FlaskPythonParser#functionDecl}.
	 * @param ctx the parse tree
	 */
	void enterFunctionDecleration(FlaskPythonParser.FunctionDeclerationContext ctx);
	/**
	 * Exit a parse tree produced by the {@code functionDecleration}
	 * labeled alternative in {@link FlaskPythonParser#functionDecl}.
	 * @param ctx the parse tree
	 */
	void exitFunctionDecleration(FlaskPythonParser.FunctionDeclerationContext ctx);
	/**
	 * Enter a parse tree produced by the {@code decoratorRule}
	 * labeled alternative in {@link FlaskPythonParser#decorator}.
	 * @param ctx the parse tree
	 */
	void enterDecoratorRule(FlaskPythonParser.DecoratorRuleContext ctx);
	/**
	 * Exit a parse tree produced by the {@code decoratorRule}
	 * labeled alternative in {@link FlaskPythonParser#decorator}.
	 * @param ctx the parse tree
	 */
	void exitDecoratorRule(FlaskPythonParser.DecoratorRuleContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#paramList}.
	 * @param ctx the parse tree
	 */
	void enterParamList(FlaskPythonParser.ParamListContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#paramList}.
	 * @param ctx the parse tree
	 */
	void exitParamList(FlaskPythonParser.ParamListContext ctx);
	/**
	 * Enter a parse tree produced by the {@code varargParam}
	 * labeled alternative in {@link FlaskPythonParser#parameter}.
	 * @param ctx the parse tree
	 */
	void enterVarargParam(FlaskPythonParser.VarargParamContext ctx);
	/**
	 * Exit a parse tree produced by the {@code varargParam}
	 * labeled alternative in {@link FlaskPythonParser#parameter}.
	 * @param ctx the parse tree
	 */
	void exitVarargParam(FlaskPythonParser.VarargParamContext ctx);
	/**
	 * Enter a parse tree produced by the {@code kwargParam}
	 * labeled alternative in {@link FlaskPythonParser#parameter}.
	 * @param ctx the parse tree
	 */
	void enterKwargParam(FlaskPythonParser.KwargParamContext ctx);
	/**
	 * Exit a parse tree produced by the {@code kwargParam}
	 * labeled alternative in {@link FlaskPythonParser#parameter}.
	 * @param ctx the parse tree
	 */
	void exitKwargParam(FlaskPythonParser.KwargParamContext ctx);
	/**
	 * Enter a parse tree produced by the {@code normalParam}
	 * labeled alternative in {@link FlaskPythonParser#parameter}.
	 * @param ctx the parse tree
	 */
	void enterNormalParam(FlaskPythonParser.NormalParamContext ctx);
	/**
	 * Exit a parse tree produced by the {@code normalParam}
	 * labeled alternative in {@link FlaskPythonParser#parameter}.
	 * @param ctx the parse tree
	 */
	void exitNormalParam(FlaskPythonParser.NormalParamContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#dottedName}.
	 * @param ctx the parse tree
	 */
	void enterDottedName(FlaskPythonParser.DottedNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#dottedName}.
	 * @param ctx the parse tree
	 */
	void exitDottedName(FlaskPythonParser.DottedNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#argumentList}.
	 * @param ctx the parse tree
	 */
	void enterArgumentList(FlaskPythonParser.ArgumentListContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#argumentList}.
	 * @param ctx the parse tree
	 */
	void exitArgumentList(FlaskPythonParser.ArgumentListContext ctx);
	/**
	 * Enter a parse tree produced by the {@code keywordArgument}
	 * labeled alternative in {@link FlaskPythonParser#argument}.
	 * @param ctx the parse tree
	 */
	void enterKeywordArgument(FlaskPythonParser.KeywordArgumentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code keywordArgument}
	 * labeled alternative in {@link FlaskPythonParser#argument}.
	 * @param ctx the parse tree
	 */
	void exitKeywordArgument(FlaskPythonParser.KeywordArgumentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code positionalArgument}
	 * labeled alternative in {@link FlaskPythonParser#argument}.
	 * @param ctx the parse tree
	 */
	void enterPositionalArgument(FlaskPythonParser.PositionalArgumentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code positionalArgument}
	 * labeled alternative in {@link FlaskPythonParser#argument}.
	 * @param ctx the parse tree
	 */
	void exitPositionalArgument(FlaskPythonParser.PositionalArgumentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code assignmentStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterAssignmentStmt(FlaskPythonParser.AssignmentStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code assignmentStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitAssignmentStmt(FlaskPythonParser.AssignmentStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code exprStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterExprStmt(FlaskPythonParser.ExprStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code exprStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitExprStmt(FlaskPythonParser.ExprStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ifStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterIfStmt(FlaskPythonParser.IfStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ifStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitIfStmt(FlaskPythonParser.IfStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code forStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterForStmt(FlaskPythonParser.ForStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code forStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitForStmt(FlaskPythonParser.ForStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code whileStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterWhileStmt(FlaskPythonParser.WhileStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code whileStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitWhileStmt(FlaskPythonParser.WhileStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code tryStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterTryStmt(FlaskPythonParser.TryStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code tryStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitTryStmt(FlaskPythonParser.TryStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code raiseStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterRaiseStmt(FlaskPythonParser.RaiseStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code raiseStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitRaiseStmt(FlaskPythonParser.RaiseStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code returnStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterReturnStmt(FlaskPythonParser.ReturnStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code returnStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitReturnStmt(FlaskPythonParser.ReturnStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code passStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterPassStmt(FlaskPythonParser.PassStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code passStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitPassStmt(FlaskPythonParser.PassStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code breakStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterBreakStmt(FlaskPythonParser.BreakStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code breakStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitBreakStmt(FlaskPythonParser.BreakStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code continueStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterContinueStmt(FlaskPythonParser.ContinueStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code continueStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitContinueStmt(FlaskPythonParser.ContinueStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code globalStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterGlobalStmt(FlaskPythonParser.GlobalStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code globalStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitGlobalStmt(FlaskPythonParser.GlobalStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code withStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterWithStmt(FlaskPythonParser.WithStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code withStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitWithStmt(FlaskPythonParser.WithStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code newLine}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterNewLine(FlaskPythonParser.NewLineContext ctx);
	/**
	 * Exit a parse tree produced by the {@code newLine}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitNewLine(FlaskPythonParser.NewLineContext ctx);
	/**
	 * Enter a parse tree produced by the {@code assignmentRule}
	 * labeled alternative in {@link FlaskPythonParser#assignment}.
	 * @param ctx the parse tree
	 */
	void enterAssignmentRule(FlaskPythonParser.AssignmentRuleContext ctx);
	/**
	 * Exit a parse tree produced by the {@code assignmentRule}
	 * labeled alternative in {@link FlaskPythonParser#assignment}.
	 * @param ctx the parse tree
	 */
	void exitAssignmentRule(FlaskPythonParser.AssignmentRuleContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#assignOp}.
	 * @param ctx the parse tree
	 */
	void enterAssignOp(FlaskPythonParser.AssignOpContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#assignOp}.
	 * @param ctx the parse tree
	 */
	void exitAssignOp(FlaskPythonParser.AssignOpContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#leftHandSide}.
	 * @param ctx the parse tree
	 */
	void enterLeftHandSide(FlaskPythonParser.LeftHandSideContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#leftHandSide}.
	 * @param ctx the parse tree
	 */
	void exitLeftHandSide(FlaskPythonParser.LeftHandSideContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#exprStatement}.
	 * @param ctx the parse tree
	 */
	void enterExprStatement(FlaskPythonParser.ExprStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#exprStatement}.
	 * @param ctx the parse tree
	 */
	void exitExprStatement(FlaskPythonParser.ExprStatementContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ifStatementRule}
	 * labeled alternative in {@link FlaskPythonParser#ifStatement}.
	 * @param ctx the parse tree
	 */
	void enterIfStatementRule(FlaskPythonParser.IfStatementRuleContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ifStatementRule}
	 * labeled alternative in {@link FlaskPythonParser#ifStatement}.
	 * @param ctx the parse tree
	 */
	void exitIfStatementRule(FlaskPythonParser.IfStatementRuleContext ctx);
	/**
	 * Enter a parse tree produced by the {@code forStatementRule}
	 * labeled alternative in {@link FlaskPythonParser#forStatement}.
	 * @param ctx the parse tree
	 */
	void enterForStatementRule(FlaskPythonParser.ForStatementRuleContext ctx);
	/**
	 * Exit a parse tree produced by the {@code forStatementRule}
	 * labeled alternative in {@link FlaskPythonParser#forStatement}.
	 * @param ctx the parse tree
	 */
	void exitForStatementRule(FlaskPythonParser.ForStatementRuleContext ctx);
	/**
	 * Enter a parse tree produced by the {@code whileStatementRule}
	 * labeled alternative in {@link FlaskPythonParser#whileStatement}.
	 * @param ctx the parse tree
	 */
	void enterWhileStatementRule(FlaskPythonParser.WhileStatementRuleContext ctx);
	/**
	 * Exit a parse tree produced by the {@code whileStatementRule}
	 * labeled alternative in {@link FlaskPythonParser#whileStatement}.
	 * @param ctx the parse tree
	 */
	void exitWhileStatementRule(FlaskPythonParser.WhileStatementRuleContext ctx);
	/**
	 * Enter a parse tree produced by the {@code tryStatementRule}
	 * labeled alternative in {@link FlaskPythonParser#tryStatement}.
	 * @param ctx the parse tree
	 */
	void enterTryStatementRule(FlaskPythonParser.TryStatementRuleContext ctx);
	/**
	 * Exit a parse tree produced by the {@code tryStatementRule}
	 * labeled alternative in {@link FlaskPythonParser#tryStatement}.
	 * @param ctx the parse tree
	 */
	void exitTryStatementRule(FlaskPythonParser.TryStatementRuleContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#exceptClause}.
	 * @param ctx the parse tree
	 */
	void enterExceptClause(FlaskPythonParser.ExceptClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#exceptClause}.
	 * @param ctx the parse tree
	 */
	void exitExceptClause(FlaskPythonParser.ExceptClauseContext ctx);
	/**
	 * Enter a parse tree produced by the {@code raiseStatementRule}
	 * labeled alternative in {@link FlaskPythonParser#raiseStatement}.
	 * @param ctx the parse tree
	 */
	void enterRaiseStatementRule(FlaskPythonParser.RaiseStatementRuleContext ctx);
	/**
	 * Exit a parse tree produced by the {@code raiseStatementRule}
	 * labeled alternative in {@link FlaskPythonParser#raiseStatement}.
	 * @param ctx the parse tree
	 */
	void exitRaiseStatementRule(FlaskPythonParser.RaiseStatementRuleContext ctx);
	/**
	 * Enter a parse tree produced by the {@code withStatementRule}
	 * labeled alternative in {@link FlaskPythonParser#withStatement}.
	 * @param ctx the parse tree
	 */
	void enterWithStatementRule(FlaskPythonParser.WithStatementRuleContext ctx);
	/**
	 * Exit a parse tree produced by the {@code withStatementRule}
	 * labeled alternative in {@link FlaskPythonParser#withStatement}.
	 * @param ctx the parse tree
	 */
	void exitWithStatementRule(FlaskPythonParser.WithStatementRuleContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#returnStatement}.
	 * @param ctx the parse tree
	 */
	void enterReturnStatement(FlaskPythonParser.ReturnStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#returnStatement}.
	 * @param ctx the parse tree
	 */
	void exitReturnStatement(FlaskPythonParser.ReturnStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#passStatement}.
	 * @param ctx the parse tree
	 */
	void enterPassStatement(FlaskPythonParser.PassStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#passStatement}.
	 * @param ctx the parse tree
	 */
	void exitPassStatement(FlaskPythonParser.PassStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#breakStatement}.
	 * @param ctx the parse tree
	 */
	void enterBreakStatement(FlaskPythonParser.BreakStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#breakStatement}.
	 * @param ctx the parse tree
	 */
	void exitBreakStatement(FlaskPythonParser.BreakStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#continueStatement}.
	 * @param ctx the parse tree
	 */
	void enterContinueStatement(FlaskPythonParser.ContinueStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#continueStatement}.
	 * @param ctx the parse tree
	 */
	void exitContinueStatement(FlaskPythonParser.ContinueStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#globalStatement}.
	 * @param ctx the parse tree
	 */
	void enterGlobalStatement(FlaskPythonParser.GlobalStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#globalStatement}.
	 * @param ctx the parse tree
	 */
	void exitGlobalStatement(FlaskPythonParser.GlobalStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#suite}.
	 * @param ctx the parse tree
	 */
	void enterSuite(FlaskPythonParser.SuiteContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#suite}.
	 * @param ctx the parse tree
	 */
	void exitSuite(FlaskPythonParser.SuiteContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#braceBlock}.
	 * @param ctx the parse tree
	 */
	void enterBraceBlock(FlaskPythonParser.BraceBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#braceBlock}.
	 * @param ctx the parse tree
	 */
	void exitBraceBlock(FlaskPythonParser.BraceBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#indentBlock}.
	 * @param ctx the parse tree
	 */
	void enterIndentBlock(FlaskPythonParser.IndentBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#indentBlock}.
	 * @param ctx the parse tree
	 */
	void exitIndentBlock(FlaskPythonParser.IndentBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#block}.
	 * @param ctx the parse tree
	 */
	void enterBlock(FlaskPythonParser.BlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#block}.
	 * @param ctx the parse tree
	 */
	void exitBlock(FlaskPythonParser.BlockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code expressionRoot}
	 * labeled alternative in {@link FlaskPythonParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterExpressionRoot(FlaskPythonParser.ExpressionRootContext ctx);
	/**
	 * Exit a parse tree produced by the {@code expressionRoot}
	 * labeled alternative in {@link FlaskPythonParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitExpressionRoot(FlaskPythonParser.ExpressionRootContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#logicalOrExpression}.
	 * @param ctx the parse tree
	 */
	void enterLogicalOrExpression(FlaskPythonParser.LogicalOrExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#logicalOrExpression}.
	 * @param ctx the parse tree
	 */
	void exitLogicalOrExpression(FlaskPythonParser.LogicalOrExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#logicalAndExpression}.
	 * @param ctx the parse tree
	 */
	void enterLogicalAndExpression(FlaskPythonParser.LogicalAndExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#logicalAndExpression}.
	 * @param ctx the parse tree
	 */
	void exitLogicalAndExpression(FlaskPythonParser.LogicalAndExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#equalityExpression}.
	 * @param ctx the parse tree
	 */
	void enterEqualityExpression(FlaskPythonParser.EqualityExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#equalityExpression}.
	 * @param ctx the parse tree
	 */
	void exitEqualityExpression(FlaskPythonParser.EqualityExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#comparisonExpression}.
	 * @param ctx the parse tree
	 */
	void enterComparisonExpression(FlaskPythonParser.ComparisonExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#comparisonExpression}.
	 * @param ctx the parse tree
	 */
	void exitComparisonExpression(FlaskPythonParser.ComparisonExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#additiveExpression}.
	 * @param ctx the parse tree
	 */
	void enterAdditiveExpression(FlaskPythonParser.AdditiveExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#additiveExpression}.
	 * @param ctx the parse tree
	 */
	void exitAdditiveExpression(FlaskPythonParser.AdditiveExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#multiplicativeExpression}.
	 * @param ctx the parse tree
	 */
	void enterMultiplicativeExpression(FlaskPythonParser.MultiplicativeExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#multiplicativeExpression}.
	 * @param ctx the parse tree
	 */
	void exitMultiplicativeExpression(FlaskPythonParser.MultiplicativeExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code unaryOp}
	 * labeled alternative in {@link FlaskPythonParser#unaryExpression}.
	 * @param ctx the parse tree
	 */
	void enterUnaryOp(FlaskPythonParser.UnaryOpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code unaryOp}
	 * labeled alternative in {@link FlaskPythonParser#unaryExpression}.
	 * @param ctx the parse tree
	 */
	void exitUnaryOp(FlaskPythonParser.UnaryOpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code simplePrimary}
	 * labeled alternative in {@link FlaskPythonParser#unaryExpression}.
	 * @param ctx the parse tree
	 */
	void enterSimplePrimary(FlaskPythonParser.SimplePrimaryContext ctx);
	/**
	 * Exit a parse tree produced by the {@code simplePrimary}
	 * labeled alternative in {@link FlaskPythonParser#unaryExpression}.
	 * @param ctx the parse tree
	 */
	void exitSimplePrimary(FlaskPythonParser.SimplePrimaryContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#primaryExpression}.
	 * @param ctx the parse tree
	 */
	void enterPrimaryExpression(FlaskPythonParser.PrimaryExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#primaryExpression}.
	 * @param ctx the parse tree
	 */
	void exitPrimaryExpression(FlaskPythonParser.PrimaryExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code indexExpr}
	 * labeled alternative in {@link FlaskPythonParser#postfix}.
	 * @param ctx the parse tree
	 */
	void enterIndexExpr(FlaskPythonParser.IndexExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code indexExpr}
	 * labeled alternative in {@link FlaskPythonParser#postfix}.
	 * @param ctx the parse tree
	 */
	void exitIndexExpr(FlaskPythonParser.IndexExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code attrExpr}
	 * labeled alternative in {@link FlaskPythonParser#postfix}.
	 * @param ctx the parse tree
	 */
	void enterAttrExpr(FlaskPythonParser.AttrExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code attrExpr}
	 * labeled alternative in {@link FlaskPythonParser#postfix}.
	 * @param ctx the parse tree
	 */
	void exitAttrExpr(FlaskPythonParser.AttrExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code callExpr}
	 * labeled alternative in {@link FlaskPythonParser#postfix}.
	 * @param ctx the parse tree
	 */
	void enterCallExpr(FlaskPythonParser.CallExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code callExpr}
	 * labeled alternative in {@link FlaskPythonParser#postfix}.
	 * @param ctx the parse tree
	 */
	void exitCallExpr(FlaskPythonParser.CallExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#listLiteral}.
	 * @param ctx the parse tree
	 */
	void enterListLiteral(FlaskPythonParser.ListLiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#listLiteral}.
	 * @param ctx the parse tree
	 */
	void exitListLiteral(FlaskPythonParser.ListLiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#dictLiteral}.
	 * @param ctx the parse tree
	 */
	void enterDictLiteral(FlaskPythonParser.DictLiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#dictLiteral}.
	 * @param ctx the parse tree
	 */
	void exitDictLiteral(FlaskPythonParser.DictLiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#dictEntry}.
	 * @param ctx the parse tree
	 */
	void enterDictEntry(FlaskPythonParser.DictEntryContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#dictEntry}.
	 * @param ctx the parse tree
	 */
	void exitDictEntry(FlaskPythonParser.DictEntryContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskPythonParser#setLiteral}.
	 * @param ctx the parse tree
	 */
	void enterSetLiteral(FlaskPythonParser.SetLiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskPythonParser#setLiteral}.
	 * @param ctx the parse tree
	 */
	void exitSetLiteral(FlaskPythonParser.SetLiteralContext ctx);
	/**
	 * Enter a parse tree produced by the {@code idAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterIdAtom(FlaskPythonParser.IdAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code idAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitIdAtom(FlaskPythonParser.IdAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code stringAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterStringAtom(FlaskPythonParser.StringAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code stringAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitStringAtom(FlaskPythonParser.StringAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code intAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterIntAtom(FlaskPythonParser.IntAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code intAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitIntAtom(FlaskPythonParser.IntAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code floatAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterFloatAtom(FlaskPythonParser.FloatAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code floatAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitFloatAtom(FlaskPythonParser.FloatAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code trueAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterTrueAtom(FlaskPythonParser.TrueAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code trueAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitTrueAtom(FlaskPythonParser.TrueAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code falseAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterFalseAtom(FlaskPythonParser.FalseAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code falseAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitFalseAtom(FlaskPythonParser.FalseAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code noneAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterNoneAtom(FlaskPythonParser.NoneAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code noneAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitNoneAtom(FlaskPythonParser.NoneAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code listAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterListAtom(FlaskPythonParser.ListAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code listAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitListAtom(FlaskPythonParser.ListAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code dictAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterDictAtom(FlaskPythonParser.DictAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code dictAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitDictAtom(FlaskPythonParser.DictAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code setAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterSetAtom(FlaskPythonParser.SetAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code setAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitSetAtom(FlaskPythonParser.SetAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code parenAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterParenAtom(FlaskPythonParser.ParenAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code parenAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitParenAtom(FlaskPythonParser.ParenAtomContext ctx);
}