package gen;
// Generated from /tmp/tmp.SdsHqkGNgv/FlaskTemplateParser.g4 by ANTLR 4.13.2
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link FlaskTemplateParser}.
 */
public interface FlaskTemplateParserListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by the {@code templateRoot}
	 * labeled alternative in {@link FlaskTemplateParser#template}.
	 * @param ctx the parse tree
	 */
	void enterTemplateRoot(FlaskTemplateParser.TemplateRootContext ctx);
	/**
	 * Exit a parse tree produced by the {@code templateRoot}
	 * labeled alternative in {@link FlaskTemplateParser#template}.
	 * @param ctx the parse tree
	 */
	void exitTemplateRoot(FlaskTemplateParser.TemplateRootContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#doctype}.
	 * @param ctx the parse tree
	 */
	void enterDoctype(FlaskTemplateParser.DoctypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#doctype}.
	 * @param ctx the parse tree
	 */
	void exitDoctype(FlaskTemplateParser.DoctypeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code htmlDocument}
	 * labeled alternative in {@link FlaskTemplateParser#html}.
	 * @param ctx the parse tree
	 */
	void enterHtmlDocument(FlaskTemplateParser.HtmlDocumentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code htmlDocument}
	 * labeled alternative in {@link FlaskTemplateParser#html}.
	 * @param ctx the parse tree
	 */
	void exitHtmlDocument(FlaskTemplateParser.HtmlDocumentContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#templateContent}.
	 * @param ctx the parse tree
	 */
	void enterTemplateContent(FlaskTemplateParser.TemplateContentContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#templateContent}.
	 * @param ctx the parse tree
	 */
	void exitTemplateContent(FlaskTemplateParser.TemplateContentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code htmlContent}
	 * labeled alternative in {@link FlaskTemplateParser#contentItem}.
	 * @param ctx the parse tree
	 */
	void enterHtmlContent(FlaskTemplateParser.HtmlContentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code htmlContent}
	 * labeled alternative in {@link FlaskTemplateParser#contentItem}.
	 * @param ctx the parse tree
	 */
	void exitHtmlContent(FlaskTemplateParser.HtmlContentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code jinjaBlockContent}
	 * labeled alternative in {@link FlaskTemplateParser#contentItem}.
	 * @param ctx the parse tree
	 */
	void enterJinjaBlockContent(FlaskTemplateParser.JinjaBlockContentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code jinjaBlockContent}
	 * labeled alternative in {@link FlaskTemplateParser#contentItem}.
	 * @param ctx the parse tree
	 */
	void exitJinjaBlockContent(FlaskTemplateParser.JinjaBlockContentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code jinjaTagContent}
	 * labeled alternative in {@link FlaskTemplateParser#contentItem}.
	 * @param ctx the parse tree
	 */
	void enterJinjaTagContent(FlaskTemplateParser.JinjaTagContentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code jinjaTagContent}
	 * labeled alternative in {@link FlaskTemplateParser#contentItem}.
	 * @param ctx the parse tree
	 */
	void exitJinjaTagContent(FlaskTemplateParser.JinjaTagContentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code jinjaExprContent}
	 * labeled alternative in {@link FlaskTemplateParser#contentItem}.
	 * @param ctx the parse tree
	 */
	void enterJinjaExprContent(FlaskTemplateParser.JinjaExprContentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code jinjaExprContent}
	 * labeled alternative in {@link FlaskTemplateParser#contentItem}.
	 * @param ctx the parse tree
	 */
	void exitJinjaExprContent(FlaskTemplateParser.JinjaExprContentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code htmlTextContent}
	 * labeled alternative in {@link FlaskTemplateParser#contentItem}.
	 * @param ctx the parse tree
	 */
	void enterHtmlTextContent(FlaskTemplateParser.HtmlTextContentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code htmlTextContent}
	 * labeled alternative in {@link FlaskTemplateParser#contentItem}.
	 * @param ctx the parse tree
	 */
	void exitHtmlTextContent(FlaskTemplateParser.HtmlTextContentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code cssContent}
	 * labeled alternative in {@link FlaskTemplateParser#contentItem}.
	 * @param ctx the parse tree
	 */
	void enterCssContent(FlaskTemplateParser.CssContentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code cssContent}
	 * labeled alternative in {@link FlaskTemplateParser#contentItem}.
	 * @param ctx the parse tree
	 */
	void exitCssContent(FlaskTemplateParser.CssContentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code newlineContent}
	 * labeled alternative in {@link FlaskTemplateParser#contentItem}.
	 * @param ctx the parse tree
	 */
	void enterNewlineContent(FlaskTemplateParser.NewlineContentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code newlineContent}
	 * labeled alternative in {@link FlaskTemplateParser#contentItem}.
	 * @param ctx the parse tree
	 */
	void exitNewlineContent(FlaskTemplateParser.NewlineContentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code normalElement}
	 * labeled alternative in {@link FlaskTemplateParser#htmlElement}.
	 * @param ctx the parse tree
	 */
	void enterNormalElement(FlaskTemplateParser.NormalElementContext ctx);
	/**
	 * Exit a parse tree produced by the {@code normalElement}
	 * labeled alternative in {@link FlaskTemplateParser#htmlElement}.
	 * @param ctx the parse tree
	 */
	void exitNormalElement(FlaskTemplateParser.NormalElementContext ctx);
	/**
	 * Enter a parse tree produced by the {@code voidElementTag}
	 * labeled alternative in {@link FlaskTemplateParser#htmlElement}.
	 * @param ctx the parse tree
	 */
	void enterVoidElementTag(FlaskTemplateParser.VoidElementTagContext ctx);
	/**
	 * Exit a parse tree produced by the {@code voidElementTag}
	 * labeled alternative in {@link FlaskTemplateParser#htmlElement}.
	 * @param ctx the parse tree
	 */
	void exitVoidElementTag(FlaskTemplateParser.VoidElementTagContext ctx);
	/**
	 * Enter a parse tree produced by the {@code selfClosingElementTag}
	 * labeled alternative in {@link FlaskTemplateParser#htmlElement}.
	 * @param ctx the parse tree
	 */
	void enterSelfClosingElementTag(FlaskTemplateParser.SelfClosingElementTagContext ctx);
	/**
	 * Exit a parse tree produced by the {@code selfClosingElementTag}
	 * labeled alternative in {@link FlaskTemplateParser#htmlElement}.
	 * @param ctx the parse tree
	 */
	void exitSelfClosingElementTag(FlaskTemplateParser.SelfClosingElementTagContext ctx);
	/**
	 * Enter a parse tree produced by the {@code openingTagNode}
	 * labeled alternative in {@link FlaskTemplateParser#openingTag}.
	 * @param ctx the parse tree
	 */
	void enterOpeningTagNode(FlaskTemplateParser.OpeningTagNodeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code openingTagNode}
	 * labeled alternative in {@link FlaskTemplateParser#openingTag}.
	 * @param ctx the parse tree
	 */
	void exitOpeningTagNode(FlaskTemplateParser.OpeningTagNodeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code closingTagNode}
	 * labeled alternative in {@link FlaskTemplateParser#closingTag}.
	 * @param ctx the parse tree
	 */
	void enterClosingTagNode(FlaskTemplateParser.ClosingTagNodeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code closingTagNode}
	 * labeled alternative in {@link FlaskTemplateParser#closingTag}.
	 * @param ctx the parse tree
	 */
	void exitClosingTagNode(FlaskTemplateParser.ClosingTagNodeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code selfClosingTagNode}
	 * labeled alternative in {@link FlaskTemplateParser#selfClosingTag}.
	 * @param ctx the parse tree
	 */
	void enterSelfClosingTagNode(FlaskTemplateParser.SelfClosingTagNodeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code selfClosingTagNode}
	 * labeled alternative in {@link FlaskTemplateParser#selfClosingTag}.
	 * @param ctx the parse tree
	 */
	void exitSelfClosingTagNode(FlaskTemplateParser.SelfClosingTagNodeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code voidTagNode}
	 * labeled alternative in {@link FlaskTemplateParser#voidTag}.
	 * @param ctx the parse tree
	 */
	void enterVoidTagNode(FlaskTemplateParser.VoidTagNodeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code voidTagNode}
	 * labeled alternative in {@link FlaskTemplateParser#voidTag}.
	 * @param ctx the parse tree
	 */
	void exitVoidTagNode(FlaskTemplateParser.VoidTagNodeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code htmlAttributeList}
	 * labeled alternative in {@link FlaskTemplateParser#htmlAttributes}.
	 * @param ctx the parse tree
	 */
	void enterHtmlAttributeList(FlaskTemplateParser.HtmlAttributeListContext ctx);
	/**
	 * Exit a parse tree produced by the {@code htmlAttributeList}
	 * labeled alternative in {@link FlaskTemplateParser#htmlAttributes}.
	 * @param ctx the parse tree
	 */
	void exitHtmlAttributeList(FlaskTemplateParser.HtmlAttributeListContext ctx);
	/**
	 * Enter a parse tree produced by the {@code attributeWithValue}
	 * labeled alternative in {@link FlaskTemplateParser#htmlAttribute}.
	 * @param ctx the parse tree
	 */
	void enterAttributeWithValue(FlaskTemplateParser.AttributeWithValueContext ctx);
	/**
	 * Exit a parse tree produced by the {@code attributeWithValue}
	 * labeled alternative in {@link FlaskTemplateParser#htmlAttribute}.
	 * @param ctx the parse tree
	 */
	void exitAttributeWithValue(FlaskTemplateParser.AttributeWithValueContext ctx);
	/**
	 * Enter a parse tree produced by the {@code booleanAttribute}
	 * labeled alternative in {@link FlaskTemplateParser#htmlAttribute}.
	 * @param ctx the parse tree
	 */
	void enterBooleanAttribute(FlaskTemplateParser.BooleanAttributeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code booleanAttribute}
	 * labeled alternative in {@link FlaskTemplateParser#htmlAttribute}.
	 * @param ctx the parse tree
	 */
	void exitBooleanAttribute(FlaskTemplateParser.BooleanAttributeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code doubleQuotedValue}
	 * labeled alternative in {@link FlaskTemplateParser#htmlAttributeValue}.
	 * @param ctx the parse tree
	 */
	void enterDoubleQuotedValue(FlaskTemplateParser.DoubleQuotedValueContext ctx);
	/**
	 * Exit a parse tree produced by the {@code doubleQuotedValue}
	 * labeled alternative in {@link FlaskTemplateParser#htmlAttributeValue}.
	 * @param ctx the parse tree
	 */
	void exitDoubleQuotedValue(FlaskTemplateParser.DoubleQuotedValueContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#attrValueContent}.
	 * @param ctx the parse tree
	 */
	void enterAttrValueContent(FlaskTemplateParser.AttrValueContentContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#attrValueContent}.
	 * @param ctx the parse tree
	 */
	void exitAttrValueContent(FlaskTemplateParser.AttrValueContentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code attrText}
	 * labeled alternative in {@link FlaskTemplateParser#attrValueItem}.
	 * @param ctx the parse tree
	 */
	void enterAttrText(FlaskTemplateParser.AttrTextContext ctx);
	/**
	 * Exit a parse tree produced by the {@code attrText}
	 * labeled alternative in {@link FlaskTemplateParser#attrValueItem}.
	 * @param ctx the parse tree
	 */
	void exitAttrText(FlaskTemplateParser.AttrTextContext ctx);
	/**
	 * Enter a parse tree produced by the {@code attrJinjaExprItem}
	 * labeled alternative in {@link FlaskTemplateParser#attrValueItem}.
	 * @param ctx the parse tree
	 */
	void enterAttrJinjaExprItem(FlaskTemplateParser.AttrJinjaExprItemContext ctx);
	/**
	 * Exit a parse tree produced by the {@code attrJinjaExprItem}
	 * labeled alternative in {@link FlaskTemplateParser#attrValueItem}.
	 * @param ctx the parse tree
	 */
	void exitAttrJinjaExprItem(FlaskTemplateParser.AttrJinjaExprItemContext ctx);
	/**
	 * Enter a parse tree produced by the {@code attrJinjaBlockItem}
	 * labeled alternative in {@link FlaskTemplateParser#attrValueItem}.
	 * @param ctx the parse tree
	 */
	void enterAttrJinjaBlockItem(FlaskTemplateParser.AttrJinjaBlockItemContext ctx);
	/**
	 * Exit a parse tree produced by the {@code attrJinjaBlockItem}
	 * labeled alternative in {@link FlaskTemplateParser#attrValueItem}.
	 * @param ctx the parse tree
	 */
	void exitAttrJinjaBlockItem(FlaskTemplateParser.AttrJinjaBlockItemContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#attrJinjaExpr}.
	 * @param ctx the parse tree
	 */
	void enterAttrJinjaExpr(FlaskTemplateParser.AttrJinjaExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#attrJinjaExpr}.
	 * @param ctx the parse tree
	 */
	void exitAttrJinjaExpr(FlaskTemplateParser.AttrJinjaExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#attrJinjaExprContent}.
	 * @param ctx the parse tree
	 */
	void enterAttrJinjaExprContent(FlaskTemplateParser.AttrJinjaExprContentContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#attrJinjaExprContent}.
	 * @param ctx the parse tree
	 */
	void exitAttrJinjaExprContent(FlaskTemplateParser.AttrJinjaExprContentContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#attrJinjaBlock}.
	 * @param ctx the parse tree
	 */
	void enterAttrJinjaBlock(FlaskTemplateParser.AttrJinjaBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#attrJinjaBlock}.
	 * @param ctx the parse tree
	 */
	void exitAttrJinjaBlock(FlaskTemplateParser.AttrJinjaBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#htmlText}.
	 * @param ctx the parse tree
	 */
	void enterHtmlText(FlaskTemplateParser.HtmlTextContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#htmlText}.
	 * @param ctx the parse tree
	 */
	void exitHtmlText(FlaskTemplateParser.HtmlTextContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#jinjaBlock}.
	 * @param ctx the parse tree
	 */
	void enterJinjaBlock(FlaskTemplateParser.JinjaBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#jinjaBlock}.
	 * @param ctx the parse tree
	 */
	void exitJinjaBlock(FlaskTemplateParser.JinjaBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#ifBlock}.
	 * @param ctx the parse tree
	 */
	void enterIfBlock(FlaskTemplateParser.IfBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#ifBlock}.
	 * @param ctx the parse tree
	 */
	void exitIfBlock(FlaskTemplateParser.IfBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#elifClause}.
	 * @param ctx the parse tree
	 */
	void enterElifClause(FlaskTemplateParser.ElifClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#elifClause}.
	 * @param ctx the parse tree
	 */
	void exitElifClause(FlaskTemplateParser.ElifClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#elseClause}.
	 * @param ctx the parse tree
	 */
	void enterElseClause(FlaskTemplateParser.ElseClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#elseClause}.
	 * @param ctx the parse tree
	 */
	void exitElseClause(FlaskTemplateParser.ElseClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#forBlock}.
	 * @param ctx the parse tree
	 */
	void enterForBlock(FlaskTemplateParser.ForBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#forBlock}.
	 * @param ctx the parse tree
	 */
	void exitForBlock(FlaskTemplateParser.ForBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#blockBlock}.
	 * @param ctx the parse tree
	 */
	void enterBlockBlock(FlaskTemplateParser.BlockBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#blockBlock}.
	 * @param ctx the parse tree
	 */
	void exitBlockBlock(FlaskTemplateParser.BlockBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#withBlock}.
	 * @param ctx the parse tree
	 */
	void enterWithBlock(FlaskTemplateParser.WithBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#withBlock}.
	 * @param ctx the parse tree
	 */
	void exitWithBlock(FlaskTemplateParser.WithBlockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code jinjaTagNode}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaTag}.
	 * @param ctx the parse tree
	 */
	void enterJinjaTagNode(FlaskTemplateParser.JinjaTagNodeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code jinjaTagNode}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaTag}.
	 * @param ctx the parse tree
	 */
	void exitJinjaTagNode(FlaskTemplateParser.JinjaTagNodeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code setBlock}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaTagStatement}.
	 * @param ctx the parse tree
	 */
	void enterSetBlock(FlaskTemplateParser.SetBlockContext ctx);
	/**
	 * Exit a parse tree produced by the {@code setBlock}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaTagStatement}.
	 * @param ctx the parse tree
	 */
	void exitSetBlock(FlaskTemplateParser.SetBlockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code includeBlock}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaTagStatement}.
	 * @param ctx the parse tree
	 */
	void enterIncludeBlock(FlaskTemplateParser.IncludeBlockContext ctx);
	/**
	 * Exit a parse tree produced by the {@code includeBlock}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaTagStatement}.
	 * @param ctx the parse tree
	 */
	void exitIncludeBlock(FlaskTemplateParser.IncludeBlockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code importBlock}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaTagStatement}.
	 * @param ctx the parse tree
	 */
	void enterImportBlock(FlaskTemplateParser.ImportBlockContext ctx);
	/**
	 * Exit a parse tree produced by the {@code importBlock}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaTagStatement}.
	 * @param ctx the parse tree
	 */
	void exitImportBlock(FlaskTemplateParser.ImportBlockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code fromImportBlock}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaTagStatement}.
	 * @param ctx the parse tree
	 */
	void enterFromImportBlock(FlaskTemplateParser.FromImportBlockContext ctx);
	/**
	 * Exit a parse tree produced by the {@code fromImportBlock}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaTagStatement}.
	 * @param ctx the parse tree
	 */
	void exitFromImportBlock(FlaskTemplateParser.FromImportBlockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code extendsBlock}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaTagStatement}.
	 * @param ctx the parse tree
	 */
	void enterExtendsBlock(FlaskTemplateParser.ExtendsBlockContext ctx);
	/**
	 * Exit a parse tree produced by the {@code extendsBlock}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaTagStatement}.
	 * @param ctx the parse tree
	 */
	void exitExtendsBlock(FlaskTemplateParser.ExtendsBlockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code genericBlock}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaTagStatement}.
	 * @param ctx the parse tree
	 */
	void enterGenericBlock(FlaskTemplateParser.GenericBlockContext ctx);
	/**
	 * Exit a parse tree produced by the {@code genericBlock}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaTagStatement}.
	 * @param ctx the parse tree
	 */
	void exitGenericBlock(FlaskTemplateParser.GenericBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#blockExpression}.
	 * @param ctx the parse tree
	 */
	void enterBlockExpression(FlaskTemplateParser.BlockExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#blockExpression}.
	 * @param ctx the parse tree
	 */
	void exitBlockExpression(FlaskTemplateParser.BlockExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#blockLogicalOrExpression}.
	 * @param ctx the parse tree
	 */
	void enterBlockLogicalOrExpression(FlaskTemplateParser.BlockLogicalOrExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#blockLogicalOrExpression}.
	 * @param ctx the parse tree
	 */
	void exitBlockLogicalOrExpression(FlaskTemplateParser.BlockLogicalOrExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#blockLogicalAndExpression}.
	 * @param ctx the parse tree
	 */
	void enterBlockLogicalAndExpression(FlaskTemplateParser.BlockLogicalAndExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#blockLogicalAndExpression}.
	 * @param ctx the parse tree
	 */
	void exitBlockLogicalAndExpression(FlaskTemplateParser.BlockLogicalAndExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#blockEqualityExpression}.
	 * @param ctx the parse tree
	 */
	void enterBlockEqualityExpression(FlaskTemplateParser.BlockEqualityExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#blockEqualityExpression}.
	 * @param ctx the parse tree
	 */
	void exitBlockEqualityExpression(FlaskTemplateParser.BlockEqualityExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#blockComparisonExpression}.
	 * @param ctx the parse tree
	 */
	void enterBlockComparisonExpression(FlaskTemplateParser.BlockComparisonExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#blockComparisonExpression}.
	 * @param ctx the parse tree
	 */
	void exitBlockComparisonExpression(FlaskTemplateParser.BlockComparisonExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#blockAdditiveExpression}.
	 * @param ctx the parse tree
	 */
	void enterBlockAdditiveExpression(FlaskTemplateParser.BlockAdditiveExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#blockAdditiveExpression}.
	 * @param ctx the parse tree
	 */
	void exitBlockAdditiveExpression(FlaskTemplateParser.BlockAdditiveExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#blockMultiplicativeExpression}.
	 * @param ctx the parse tree
	 */
	void enterBlockMultiplicativeExpression(FlaskTemplateParser.BlockMultiplicativeExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#blockMultiplicativeExpression}.
	 * @param ctx the parse tree
	 */
	void exitBlockMultiplicativeExpression(FlaskTemplateParser.BlockMultiplicativeExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code blockUnaryOp}
	 * labeled alternative in {@link FlaskTemplateParser#blockUnaryExpression}.
	 * @param ctx the parse tree
	 */
	void enterBlockUnaryOp(FlaskTemplateParser.BlockUnaryOpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code blockUnaryOp}
	 * labeled alternative in {@link FlaskTemplateParser#blockUnaryExpression}.
	 * @param ctx the parse tree
	 */
	void exitBlockUnaryOp(FlaskTemplateParser.BlockUnaryOpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code blockUnaryBase}
	 * labeled alternative in {@link FlaskTemplateParser#blockUnaryExpression}.
	 * @param ctx the parse tree
	 */
	void enterBlockUnaryBase(FlaskTemplateParser.BlockUnaryBaseContext ctx);
	/**
	 * Exit a parse tree produced by the {@code blockUnaryBase}
	 * labeled alternative in {@link FlaskTemplateParser#blockUnaryExpression}.
	 * @param ctx the parse tree
	 */
	void exitBlockUnaryBase(FlaskTemplateParser.BlockUnaryBaseContext ctx);
	/**
	 * Enter a parse tree produced by the {@code blockPrimary}
	 * labeled alternative in {@link FlaskTemplateParser#blockPrimaryExpression}.
	 * @param ctx the parse tree
	 */
	void enterBlockPrimary(FlaskTemplateParser.BlockPrimaryContext ctx);
	/**
	 * Exit a parse tree produced by the {@code blockPrimary}
	 * labeled alternative in {@link FlaskTemplateParser#blockPrimaryExpression}.
	 * @param ctx the parse tree
	 */
	void exitBlockPrimary(FlaskTemplateParser.BlockPrimaryContext ctx);
	/**
	 * Enter a parse tree produced by the {@code blockParenExpr}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 */
	void enterBlockParenExpr(FlaskTemplateParser.BlockParenExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code blockParenExpr}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 */
	void exitBlockParenExpr(FlaskTemplateParser.BlockParenExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code blockIdentifier}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 */
	void enterBlockIdentifier(FlaskTemplateParser.BlockIdentifierContext ctx);
	/**
	 * Exit a parse tree produced by the {@code blockIdentifier}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 */
	void exitBlockIdentifier(FlaskTemplateParser.BlockIdentifierContext ctx);
	/**
	 * Enter a parse tree produced by the {@code blockStringLiteral}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 */
	void enterBlockStringLiteral(FlaskTemplateParser.BlockStringLiteralContext ctx);
	/**
	 * Exit a parse tree produced by the {@code blockStringLiteral}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 */
	void exitBlockStringLiteral(FlaskTemplateParser.BlockStringLiteralContext ctx);
	/**
	 * Enter a parse tree produced by the {@code blockNumberLiteral}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 */
	void enterBlockNumberLiteral(FlaskTemplateParser.BlockNumberLiteralContext ctx);
	/**
	 * Exit a parse tree produced by the {@code blockNumberLiteral}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 */
	void exitBlockNumberLiteral(FlaskTemplateParser.BlockNumberLiteralContext ctx);
	/**
	 * Enter a parse tree produced by the {@code blockTrueLiteral}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 */
	void enterBlockTrueLiteral(FlaskTemplateParser.BlockTrueLiteralContext ctx);
	/**
	 * Exit a parse tree produced by the {@code blockTrueLiteral}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 */
	void exitBlockTrueLiteral(FlaskTemplateParser.BlockTrueLiteralContext ctx);
	/**
	 * Enter a parse tree produced by the {@code blockFalseLiteral}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 */
	void enterBlockFalseLiteral(FlaskTemplateParser.BlockFalseLiteralContext ctx);
	/**
	 * Exit a parse tree produced by the {@code blockFalseLiteral}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 */
	void exitBlockFalseLiteral(FlaskTemplateParser.BlockFalseLiteralContext ctx);
	/**
	 * Enter a parse tree produced by the {@code blockNoneLiteral}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 */
	void enterBlockNoneLiteral(FlaskTemplateParser.BlockNoneLiteralContext ctx);
	/**
	 * Exit a parse tree produced by the {@code blockNoneLiteral}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 */
	void exitBlockNoneLiteral(FlaskTemplateParser.BlockNoneLiteralContext ctx);
	/**
	 * Enter a parse tree produced by the {@code blockListLiteral}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 */
	void enterBlockListLiteral(FlaskTemplateParser.BlockListLiteralContext ctx);
	/**
	 * Exit a parse tree produced by the {@code blockListLiteral}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 */
	void exitBlockListLiteral(FlaskTemplateParser.BlockListLiteralContext ctx);
	/**
	 * Enter a parse tree produced by the {@code blockDictLiteral}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 */
	void enterBlockDictLiteral(FlaskTemplateParser.BlockDictLiteralContext ctx);
	/**
	 * Exit a parse tree produced by the {@code blockDictLiteral}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 */
	void exitBlockDictLiteral(FlaskTemplateParser.BlockDictLiteralContext ctx);
	/**
	 * Enter a parse tree produced by the {@code blockFilterOp}
	 * labeled alternative in {@link FlaskTemplateParser#blockPostfix}.
	 * @param ctx the parse tree
	 */
	void enterBlockFilterOp(FlaskTemplateParser.BlockFilterOpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code blockFilterOp}
	 * labeled alternative in {@link FlaskTemplateParser#blockPostfix}.
	 * @param ctx the parse tree
	 */
	void exitBlockFilterOp(FlaskTemplateParser.BlockFilterOpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code blockCallOp}
	 * labeled alternative in {@link FlaskTemplateParser#blockPostfix}.
	 * @param ctx the parse tree
	 */
	void enterBlockCallOp(FlaskTemplateParser.BlockCallOpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code blockCallOp}
	 * labeled alternative in {@link FlaskTemplateParser#blockPostfix}.
	 * @param ctx the parse tree
	 */
	void exitBlockCallOp(FlaskTemplateParser.BlockCallOpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code blockMemberOp}
	 * labeled alternative in {@link FlaskTemplateParser#blockPostfix}.
	 * @param ctx the parse tree
	 */
	void enterBlockMemberOp(FlaskTemplateParser.BlockMemberOpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code blockMemberOp}
	 * labeled alternative in {@link FlaskTemplateParser#blockPostfix}.
	 * @param ctx the parse tree
	 */
	void exitBlockMemberOp(FlaskTemplateParser.BlockMemberOpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code blockIndexOp}
	 * labeled alternative in {@link FlaskTemplateParser#blockPostfix}.
	 * @param ctx the parse tree
	 */
	void enterBlockIndexOp(FlaskTemplateParser.BlockIndexOpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code blockIndexOp}
	 * labeled alternative in {@link FlaskTemplateParser#blockPostfix}.
	 * @param ctx the parse tree
	 */
	void exitBlockIndexOp(FlaskTemplateParser.BlockIndexOpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code blockSlice}
	 * labeled alternative in {@link FlaskTemplateParser#blockSliceItem}.
	 * @param ctx the parse tree
	 */
	void enterBlockSlice(FlaskTemplateParser.BlockSliceContext ctx);
	/**
	 * Exit a parse tree produced by the {@code blockSlice}
	 * labeled alternative in {@link FlaskTemplateParser#blockSliceItem}.
	 * @param ctx the parse tree
	 */
	void exitBlockSlice(FlaskTemplateParser.BlockSliceContext ctx);
	/**
	 * Enter a parse tree produced by the {@code blockIndex}
	 * labeled alternative in {@link FlaskTemplateParser#blockSliceItem}.
	 * @param ctx the parse tree
	 */
	void enterBlockIndex(FlaskTemplateParser.BlockIndexContext ctx);
	/**
	 * Exit a parse tree produced by the {@code blockIndex}
	 * labeled alternative in {@link FlaskTemplateParser#blockSliceItem}.
	 * @param ctx the parse tree
	 */
	void exitBlockIndex(FlaskTemplateParser.BlockIndexContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#blockArgumentList}.
	 * @param ctx the parse tree
	 */
	void enterBlockArgumentList(FlaskTemplateParser.BlockArgumentListContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#blockArgumentList}.
	 * @param ctx the parse tree
	 */
	void exitBlockArgumentList(FlaskTemplateParser.BlockArgumentListContext ctx);
	/**
	 * Enter a parse tree produced by the {@code blockKeywordArgument}
	 * labeled alternative in {@link FlaskTemplateParser#blockArgument}.
	 * @param ctx the parse tree
	 */
	void enterBlockKeywordArgument(FlaskTemplateParser.BlockKeywordArgumentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code blockKeywordArgument}
	 * labeled alternative in {@link FlaskTemplateParser#blockArgument}.
	 * @param ctx the parse tree
	 */
	void exitBlockKeywordArgument(FlaskTemplateParser.BlockKeywordArgumentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code blockPositionalArgument}
	 * labeled alternative in {@link FlaskTemplateParser#blockArgument}.
	 * @param ctx the parse tree
	 */
	void enterBlockPositionalArgument(FlaskTemplateParser.BlockPositionalArgumentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code blockPositionalArgument}
	 * labeled alternative in {@link FlaskTemplateParser#blockArgument}.
	 * @param ctx the parse tree
	 */
	void exitBlockPositionalArgument(FlaskTemplateParser.BlockPositionalArgumentContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#blockExpressionList}.
	 * @param ctx the parse tree
	 */
	void enterBlockExpressionList(FlaskTemplateParser.BlockExpressionListContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#blockExpressionList}.
	 * @param ctx the parse tree
	 */
	void exitBlockExpressionList(FlaskTemplateParser.BlockExpressionListContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#blockDictPairList}.
	 * @param ctx the parse tree
	 */
	void enterBlockDictPairList(FlaskTemplateParser.BlockDictPairListContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#blockDictPairList}.
	 * @param ctx the parse tree
	 */
	void exitBlockDictPairList(FlaskTemplateParser.BlockDictPairListContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#blockDictPair}.
	 * @param ctx the parse tree
	 */
	void enterBlockDictPair(FlaskTemplateParser.BlockDictPairContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#blockDictPair}.
	 * @param ctx the parse tree
	 */
	void exitBlockDictPair(FlaskTemplateParser.BlockDictPairContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#importList}.
	 * @param ctx the parse tree
	 */
	void enterImportList(FlaskTemplateParser.ImportListContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#importList}.
	 * @param ctx the parse tree
	 */
	void exitImportList(FlaskTemplateParser.ImportListContext ctx);
	/**
	 * Enter a parse tree produced by the {@code jinjaExprNode}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaExpr}.
	 * @param ctx the parse tree
	 */
	void enterJinjaExprNode(FlaskTemplateParser.JinjaExprNodeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code jinjaExprNode}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaExpr}.
	 * @param ctx the parse tree
	 */
	void exitJinjaExprNode(FlaskTemplateParser.JinjaExprNodeContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#jinjaExpression}.
	 * @param ctx the parse tree
	 */
	void enterJinjaExpression(FlaskTemplateParser.JinjaExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#jinjaExpression}.
	 * @param ctx the parse tree
	 */
	void exitJinjaExpression(FlaskTemplateParser.JinjaExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code expressionRoot}
	 * labeled alternative in {@link FlaskTemplateParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterExpressionRoot(FlaskTemplateParser.ExpressionRootContext ctx);
	/**
	 * Exit a parse tree produced by the {@code expressionRoot}
	 * labeled alternative in {@link FlaskTemplateParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitExpressionRoot(FlaskTemplateParser.ExpressionRootContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#logicalOrExpression}.
	 * @param ctx the parse tree
	 */
	void enterLogicalOrExpression(FlaskTemplateParser.LogicalOrExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#logicalOrExpression}.
	 * @param ctx the parse tree
	 */
	void exitLogicalOrExpression(FlaskTemplateParser.LogicalOrExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#logicalAndExpression}.
	 * @param ctx the parse tree
	 */
	void enterLogicalAndExpression(FlaskTemplateParser.LogicalAndExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#logicalAndExpression}.
	 * @param ctx the parse tree
	 */
	void exitLogicalAndExpression(FlaskTemplateParser.LogicalAndExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#equalityExpression}.
	 * @param ctx the parse tree
	 */
	void enterEqualityExpression(FlaskTemplateParser.EqualityExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#equalityExpression}.
	 * @param ctx the parse tree
	 */
	void exitEqualityExpression(FlaskTemplateParser.EqualityExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#comparisonExpression}.
	 * @param ctx the parse tree
	 */
	void enterComparisonExpression(FlaskTemplateParser.ComparisonExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#comparisonExpression}.
	 * @param ctx the parse tree
	 */
	void exitComparisonExpression(FlaskTemplateParser.ComparisonExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#additiveExpression}.
	 * @param ctx the parse tree
	 */
	void enterAdditiveExpression(FlaskTemplateParser.AdditiveExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#additiveExpression}.
	 * @param ctx the parse tree
	 */
	void exitAdditiveExpression(FlaskTemplateParser.AdditiveExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#multiplicativeExpression}.
	 * @param ctx the parse tree
	 */
	void enterMultiplicativeExpression(FlaskTemplateParser.MultiplicativeExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#multiplicativeExpression}.
	 * @param ctx the parse tree
	 */
	void exitMultiplicativeExpression(FlaskTemplateParser.MultiplicativeExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code unaryOp}
	 * labeled alternative in {@link FlaskTemplateParser#unaryExpression}.
	 * @param ctx the parse tree
	 */
	void enterUnaryOp(FlaskTemplateParser.UnaryOpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code unaryOp}
	 * labeled alternative in {@link FlaskTemplateParser#unaryExpression}.
	 * @param ctx the parse tree
	 */
	void exitUnaryOp(FlaskTemplateParser.UnaryOpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code unaryBase}
	 * labeled alternative in {@link FlaskTemplateParser#unaryExpression}.
	 * @param ctx the parse tree
	 */
	void enterUnaryBase(FlaskTemplateParser.UnaryBaseContext ctx);
	/**
	 * Exit a parse tree produced by the {@code unaryBase}
	 * labeled alternative in {@link FlaskTemplateParser#unaryExpression}.
	 * @param ctx the parse tree
	 */
	void exitUnaryBase(FlaskTemplateParser.UnaryBaseContext ctx);
	/**
	 * Enter a parse tree produced by the {@code primary}
	 * labeled alternative in {@link FlaskTemplateParser#primaryExpression}.
	 * @param ctx the parse tree
	 */
	void enterPrimary(FlaskTemplateParser.PrimaryContext ctx);
	/**
	 * Exit a parse tree produced by the {@code primary}
	 * labeled alternative in {@link FlaskTemplateParser#primaryExpression}.
	 * @param ctx the parse tree
	 */
	void exitPrimary(FlaskTemplateParser.PrimaryContext ctx);
	/**
	 * Enter a parse tree produced by the {@code parenExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterParenExpr(FlaskTemplateParser.ParenExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code parenExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitParenExpr(FlaskTemplateParser.ParenExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code identifierExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterIdentifierExpr(FlaskTemplateParser.IdentifierExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code identifierExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitIdentifierExpr(FlaskTemplateParser.IdentifierExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code stringExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterStringExpr(FlaskTemplateParser.StringExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code stringExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitStringExpr(FlaskTemplateParser.StringExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code numberExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterNumberExpr(FlaskTemplateParser.NumberExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code numberExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitNumberExpr(FlaskTemplateParser.NumberExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code trueExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterTrueExpr(FlaskTemplateParser.TrueExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code trueExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitTrueExpr(FlaskTemplateParser.TrueExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code falseExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterFalseExpr(FlaskTemplateParser.FalseExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code falseExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitFalseExpr(FlaskTemplateParser.FalseExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code noneExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterNoneExpr(FlaskTemplateParser.NoneExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code noneExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitNoneExpr(FlaskTemplateParser.NoneExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code listExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterListExpr(FlaskTemplateParser.ListExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code listExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitListExpr(FlaskTemplateParser.ListExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code dictExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterDictExpr(FlaskTemplateParser.DictExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code dictExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitDictExpr(FlaskTemplateParser.DictExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code filterExpr}
	 * labeled alternative in {@link FlaskTemplateParser#postfix}.
	 * @param ctx the parse tree
	 */
	void enterFilterExpr(FlaskTemplateParser.FilterExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code filterExpr}
	 * labeled alternative in {@link FlaskTemplateParser#postfix}.
	 * @param ctx the parse tree
	 */
	void exitFilterExpr(FlaskTemplateParser.FilterExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code callExpr}
	 * labeled alternative in {@link FlaskTemplateParser#postfix}.
	 * @param ctx the parse tree
	 */
	void enterCallExpr(FlaskTemplateParser.CallExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code callExpr}
	 * labeled alternative in {@link FlaskTemplateParser#postfix}.
	 * @param ctx the parse tree
	 */
	void exitCallExpr(FlaskTemplateParser.CallExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code memberOp}
	 * labeled alternative in {@link FlaskTemplateParser#postfix}.
	 * @param ctx the parse tree
	 */
	void enterMemberOp(FlaskTemplateParser.MemberOpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code memberOp}
	 * labeled alternative in {@link FlaskTemplateParser#postfix}.
	 * @param ctx the parse tree
	 */
	void exitMemberOp(FlaskTemplateParser.MemberOpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code indexOp}
	 * labeled alternative in {@link FlaskTemplateParser#postfix}.
	 * @param ctx the parse tree
	 */
	void enterIndexOp(FlaskTemplateParser.IndexOpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code indexOp}
	 * labeled alternative in {@link FlaskTemplateParser#postfix}.
	 * @param ctx the parse tree
	 */
	void exitIndexOp(FlaskTemplateParser.IndexOpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code slice}
	 * labeled alternative in {@link FlaskTemplateParser#sliceItem}.
	 * @param ctx the parse tree
	 */
	void enterSlice(FlaskTemplateParser.SliceContext ctx);
	/**
	 * Exit a parse tree produced by the {@code slice}
	 * labeled alternative in {@link FlaskTemplateParser#sliceItem}.
	 * @param ctx the parse tree
	 */
	void exitSlice(FlaskTemplateParser.SliceContext ctx);
	/**
	 * Enter a parse tree produced by the {@code index}
	 * labeled alternative in {@link FlaskTemplateParser#sliceItem}.
	 * @param ctx the parse tree
	 */
	void enterIndex(FlaskTemplateParser.IndexContext ctx);
	/**
	 * Exit a parse tree produced by the {@code index}
	 * labeled alternative in {@link FlaskTemplateParser#sliceItem}.
	 * @param ctx the parse tree
	 */
	void exitIndex(FlaskTemplateParser.IndexContext ctx);
	/**
	 * Enter a parse tree produced by the {@code argList}
	 * labeled alternative in {@link FlaskTemplateParser#argumentList}.
	 * @param ctx the parse tree
	 */
	void enterArgList(FlaskTemplateParser.ArgListContext ctx);
	/**
	 * Exit a parse tree produced by the {@code argList}
	 * labeled alternative in {@link FlaskTemplateParser#argumentList}.
	 * @param ctx the parse tree
	 */
	void exitArgList(FlaskTemplateParser.ArgListContext ctx);
	/**
	 * Enter a parse tree produced by the {@code keywordArgument}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaArgument}.
	 * @param ctx the parse tree
	 */
	void enterKeywordArgument(FlaskTemplateParser.KeywordArgumentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code keywordArgument}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaArgument}.
	 * @param ctx the parse tree
	 */
	void exitKeywordArgument(FlaskTemplateParser.KeywordArgumentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code positionalArgument}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaArgument}.
	 * @param ctx the parse tree
	 */
	void enterPositionalArgument(FlaskTemplateParser.PositionalArgumentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code positionalArgument}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaArgument}.
	 * @param ctx the parse tree
	 */
	void exitPositionalArgument(FlaskTemplateParser.PositionalArgumentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code exprList}
	 * labeled alternative in {@link FlaskTemplateParser#expressionList}.
	 * @param ctx the parse tree
	 */
	void enterExprList(FlaskTemplateParser.ExprListContext ctx);
	/**
	 * Exit a parse tree produced by the {@code exprList}
	 * labeled alternative in {@link FlaskTemplateParser#expressionList}.
	 * @param ctx the parse tree
	 */
	void exitExprList(FlaskTemplateParser.ExprListContext ctx);
	/**
	 * Enter a parse tree produced by the {@code dictPairListNode}
	 * labeled alternative in {@link FlaskTemplateParser#dictPairList}.
	 * @param ctx the parse tree
	 */
	void enterDictPairListNode(FlaskTemplateParser.DictPairListNodeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code dictPairListNode}
	 * labeled alternative in {@link FlaskTemplateParser#dictPairList}.
	 * @param ctx the parse tree
	 */
	void exitDictPairListNode(FlaskTemplateParser.DictPairListNodeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code dictPairNode}
	 * labeled alternative in {@link FlaskTemplateParser#dictPair}.
	 * @param ctx the parse tree
	 */
	void enterDictPairNode(FlaskTemplateParser.DictPairNodeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code dictPairNode}
	 * labeled alternative in {@link FlaskTemplateParser#dictPair}.
	 * @param ctx the parse tree
	 */
	void exitDictPairNode(FlaskTemplateParser.DictPairNodeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code styleWithAttributes}
	 * labeled alternative in {@link FlaskTemplateParser#cssStyle}.
	 * @param ctx the parse tree
	 */
	void enterStyleWithAttributes(FlaskTemplateParser.StyleWithAttributesContext ctx);
	/**
	 * Exit a parse tree produced by the {@code styleWithAttributes}
	 * labeled alternative in {@link FlaskTemplateParser#cssStyle}.
	 * @param ctx the parse tree
	 */
	void exitStyleWithAttributes(FlaskTemplateParser.StyleWithAttributesContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#cssTagAttributes}.
	 * @param ctx the parse tree
	 */
	void enterCssTagAttributes(FlaskTemplateParser.CssTagAttributesContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#cssTagAttributes}.
	 * @param ctx the parse tree
	 */
	void exitCssTagAttributes(FlaskTemplateParser.CssTagAttributesContext ctx);
	/**
	 * Enter a parse tree produced by the {@code cssTagAttrNode}
	 * labeled alternative in {@link FlaskTemplateParser#cssTagAttribute}.
	 * @param ctx the parse tree
	 */
	void enterCssTagAttrNode(FlaskTemplateParser.CssTagAttrNodeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code cssTagAttrNode}
	 * labeled alternative in {@link FlaskTemplateParser#cssTagAttribute}.
	 * @param ctx the parse tree
	 */
	void exitCssTagAttrNode(FlaskTemplateParser.CssTagAttrNodeContext ctx);
	/**
	 * Enter a parse tree produced by {@link FlaskTemplateParser#cssStyleContent}.
	 * @param ctx the parse tree
	 */
	void enterCssStyleContent(FlaskTemplateParser.CssStyleContentContext ctx);
	/**
	 * Exit a parse tree produced by {@link FlaskTemplateParser#cssStyleContent}.
	 * @param ctx the parse tree
	 */
	void exitCssStyleContent(FlaskTemplateParser.CssStyleContentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code cssRuleNode}
	 * labeled alternative in {@link FlaskTemplateParser#cssRule}.
	 * @param ctx the parse tree
	 */
	void enterCssRuleNode(FlaskTemplateParser.CssRuleNodeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code cssRuleNode}
	 * labeled alternative in {@link FlaskTemplateParser#cssRule}.
	 * @param ctx the parse tree
	 */
	void exitCssRuleNode(FlaskTemplateParser.CssRuleNodeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code cssSelectorExpr}
	 * labeled alternative in {@link FlaskTemplateParser#cssSelectors}.
	 * @param ctx the parse tree
	 */
	void enterCssSelectorExpr(FlaskTemplateParser.CssSelectorExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code cssSelectorExpr}
	 * labeled alternative in {@link FlaskTemplateParser#cssSelectors}.
	 * @param ctx the parse tree
	 */
	void exitCssSelectorExpr(FlaskTemplateParser.CssSelectorExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code cssSelectorNode}
	 * labeled alternative in {@link FlaskTemplateParser#cssSelector}.
	 * @param ctx the parse tree
	 */
	void enterCssSelectorNode(FlaskTemplateParser.CssSelectorNodeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code cssSelectorNode}
	 * labeled alternative in {@link FlaskTemplateParser#cssSelector}.
	 * @param ctx the parse tree
	 */
	void exitCssSelectorNode(FlaskTemplateParser.CssSelectorNodeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code cssDeclarationList}
	 * labeled alternative in {@link FlaskTemplateParser#cssDeclarations}.
	 * @param ctx the parse tree
	 */
	void enterCssDeclarationList(FlaskTemplateParser.CssDeclarationListContext ctx);
	/**
	 * Exit a parse tree produced by the {@code cssDeclarationList}
	 * labeled alternative in {@link FlaskTemplateParser#cssDeclarations}.
	 * @param ctx the parse tree
	 */
	void exitCssDeclarationList(FlaskTemplateParser.CssDeclarationListContext ctx);
	/**
	 * Enter a parse tree produced by the {@code cssDeclarationNode}
	 * labeled alternative in {@link FlaskTemplateParser#cssDeclaration}.
	 * @param ctx the parse tree
	 */
	void enterCssDeclarationNode(FlaskTemplateParser.CssDeclarationNodeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code cssDeclarationNode}
	 * labeled alternative in {@link FlaskTemplateParser#cssDeclaration}.
	 * @param ctx the parse tree
	 */
	void exitCssDeclarationNode(FlaskTemplateParser.CssDeclarationNodeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code cssValueList}
	 * labeled alternative in {@link FlaskTemplateParser#cssValues}.
	 * @param ctx the parse tree
	 */
	void enterCssValueList(FlaskTemplateParser.CssValueListContext ctx);
	/**
	 * Exit a parse tree produced by the {@code cssValueList}
	 * labeled alternative in {@link FlaskTemplateParser#cssValues}.
	 * @param ctx the parse tree
	 */
	void exitCssValueList(FlaskTemplateParser.CssValueListContext ctx);
	/**
	 * Enter a parse tree produced by the {@code cssStringValue}
	 * labeled alternative in {@link FlaskTemplateParser#cssValue}.
	 * @param ctx the parse tree
	 */
	void enterCssStringValue(FlaskTemplateParser.CssStringValueContext ctx);
	/**
	 * Exit a parse tree produced by the {@code cssStringValue}
	 * labeled alternative in {@link FlaskTemplateParser#cssValue}.
	 * @param ctx the parse tree
	 */
	void exitCssStringValue(FlaskTemplateParser.CssStringValueContext ctx);
	/**
	 * Enter a parse tree produced by the {@code cssNumericValue}
	 * labeled alternative in {@link FlaskTemplateParser#cssValue}.
	 * @param ctx the parse tree
	 */
	void enterCssNumericValue(FlaskTemplateParser.CssNumericValueContext ctx);
	/**
	 * Exit a parse tree produced by the {@code cssNumericValue}
	 * labeled alternative in {@link FlaskTemplateParser#cssValue}.
	 * @param ctx the parse tree
	 */
	void exitCssNumericValue(FlaskTemplateParser.CssNumericValueContext ctx);
	/**
	 * Enter a parse tree produced by the {@code cssColorValue}
	 * labeled alternative in {@link FlaskTemplateParser#cssValue}.
	 * @param ctx the parse tree
	 */
	void enterCssColorValue(FlaskTemplateParser.CssColorValueContext ctx);
	/**
	 * Exit a parse tree produced by the {@code cssColorValue}
	 * labeled alternative in {@link FlaskTemplateParser#cssValue}.
	 * @param ctx the parse tree
	 */
	void exitCssColorValue(FlaskTemplateParser.CssColorValueContext ctx);
	/**
	 * Enter a parse tree produced by the {@code cssKeywordValue}
	 * labeled alternative in {@link FlaskTemplateParser#cssValue}.
	 * @param ctx the parse tree
	 */
	void enterCssKeywordValue(FlaskTemplateParser.CssKeywordValueContext ctx);
	/**
	 * Exit a parse tree produced by the {@code cssKeywordValue}
	 * labeled alternative in {@link FlaskTemplateParser#cssValue}.
	 * @param ctx the parse tree
	 */
	void exitCssKeywordValue(FlaskTemplateParser.CssKeywordValueContext ctx);
}