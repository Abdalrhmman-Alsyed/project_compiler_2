// Generated from FlaskTemplateParser.g4 by ANTLR 4.13.2
package gen;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue", "this-escape"})
public class FlaskTemplateParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.13.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		NEWLINE=1, HTML_DOCTYPE=2, HTML_COMMENT=3, TEMPLATE_JINJA_BLOCK_START=4, 
		TEMPLATE_JINJA_EXPR_START=5, TEMPLATE_JINJA_COMMENT_START=6, CSS_START=7, 
		HTML_TAG_OPEN_SELF=8, HTML_TAG_OPEN=9, TEMPLATE_WS=10, HTML_TEXT=11, TEMPLATE_END=12, 
		ERROR_CHAR=13, TAG_CLOSE=14, SELF_CLOSE_TAG=15, HTML_EQ=16, VOID_TAG=17, 
		HTML_BOOLEAN_ATTR=18, HTML_ID=19, HTML_QUOTE=20, HTML_WS=21, ATTR_VALUE_QUOTE=22, 
		ATTR_JINJA_EXPR_START=23, ATTR_JINJA_BLOCK_START=24, ATTR_JINJA_COMMENT_START=25, 
		ATTR_VALUE_ESCAPE=26, ATTR_VALUE_ID=27, HTML_ATTR_VALUE_WS=28, BLOCK_EXTENDS=29, 
		BLOCK_BLOCK=30, BLOCK_ENDBLOCK=31, BLOCK_IF=32, BLOCK_ELIF=33, BLOCK_ELSE=34, 
		BLOCK_ENDIF=35, BLOCK_FOR=36, BLOCK_ENDFOR=37, BLOCK_SET=38, BLOCK_INCLUDE=39, 
		BLOCK_IN=40, BLOCK_IS=41, BLOCK_IMPORT=42, BLOCK_FROM=43, BLOCK_WITH=44, 
		BLOCK_ENDWITH=45, BLOCK_DOT=46, BLOCK_EQ=47, BLOCK_AS=48, BLOCK_COMMA=49, 
		BLOCK_AND=50, BLOCK_OR=51, BLOCK_NOT=52, BLOCK_EQEQ=53, BLOCK_NEQ=54, 
		BLOCK_LT=55, BLOCK_LTE=56, BLOCK_GT=57, BLOCK_GTE=58, BLOCK_PLUS=59, BLOCK_MINUS=60, 
		BLOCK_STAR=61, BLOCK_SLASH=62, BLOCK_PERCENT=63, BLOCK_LPAREN=64, BLOCK_RPAREN=65, 
		BLOCK_PIPE=66, BLOCK_TRUE=67, BLOCK_FALSE=68, BLOCK_NONE=69, BLOCK_LBRACK=70, 
		BLOCK_RBRACK=71, BLOCK_LBRACE=72, BLOCK_RBRACE=73, BLOCK_COLON=74, BLOCK_ID=75, 
		BLOCK_STRING=76, BLOCK_NUMBER=77, BLOCK_WS=78, BLOCK_END=79, EXPR_LPAREN=80, 
		EXPR_RPAREN=81, EXPR_LBRACK=82, EXPR_RBRACK=83, EXPR_LBRACE=84, EXPR_RBRACE=85, 
		EXPR_COMMA=86, EXPR_COLON=87, EXPR_DOT=88, EXPR_PIPE=89, EXPR_TILDE=90, 
		EXPR_QUESTION=91, EXPR_PLUS=92, EXPR_MINUS=93, EXPR_STAR=94, EXPR_SLASH=95, 
		EXPR_PERCENT=96, EXPR_POWER=97, EXPR_FLOORDIV=98, EXPR_EQ=99, EXPR_EQEQ=100, 
		EXPR_NEQ=101, EXPR_LT=102, EXPR_LTE=103, EXPR_GT=104, EXPR_GTE=105, EXPR_AND=106, 
		EXPR_OR=107, EXPR_NOT=108, EXPR_IN=109, EXPR_IS=110, EXPR_IF=111, EXPR_ELSE=112, 
		EXPR_TRUE=113, EXPR_FALSE=114, EXPR_NONE=115, EXPR_ID=116, EXPR_STRING=117, 
		EXPR_NUMBER=118, EXPR_ELLIPSIS=119, EXPR_WALRUS=120, EXPR_WS=121, EXPR_END=122, 
		COMMENT_TEXT=123, COMMENT_WS=124, COMMENT_END=125, CSS_TAG_CLOSE=126, 
		CSS_TAG_ATTR=127, CSS_TAG_EQ=128, CSS_TAG_STRING=129, CSS_TAG_WS=130, 
		STYLE_TAG_END=131, CSS_CONTENT_COMMENT=132, CSS_LBRACE=133, CSS_CONTENT_WS=134, 
		CSS_CONTENT=135, CSS_RBRACE=136, CSS_COLON=137, CSS_SEMICOLON=138, CSS_COMMA=139, 
		CSS_DOT=140, CSS_PROPERTY=141, CSS_SELECTOR=142, CSS_ATTR_SELECTOR=143, 
		CSS_NUMERIC=144, CSS_COLOR=145, CSS_STRING=146, CSS_KEYWORD=147, CSS_COMMENT=148, 
		CSS_BLOCK_WS=149, CSS_VALUE=150;
	public static final int
		RULE_template = 0, RULE_doctype = 1, RULE_html = 2, RULE_templateContent = 3, 
		RULE_contentItem = 4, RULE_htmlElement = 5, RULE_openingTag = 6, RULE_closingTag = 7, 
		RULE_selfClosingTag = 8, RULE_voidTag = 9, RULE_htmlAttributes = 10, RULE_htmlAttribute = 11, 
		RULE_htmlAttributeValue = 12, RULE_attrValueContent = 13, RULE_attrValueItem = 14, 
		RULE_attrJinjaExpr = 15, RULE_attrJinjaExprContent = 16, RULE_attrJinjaBlock = 17, 
		RULE_htmlText = 18, RULE_jinjaBlock = 19, RULE_ifBlock = 20, RULE_elifClause = 21, 
		RULE_elseClause = 22, RULE_forBlock = 23, RULE_blockBlock = 24, RULE_withBlock = 25, 
		RULE_jinjaTag = 26, RULE_jinjaTagStatement = 27, RULE_blockExpression = 28, 
		RULE_blockLogicalOrExpression = 29, RULE_blockLogicalAndExpression = 30, 
		RULE_blockEqualityExpression = 31, RULE_blockComparisonExpression = 32, 
		RULE_blockAdditiveExpression = 33, RULE_blockMultiplicativeExpression = 34, 
		RULE_blockUnaryExpression = 35, RULE_blockPrimaryExpression = 36, RULE_blockAtom = 37, 
		RULE_blockPostfix = 38, RULE_blockSliceItem = 39, RULE_blockArgumentList = 40, 
		RULE_blockArgument = 41, RULE_blockExpressionList = 42, RULE_blockDictPairList = 43, 
		RULE_blockDictPair = 44, RULE_importList = 45, RULE_jinjaExpr = 46, RULE_jinjaExpression = 47, 
		RULE_expression = 48, RULE_logicalOrExpression = 49, RULE_logicalAndExpression = 50, 
		RULE_equalityExpression = 51, RULE_comparisonExpression = 52, RULE_additiveExpression = 53, 
		RULE_multiplicativeExpression = 54, RULE_unaryExpression = 55, RULE_primaryExpression = 56, 
		RULE_atom = 57, RULE_postfix = 58, RULE_sliceItem = 59, RULE_argumentList = 60, 
		RULE_jinjaArgument = 61, RULE_expressionList = 62, RULE_dictPairList = 63, 
		RULE_dictPair = 64, RULE_cssStyle = 65, RULE_cssTagAttributes = 66, RULE_cssTagAttribute = 67, 
		RULE_cssStyleContent = 68, RULE_cssRule = 69, RULE_cssSelectors = 70, 
		RULE_cssSelector = 71, RULE_cssDeclarations = 72, RULE_cssDeclaration = 73, 
		RULE_cssValues = 74, RULE_cssValue = 75;
	private static String[] makeRuleNames() {
		return new String[] {
			"template", "doctype", "html", "templateContent", "contentItem", "htmlElement", 
			"openingTag", "closingTag", "selfClosingTag", "voidTag", "htmlAttributes", 
			"htmlAttribute", "htmlAttributeValue", "attrValueContent", "attrValueItem", 
			"attrJinjaExpr", "attrJinjaExprContent", "attrJinjaBlock", "htmlText", 
			"jinjaBlock", "ifBlock", "elifClause", "elseClause", "forBlock", "blockBlock", 
			"withBlock", "jinjaTag", "jinjaTagStatement", "blockExpression", "blockLogicalOrExpression", 
			"blockLogicalAndExpression", "blockEqualityExpression", "blockComparisonExpression", 
			"blockAdditiveExpression", "blockMultiplicativeExpression", "blockUnaryExpression", 
			"blockPrimaryExpression", "blockAtom", "blockPostfix", "blockSliceItem", 
			"blockArgumentList", "blockArgument", "blockExpressionList", "blockDictPairList", 
			"blockDictPair", "importList", "jinjaExpr", "jinjaExpression", "expression", 
			"logicalOrExpression", "logicalAndExpression", "equalityExpression", 
			"comparisonExpression", "additiveExpression", "multiplicativeExpression", 
			"unaryExpression", "primaryExpression", "atom", "postfix", "sliceItem", 
			"argumentList", "jinjaArgument", "expressionList", "dictPairList", "dictPair", 
			"cssStyle", "cssTagAttributes", "cssTagAttribute", "cssStyleContent", 
			"cssRule", "cssSelectors", "cssSelector", "cssDeclarations", "cssDeclaration", 
			"cssValues", "cssValue"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, null, null, null, null, null, null, "'<style'", "'</'", null, null, 
			null, "'</html>'", null, null, "'/>'", null, null, null, null, null, 
			null, null, null, null, null, null, null, null, "'extends'", "'block'", 
			"'endblock'", null, "'elif'", null, "'endif'", "'for'", "'endfor'", "'set'", 
			"'include'", null, null, "'import'", "'from'", "'with'", "'endwith'", 
			null, null, "'as'", null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, "'true'", "'false'", 
			"'none'", null, null, null, null, null, null, null, null, null, "'%}'", 
			null, null, null, null, null, null, null, null, null, null, "'~'", "'?'", 
			null, null, null, null, null, "'**'", "'//'", null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, "'...'", "':='", null, "'}}'", null, null, "'#}'", 
			null, null, null, null, null, "'</style>'", null, null, null, null, null, 
			null, "';'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "NEWLINE", "HTML_DOCTYPE", "HTML_COMMENT", "TEMPLATE_JINJA_BLOCK_START", 
			"TEMPLATE_JINJA_EXPR_START", "TEMPLATE_JINJA_COMMENT_START", "CSS_START", 
			"HTML_TAG_OPEN_SELF", "HTML_TAG_OPEN", "TEMPLATE_WS", "HTML_TEXT", "TEMPLATE_END", 
			"ERROR_CHAR", "TAG_CLOSE", "SELF_CLOSE_TAG", "HTML_EQ", "VOID_TAG", "HTML_BOOLEAN_ATTR", 
			"HTML_ID", "HTML_QUOTE", "HTML_WS", "ATTR_VALUE_QUOTE", "ATTR_JINJA_EXPR_START", 
			"ATTR_JINJA_BLOCK_START", "ATTR_JINJA_COMMENT_START", "ATTR_VALUE_ESCAPE", 
			"ATTR_VALUE_ID", "HTML_ATTR_VALUE_WS", "BLOCK_EXTENDS", "BLOCK_BLOCK", 
			"BLOCK_ENDBLOCK", "BLOCK_IF", "BLOCK_ELIF", "BLOCK_ELSE", "BLOCK_ENDIF", 
			"BLOCK_FOR", "BLOCK_ENDFOR", "BLOCK_SET", "BLOCK_INCLUDE", "BLOCK_IN", 
			"BLOCK_IS", "BLOCK_IMPORT", "BLOCK_FROM", "BLOCK_WITH", "BLOCK_ENDWITH", 
			"BLOCK_DOT", "BLOCK_EQ", "BLOCK_AS", "BLOCK_COMMA", "BLOCK_AND", "BLOCK_OR", 
			"BLOCK_NOT", "BLOCK_EQEQ", "BLOCK_NEQ", "BLOCK_LT", "BLOCK_LTE", "BLOCK_GT", 
			"BLOCK_GTE", "BLOCK_PLUS", "BLOCK_MINUS", "BLOCK_STAR", "BLOCK_SLASH", 
			"BLOCK_PERCENT", "BLOCK_LPAREN", "BLOCK_RPAREN", "BLOCK_PIPE", "BLOCK_TRUE", 
			"BLOCK_FALSE", "BLOCK_NONE", "BLOCK_LBRACK", "BLOCK_RBRACK", "BLOCK_LBRACE", 
			"BLOCK_RBRACE", "BLOCK_COLON", "BLOCK_ID", "BLOCK_STRING", "BLOCK_NUMBER", 
			"BLOCK_WS", "BLOCK_END", "EXPR_LPAREN", "EXPR_RPAREN", "EXPR_LBRACK", 
			"EXPR_RBRACK", "EXPR_LBRACE", "EXPR_RBRACE", "EXPR_COMMA", "EXPR_COLON", 
			"EXPR_DOT", "EXPR_PIPE", "EXPR_TILDE", "EXPR_QUESTION", "EXPR_PLUS", 
			"EXPR_MINUS", "EXPR_STAR", "EXPR_SLASH", "EXPR_PERCENT", "EXPR_POWER", 
			"EXPR_FLOORDIV", "EXPR_EQ", "EXPR_EQEQ", "EXPR_NEQ", "EXPR_LT", "EXPR_LTE", 
			"EXPR_GT", "EXPR_GTE", "EXPR_AND", "EXPR_OR", "EXPR_NOT", "EXPR_IN", 
			"EXPR_IS", "EXPR_IF", "EXPR_ELSE", "EXPR_TRUE", "EXPR_FALSE", "EXPR_NONE", 
			"EXPR_ID", "EXPR_STRING", "EXPR_NUMBER", "EXPR_ELLIPSIS", "EXPR_WALRUS", 
			"EXPR_WS", "EXPR_END", "COMMENT_TEXT", "COMMENT_WS", "COMMENT_END", "CSS_TAG_CLOSE", 
			"CSS_TAG_ATTR", "CSS_TAG_EQ", "CSS_TAG_STRING", "CSS_TAG_WS", "STYLE_TAG_END", 
			"CSS_CONTENT_COMMENT", "CSS_LBRACE", "CSS_CONTENT_WS", "CSS_CONTENT", 
			"CSS_RBRACE", "CSS_COLON", "CSS_SEMICOLON", "CSS_COMMA", "CSS_DOT", "CSS_PROPERTY", 
			"CSS_SELECTOR", "CSS_ATTR_SELECTOR", "CSS_NUMERIC", "CSS_COLOR", "CSS_STRING", 
			"CSS_KEYWORD", "CSS_COMMENT", "CSS_BLOCK_WS", "CSS_VALUE"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "FlaskTemplateParser.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public FlaskTemplateParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TemplateContext extends ParserRuleContext {
		public TemplateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_template; }
	 
		public TemplateContext() { }
		public void copyFrom(TemplateContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class TemplateRootContext extends TemplateContext {
		public TerminalNode EOF() { return getToken(FlaskTemplateParser.EOF, 0); }
		public HtmlContext html() {
			return getRuleContext(HtmlContext.class,0);
		}
		public TemplateContentContext templateContent() {
			return getRuleContext(TemplateContentContext.class,0);
		}
		public DoctypeContext doctype() {
			return getRuleContext(DoctypeContext.class,0);
		}
		public List<TerminalNode> NEWLINE() { return getTokens(FlaskTemplateParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(FlaskTemplateParser.NEWLINE, i);
		}
		public TemplateRootContext(TemplateContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitTemplateRoot(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TemplateContext template() throws RecognitionException {
		TemplateContext _localctx = new TemplateContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_template);
		int _la;
		try {
			_localctx = new TemplateRootContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(153);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==HTML_DOCTYPE) {
				{
				setState(152);
				doctype();
				}
			}

			setState(157);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,1,_ctx) ) {
			case 1:
				{
				setState(155);
				html();
				}
				break;
			case 2:
				{
				setState(156);
				templateContent();
				}
				break;
			}
			setState(162);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==NEWLINE) {
				{
				{
				setState(159);
				match(NEWLINE);
				}
				}
				setState(164);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(165);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DoctypeContext extends ParserRuleContext {
		public TerminalNode HTML_DOCTYPE() { return getToken(FlaskTemplateParser.HTML_DOCTYPE, 0); }
		public DoctypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_doctype; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitDoctype(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DoctypeContext doctype() throws RecognitionException {
		DoctypeContext _localctx = new DoctypeContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_doctype);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(167);
			match(HTML_DOCTYPE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class HtmlContext extends ParserRuleContext {
		public HtmlContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_html; }
	 
		public HtmlContext() { }
		public void copyFrom(HtmlContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class HtmlDocumentContext extends HtmlContext {
		public TerminalNode HTML_TAG_OPEN() { return getToken(FlaskTemplateParser.HTML_TAG_OPEN, 0); }
		public TerminalNode HTML_ID() { return getToken(FlaskTemplateParser.HTML_ID, 0); }
		public HtmlAttributesContext htmlAttributes() {
			return getRuleContext(HtmlAttributesContext.class,0);
		}
		public TerminalNode TAG_CLOSE() { return getToken(FlaskTemplateParser.TAG_CLOSE, 0); }
		public TemplateContentContext templateContent() {
			return getRuleContext(TemplateContentContext.class,0);
		}
		public TerminalNode TEMPLATE_END() { return getToken(FlaskTemplateParser.TEMPLATE_END, 0); }
		public HtmlDocumentContext(HtmlContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitHtmlDocument(this);
			else return visitor.visitChildren(this);
		}
	}

	public final HtmlContext html() throws RecognitionException {
		HtmlContext _localctx = new HtmlContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_html);
		try {
			_localctx = new HtmlDocumentContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(169);
			match(HTML_TAG_OPEN);
			setState(170);
			match(HTML_ID);
			setState(171);
			htmlAttributes();
			setState(172);
			match(TAG_CLOSE);
			setState(173);
			templateContent();
			setState(174);
			match(TEMPLATE_END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TemplateContentContext extends ParserRuleContext {
		public List<ContentItemContext> contentItem() {
			return getRuleContexts(ContentItemContext.class);
		}
		public ContentItemContext contentItem(int i) {
			return getRuleContext(ContentItemContext.class,i);
		}
		public TemplateContentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_templateContent; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitTemplateContent(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TemplateContentContext templateContent() throws RecognitionException {
		TemplateContentContext _localctx = new TemplateContentContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_templateContent);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(179);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,3,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(176);
					contentItem();
					}
					} 
				}
				setState(181);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,3,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ContentItemContext extends ParserRuleContext {
		public ContentItemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_contentItem; }
	 
		public ContentItemContext() { }
		public void copyFrom(ContentItemContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class JinjaTagContentContext extends ContentItemContext {
		public JinjaTagContext jinjaTag() {
			return getRuleContext(JinjaTagContext.class,0);
		}
		public JinjaTagContentContext(ContentItemContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitJinjaTagContent(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class JinjaBlockContentContext extends ContentItemContext {
		public JinjaBlockContext jinjaBlock() {
			return getRuleContext(JinjaBlockContext.class,0);
		}
		public JinjaBlockContentContext(ContentItemContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitJinjaBlockContent(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class JinjaExprContentContext extends ContentItemContext {
		public JinjaExprContext jinjaExpr() {
			return getRuleContext(JinjaExprContext.class,0);
		}
		public JinjaExprContentContext(ContentItemContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitJinjaExprContent(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CssContentContext extends ContentItemContext {
		public CssStyleContext cssStyle() {
			return getRuleContext(CssStyleContext.class,0);
		}
		public CssContentContext(ContentItemContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitCssContent(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NewlineContentContext extends ContentItemContext {
		public TerminalNode NEWLINE() { return getToken(FlaskTemplateParser.NEWLINE, 0); }
		public NewlineContentContext(ContentItemContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitNewlineContent(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class HtmlContentContext extends ContentItemContext {
		public HtmlElementContext htmlElement() {
			return getRuleContext(HtmlElementContext.class,0);
		}
		public HtmlContentContext(ContentItemContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitHtmlContent(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class HtmlTextContentContext extends ContentItemContext {
		public HtmlTextContext htmlText() {
			return getRuleContext(HtmlTextContext.class,0);
		}
		public HtmlTextContentContext(ContentItemContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitHtmlTextContent(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ContentItemContext contentItem() throws RecognitionException {
		ContentItemContext _localctx = new ContentItemContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_contentItem);
		try {
			setState(189);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,4,_ctx) ) {
			case 1:
				_localctx = new HtmlContentContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(182);
				htmlElement();
				}
				break;
			case 2:
				_localctx = new JinjaBlockContentContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(183);
				jinjaBlock();
				}
				break;
			case 3:
				_localctx = new JinjaTagContentContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(184);
				jinjaTag();
				}
				break;
			case 4:
				_localctx = new JinjaExprContentContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(185);
				jinjaExpr();
				}
				break;
			case 5:
				_localctx = new HtmlTextContentContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(186);
				htmlText();
				}
				break;
			case 6:
				_localctx = new CssContentContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(187);
				cssStyle();
				}
				break;
			case 7:
				_localctx = new NewlineContentContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(188);
				match(NEWLINE);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class HtmlElementContext extends ParserRuleContext {
		public HtmlElementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_htmlElement; }
	 
		public HtmlElementContext() { }
		public void copyFrom(HtmlElementContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class VoidElementTagContext extends HtmlElementContext {
		public VoidTagContext voidTag() {
			return getRuleContext(VoidTagContext.class,0);
		}
		public VoidElementTagContext(HtmlElementContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitVoidElementTag(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SelfClosingElementTagContext extends HtmlElementContext {
		public SelfClosingTagContext selfClosingTag() {
			return getRuleContext(SelfClosingTagContext.class,0);
		}
		public SelfClosingElementTagContext(HtmlElementContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitSelfClosingElementTag(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NormalElementContext extends HtmlElementContext {
		public OpeningTagContext openingTag() {
			return getRuleContext(OpeningTagContext.class,0);
		}
		public ClosingTagContext closingTag() {
			return getRuleContext(ClosingTagContext.class,0);
		}
		public TemplateContentContext templateContent() {
			return getRuleContext(TemplateContentContext.class,0);
		}
		public NormalElementContext(HtmlElementContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitNormalElement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final HtmlElementContext htmlElement() throws RecognitionException {
		HtmlElementContext _localctx = new HtmlElementContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_htmlElement);
		try {
			setState(199);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,6,_ctx) ) {
			case 1:
				_localctx = new NormalElementContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(191);
				openingTag();
				setState(193);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,5,_ctx) ) {
				case 1:
					{
					setState(192);
					templateContent();
					}
					break;
				}
				setState(195);
				closingTag();
				}
				break;
			case 2:
				_localctx = new VoidElementTagContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(197);
				voidTag();
				}
				break;
			case 3:
				_localctx = new SelfClosingElementTagContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(198);
				selfClosingTag();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OpeningTagContext extends ParserRuleContext {
		public OpeningTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_openingTag; }
	 
		public OpeningTagContext() { }
		public void copyFrom(OpeningTagContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class OpeningTagNodeContext extends OpeningTagContext {
		public TerminalNode HTML_TAG_OPEN() { return getToken(FlaskTemplateParser.HTML_TAG_OPEN, 0); }
		public TerminalNode HTML_ID() { return getToken(FlaskTemplateParser.HTML_ID, 0); }
		public HtmlAttributesContext htmlAttributes() {
			return getRuleContext(HtmlAttributesContext.class,0);
		}
		public TerminalNode TAG_CLOSE() { return getToken(FlaskTemplateParser.TAG_CLOSE, 0); }
		public OpeningTagNodeContext(OpeningTagContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitOpeningTagNode(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OpeningTagContext openingTag() throws RecognitionException {
		OpeningTagContext _localctx = new OpeningTagContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_openingTag);
		try {
			_localctx = new OpeningTagNodeContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(201);
			match(HTML_TAG_OPEN);
			setState(202);
			match(HTML_ID);
			setState(203);
			htmlAttributes();
			setState(204);
			match(TAG_CLOSE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ClosingTagContext extends ParserRuleContext {
		public ClosingTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_closingTag; }
	 
		public ClosingTagContext() { }
		public void copyFrom(ClosingTagContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ClosingTagNodeContext extends ClosingTagContext {
		public TerminalNode HTML_TAG_OPEN_SELF() { return getToken(FlaskTemplateParser.HTML_TAG_OPEN_SELF, 0); }
		public TerminalNode HTML_ID() { return getToken(FlaskTemplateParser.HTML_ID, 0); }
		public TerminalNode TAG_CLOSE() { return getToken(FlaskTemplateParser.TAG_CLOSE, 0); }
		public ClosingTagNodeContext(ClosingTagContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitClosingTagNode(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ClosingTagContext closingTag() throws RecognitionException {
		ClosingTagContext _localctx = new ClosingTagContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_closingTag);
		try {
			_localctx = new ClosingTagNodeContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(206);
			match(HTML_TAG_OPEN_SELF);
			setState(207);
			match(HTML_ID);
			setState(208);
			match(TAG_CLOSE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SelfClosingTagContext extends ParserRuleContext {
		public SelfClosingTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_selfClosingTag; }
	 
		public SelfClosingTagContext() { }
		public void copyFrom(SelfClosingTagContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SelfClosingTagNodeContext extends SelfClosingTagContext {
		public TerminalNode HTML_TAG_OPEN() { return getToken(FlaskTemplateParser.HTML_TAG_OPEN, 0); }
		public TerminalNode HTML_ID() { return getToken(FlaskTemplateParser.HTML_ID, 0); }
		public HtmlAttributesContext htmlAttributes() {
			return getRuleContext(HtmlAttributesContext.class,0);
		}
		public TerminalNode SELF_CLOSE_TAG() { return getToken(FlaskTemplateParser.SELF_CLOSE_TAG, 0); }
		public SelfClosingTagNodeContext(SelfClosingTagContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitSelfClosingTagNode(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SelfClosingTagContext selfClosingTag() throws RecognitionException {
		SelfClosingTagContext _localctx = new SelfClosingTagContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_selfClosingTag);
		try {
			_localctx = new SelfClosingTagNodeContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(210);
			match(HTML_TAG_OPEN);
			setState(211);
			match(HTML_ID);
			setState(212);
			htmlAttributes();
			setState(213);
			match(SELF_CLOSE_TAG);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class VoidTagContext extends ParserRuleContext {
		public VoidTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_voidTag; }
	 
		public VoidTagContext() { }
		public void copyFrom(VoidTagContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class VoidTagNodeContext extends VoidTagContext {
		public TerminalNode HTML_TAG_OPEN() { return getToken(FlaskTemplateParser.HTML_TAG_OPEN, 0); }
		public TerminalNode VOID_TAG() { return getToken(FlaskTemplateParser.VOID_TAG, 0); }
		public HtmlAttributesContext htmlAttributes() {
			return getRuleContext(HtmlAttributesContext.class,0);
		}
		public TerminalNode TAG_CLOSE() { return getToken(FlaskTemplateParser.TAG_CLOSE, 0); }
		public VoidTagNodeContext(VoidTagContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitVoidTagNode(this);
			else return visitor.visitChildren(this);
		}
	}

	public final VoidTagContext voidTag() throws RecognitionException {
		VoidTagContext _localctx = new VoidTagContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_voidTag);
		try {
			_localctx = new VoidTagNodeContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(215);
			match(HTML_TAG_OPEN);
			setState(216);
			match(VOID_TAG);
			setState(217);
			htmlAttributes();
			setState(218);
			match(TAG_CLOSE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class HtmlAttributesContext extends ParserRuleContext {
		public HtmlAttributesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_htmlAttributes; }
	 
		public HtmlAttributesContext() { }
		public void copyFrom(HtmlAttributesContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class HtmlAttributeListContext extends HtmlAttributesContext {
		public List<HtmlAttributeContext> htmlAttribute() {
			return getRuleContexts(HtmlAttributeContext.class);
		}
		public HtmlAttributeContext htmlAttribute(int i) {
			return getRuleContext(HtmlAttributeContext.class,i);
		}
		public HtmlAttributeListContext(HtmlAttributesContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitHtmlAttributeList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final HtmlAttributesContext htmlAttributes() throws RecognitionException {
		HtmlAttributesContext _localctx = new HtmlAttributesContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_htmlAttributes);
		int _la;
		try {
			_localctx = new HtmlAttributeListContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(223);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==HTML_BOOLEAN_ATTR || _la==HTML_ID) {
				{
				{
				setState(220);
				htmlAttribute();
				}
				}
				setState(225);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class HtmlAttributeContext extends ParserRuleContext {
		public HtmlAttributeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_htmlAttribute; }
	 
		public HtmlAttributeContext() { }
		public void copyFrom(HtmlAttributeContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AttributeWithValueContext extends HtmlAttributeContext {
		public TerminalNode HTML_ID() { return getToken(FlaskTemplateParser.HTML_ID, 0); }
		public TerminalNode HTML_EQ() { return getToken(FlaskTemplateParser.HTML_EQ, 0); }
		public HtmlAttributeValueContext htmlAttributeValue() {
			return getRuleContext(HtmlAttributeValueContext.class,0);
		}
		public AttributeWithValueContext(HtmlAttributeContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitAttributeWithValue(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BooleanAttributeContext extends HtmlAttributeContext {
		public TerminalNode HTML_BOOLEAN_ATTR() { return getToken(FlaskTemplateParser.HTML_BOOLEAN_ATTR, 0); }
		public BooleanAttributeContext(HtmlAttributeContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBooleanAttribute(this);
			else return visitor.visitChildren(this);
		}
	}

	public final HtmlAttributeContext htmlAttribute() throws RecognitionException {
		HtmlAttributeContext _localctx = new HtmlAttributeContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_htmlAttribute);
		try {
			setState(230);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case HTML_ID:
				_localctx = new AttributeWithValueContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(226);
				match(HTML_ID);
				setState(227);
				match(HTML_EQ);
				setState(228);
				htmlAttributeValue();
				}
				break;
			case HTML_BOOLEAN_ATTR:
				_localctx = new BooleanAttributeContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(229);
				match(HTML_BOOLEAN_ATTR);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class HtmlAttributeValueContext extends ParserRuleContext {
		public HtmlAttributeValueContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_htmlAttributeValue; }
	 
		public HtmlAttributeValueContext() { }
		public void copyFrom(HtmlAttributeValueContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DoubleQuotedValueContext extends HtmlAttributeValueContext {
		public TerminalNode HTML_QUOTE() { return getToken(FlaskTemplateParser.HTML_QUOTE, 0); }
		public TerminalNode ATTR_VALUE_QUOTE() { return getToken(FlaskTemplateParser.ATTR_VALUE_QUOTE, 0); }
		public AttrValueContentContext attrValueContent() {
			return getRuleContext(AttrValueContentContext.class,0);
		}
		public DoubleQuotedValueContext(HtmlAttributeValueContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitDoubleQuotedValue(this);
			else return visitor.visitChildren(this);
		}
	}

	public final HtmlAttributeValueContext htmlAttributeValue() throws RecognitionException {
		HtmlAttributeValueContext _localctx = new HtmlAttributeValueContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_htmlAttributeValue);
		int _la;
		try {
			_localctx = new DoubleQuotedValueContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(232);
			match(HTML_QUOTE);
			setState(234);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & 159383552L) != 0)) {
				{
				setState(233);
				attrValueContent();
				}
			}

			setState(236);
			match(ATTR_VALUE_QUOTE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AttrValueContentContext extends ParserRuleContext {
		public List<AttrValueItemContext> attrValueItem() {
			return getRuleContexts(AttrValueItemContext.class);
		}
		public AttrValueItemContext attrValueItem(int i) {
			return getRuleContext(AttrValueItemContext.class,i);
		}
		public AttrValueContentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_attrValueContent; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitAttrValueContent(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AttrValueContentContext attrValueContent() throws RecognitionException {
		AttrValueContentContext _localctx = new AttrValueContentContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_attrValueContent);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(239); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(238);
				attrValueItem();
				}
				}
				setState(241); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & 159383552L) != 0) );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AttrValueItemContext extends ParserRuleContext {
		public AttrValueItemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_attrValueItem; }
	 
		public AttrValueItemContext() { }
		public void copyFrom(AttrValueItemContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AttrJinjaBlockItemContext extends AttrValueItemContext {
		public AttrJinjaBlockContext attrJinjaBlock() {
			return getRuleContext(AttrJinjaBlockContext.class,0);
		}
		public AttrJinjaBlockItemContext(AttrValueItemContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitAttrJinjaBlockItem(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AttrTextContext extends AttrValueItemContext {
		public TerminalNode ATTR_VALUE_ID() { return getToken(FlaskTemplateParser.ATTR_VALUE_ID, 0); }
		public AttrTextContext(AttrValueItemContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitAttrText(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AttrJinjaExprItemContext extends AttrValueItemContext {
		public AttrJinjaExprContext attrJinjaExpr() {
			return getRuleContext(AttrJinjaExprContext.class,0);
		}
		public AttrJinjaExprItemContext(AttrValueItemContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitAttrJinjaExprItem(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AttrValueItemContext attrValueItem() throws RecognitionException {
		AttrValueItemContext _localctx = new AttrValueItemContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_attrValueItem);
		try {
			setState(246);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ATTR_VALUE_ID:
				_localctx = new AttrTextContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(243);
				match(ATTR_VALUE_ID);
				}
				break;
			case ATTR_JINJA_EXPR_START:
				_localctx = new AttrJinjaExprItemContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(244);
				attrJinjaExpr();
				}
				break;
			case ATTR_JINJA_BLOCK_START:
				_localctx = new AttrJinjaBlockItemContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(245);
				attrJinjaBlock();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AttrJinjaExprContext extends ParserRuleContext {
		public TerminalNode ATTR_JINJA_EXPR_START() { return getToken(FlaskTemplateParser.ATTR_JINJA_EXPR_START, 0); }
		public AttrJinjaExprContentContext attrJinjaExprContent() {
			return getRuleContext(AttrJinjaExprContentContext.class,0);
		}
		public TerminalNode EXPR_END() { return getToken(FlaskTemplateParser.EXPR_END, 0); }
		public AttrJinjaExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_attrJinjaExpr; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitAttrJinjaExpr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AttrJinjaExprContext attrJinjaExpr() throws RecognitionException {
		AttrJinjaExprContext _localctx = new AttrJinjaExprContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_attrJinjaExpr);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(248);
			match(ATTR_JINJA_EXPR_START);
			setState(249);
			attrJinjaExprContent();
			setState(250);
			match(EXPR_END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AttrJinjaExprContentContext extends ParserRuleContext {
		public JinjaExpressionContext jinjaExpression() {
			return getRuleContext(JinjaExpressionContext.class,0);
		}
		public AttrJinjaExprContentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_attrJinjaExprContent; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitAttrJinjaExprContent(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AttrJinjaExprContentContext attrJinjaExprContent() throws RecognitionException {
		AttrJinjaExprContentContext _localctx = new AttrJinjaExprContentContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_attrJinjaExprContent);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(252);
			jinjaExpression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AttrJinjaBlockContext extends ParserRuleContext {
		public TerminalNode ATTR_JINJA_BLOCK_START() { return getToken(FlaskTemplateParser.ATTR_JINJA_BLOCK_START, 0); }
		public JinjaTagStatementContext jinjaTagStatement() {
			return getRuleContext(JinjaTagStatementContext.class,0);
		}
		public TerminalNode BLOCK_END() { return getToken(FlaskTemplateParser.BLOCK_END, 0); }
		public AttrJinjaBlockContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_attrJinjaBlock; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitAttrJinjaBlock(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AttrJinjaBlockContext attrJinjaBlock() throws RecognitionException {
		AttrJinjaBlockContext _localctx = new AttrJinjaBlockContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_attrJinjaBlock);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(254);
			match(ATTR_JINJA_BLOCK_START);
			setState(255);
			jinjaTagStatement();
			setState(256);
			match(BLOCK_END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class HtmlTextContext extends ParserRuleContext {
		public List<TerminalNode> HTML_TEXT() { return getTokens(FlaskTemplateParser.HTML_TEXT); }
		public TerminalNode HTML_TEXT(int i) {
			return getToken(FlaskTemplateParser.HTML_TEXT, i);
		}
		public HtmlTextContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_htmlText; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitHtmlText(this);
			else return visitor.visitChildren(this);
		}
	}

	public final HtmlTextContext htmlText() throws RecognitionException {
		HtmlTextContext _localctx = new HtmlTextContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_htmlText);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(259); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(258);
					match(HTML_TEXT);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(261); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,12,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JinjaBlockContext extends ParserRuleContext {
		public IfBlockContext ifBlock() {
			return getRuleContext(IfBlockContext.class,0);
		}
		public ForBlockContext forBlock() {
			return getRuleContext(ForBlockContext.class,0);
		}
		public BlockBlockContext blockBlock() {
			return getRuleContext(BlockBlockContext.class,0);
		}
		public WithBlockContext withBlock() {
			return getRuleContext(WithBlockContext.class,0);
		}
		public JinjaBlockContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jinjaBlock; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitJinjaBlock(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JinjaBlockContext jinjaBlock() throws RecognitionException {
		JinjaBlockContext _localctx = new JinjaBlockContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_jinjaBlock);
		try {
			setState(267);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,13,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(263);
				ifBlock();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(264);
				forBlock();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(265);
				blockBlock();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(266);
				withBlock();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IfBlockContext extends ParserRuleContext {
		public List<TerminalNode> TEMPLATE_JINJA_BLOCK_START() { return getTokens(FlaskTemplateParser.TEMPLATE_JINJA_BLOCK_START); }
		public TerminalNode TEMPLATE_JINJA_BLOCK_START(int i) {
			return getToken(FlaskTemplateParser.TEMPLATE_JINJA_BLOCK_START, i);
		}
		public TerminalNode BLOCK_IF() { return getToken(FlaskTemplateParser.BLOCK_IF, 0); }
		public BlockExpressionContext blockExpression() {
			return getRuleContext(BlockExpressionContext.class,0);
		}
		public List<TerminalNode> BLOCK_END() { return getTokens(FlaskTemplateParser.BLOCK_END); }
		public TerminalNode BLOCK_END(int i) {
			return getToken(FlaskTemplateParser.BLOCK_END, i);
		}
		public TemplateContentContext templateContent() {
			return getRuleContext(TemplateContentContext.class,0);
		}
		public TerminalNode BLOCK_ENDIF() { return getToken(FlaskTemplateParser.BLOCK_ENDIF, 0); }
		public List<ElifClauseContext> elifClause() {
			return getRuleContexts(ElifClauseContext.class);
		}
		public ElifClauseContext elifClause(int i) {
			return getRuleContext(ElifClauseContext.class,i);
		}
		public ElseClauseContext elseClause() {
			return getRuleContext(ElseClauseContext.class,0);
		}
		public IfBlockContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ifBlock; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitIfBlock(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IfBlockContext ifBlock() throws RecognitionException {
		IfBlockContext _localctx = new IfBlockContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_ifBlock);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(269);
			match(TEMPLATE_JINJA_BLOCK_START);
			setState(270);
			match(BLOCK_IF);
			setState(271);
			blockExpression();
			setState(272);
			match(BLOCK_END);
			setState(273);
			templateContent();
			setState(277);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,14,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(274);
					elifClause();
					}
					} 
				}
				setState(279);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,14,_ctx);
			}
			setState(281);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,15,_ctx) ) {
			case 1:
				{
				setState(280);
				elseClause();
				}
				break;
			}
			setState(283);
			match(TEMPLATE_JINJA_BLOCK_START);
			setState(284);
			match(BLOCK_ENDIF);
			setState(285);
			match(BLOCK_END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ElifClauseContext extends ParserRuleContext {
		public TerminalNode TEMPLATE_JINJA_BLOCK_START() { return getToken(FlaskTemplateParser.TEMPLATE_JINJA_BLOCK_START, 0); }
		public TerminalNode BLOCK_ELIF() { return getToken(FlaskTemplateParser.BLOCK_ELIF, 0); }
		public BlockExpressionContext blockExpression() {
			return getRuleContext(BlockExpressionContext.class,0);
		}
		public TerminalNode BLOCK_END() { return getToken(FlaskTemplateParser.BLOCK_END, 0); }
		public TemplateContentContext templateContent() {
			return getRuleContext(TemplateContentContext.class,0);
		}
		public ElifClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_elifClause; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitElifClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ElifClauseContext elifClause() throws RecognitionException {
		ElifClauseContext _localctx = new ElifClauseContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_elifClause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(287);
			match(TEMPLATE_JINJA_BLOCK_START);
			setState(288);
			match(BLOCK_ELIF);
			setState(289);
			blockExpression();
			setState(290);
			match(BLOCK_END);
			setState(291);
			templateContent();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ElseClauseContext extends ParserRuleContext {
		public TerminalNode TEMPLATE_JINJA_BLOCK_START() { return getToken(FlaskTemplateParser.TEMPLATE_JINJA_BLOCK_START, 0); }
		public TerminalNode BLOCK_ELSE() { return getToken(FlaskTemplateParser.BLOCK_ELSE, 0); }
		public TerminalNode BLOCK_END() { return getToken(FlaskTemplateParser.BLOCK_END, 0); }
		public TemplateContentContext templateContent() {
			return getRuleContext(TemplateContentContext.class,0);
		}
		public ElseClauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_elseClause; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitElseClause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ElseClauseContext elseClause() throws RecognitionException {
		ElseClauseContext _localctx = new ElseClauseContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_elseClause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(293);
			match(TEMPLATE_JINJA_BLOCK_START);
			setState(294);
			match(BLOCK_ELSE);
			setState(295);
			match(BLOCK_END);
			setState(296);
			templateContent();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ForBlockContext extends ParserRuleContext {
		public List<TerminalNode> TEMPLATE_JINJA_BLOCK_START() { return getTokens(FlaskTemplateParser.TEMPLATE_JINJA_BLOCK_START); }
		public TerminalNode TEMPLATE_JINJA_BLOCK_START(int i) {
			return getToken(FlaskTemplateParser.TEMPLATE_JINJA_BLOCK_START, i);
		}
		public TerminalNode BLOCK_FOR() { return getToken(FlaskTemplateParser.BLOCK_FOR, 0); }
		public TerminalNode BLOCK_ID() { return getToken(FlaskTemplateParser.BLOCK_ID, 0); }
		public TerminalNode BLOCK_IN() { return getToken(FlaskTemplateParser.BLOCK_IN, 0); }
		public BlockExpressionContext blockExpression() {
			return getRuleContext(BlockExpressionContext.class,0);
		}
		public List<TerminalNode> BLOCK_END() { return getTokens(FlaskTemplateParser.BLOCK_END); }
		public TerminalNode BLOCK_END(int i) {
			return getToken(FlaskTemplateParser.BLOCK_END, i);
		}
		public TemplateContentContext templateContent() {
			return getRuleContext(TemplateContentContext.class,0);
		}
		public TerminalNode BLOCK_ENDFOR() { return getToken(FlaskTemplateParser.BLOCK_ENDFOR, 0); }
		public ElseClauseContext elseClause() {
			return getRuleContext(ElseClauseContext.class,0);
		}
		public ForBlockContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_forBlock; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitForBlock(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ForBlockContext forBlock() throws RecognitionException {
		ForBlockContext _localctx = new ForBlockContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_forBlock);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(298);
			match(TEMPLATE_JINJA_BLOCK_START);
			setState(299);
			match(BLOCK_FOR);
			setState(300);
			match(BLOCK_ID);
			setState(301);
			match(BLOCK_IN);
			setState(302);
			blockExpression();
			setState(303);
			match(BLOCK_END);
			setState(304);
			templateContent();
			setState(306);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,16,_ctx) ) {
			case 1:
				{
				setState(305);
				elseClause();
				}
				break;
			}
			setState(308);
			match(TEMPLATE_JINJA_BLOCK_START);
			setState(309);
			match(BLOCK_ENDFOR);
			setState(310);
			match(BLOCK_END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BlockBlockContext extends ParserRuleContext {
		public List<TerminalNode> TEMPLATE_JINJA_BLOCK_START() { return getTokens(FlaskTemplateParser.TEMPLATE_JINJA_BLOCK_START); }
		public TerminalNode TEMPLATE_JINJA_BLOCK_START(int i) {
			return getToken(FlaskTemplateParser.TEMPLATE_JINJA_BLOCK_START, i);
		}
		public TerminalNode BLOCK_BLOCK() { return getToken(FlaskTemplateParser.BLOCK_BLOCK, 0); }
		public List<TerminalNode> BLOCK_ID() { return getTokens(FlaskTemplateParser.BLOCK_ID); }
		public TerminalNode BLOCK_ID(int i) {
			return getToken(FlaskTemplateParser.BLOCK_ID, i);
		}
		public List<TerminalNode> BLOCK_END() { return getTokens(FlaskTemplateParser.BLOCK_END); }
		public TerminalNode BLOCK_END(int i) {
			return getToken(FlaskTemplateParser.BLOCK_END, i);
		}
		public TemplateContentContext templateContent() {
			return getRuleContext(TemplateContentContext.class,0);
		}
		public TerminalNode BLOCK_ENDBLOCK() { return getToken(FlaskTemplateParser.BLOCK_ENDBLOCK, 0); }
		public BlockBlockContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_blockBlock; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockBlock(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockBlockContext blockBlock() throws RecognitionException {
		BlockBlockContext _localctx = new BlockBlockContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_blockBlock);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(312);
			match(TEMPLATE_JINJA_BLOCK_START);
			setState(313);
			match(BLOCK_BLOCK);
			setState(314);
			match(BLOCK_ID);
			setState(315);
			match(BLOCK_END);
			setState(316);
			templateContent();
			setState(317);
			match(TEMPLATE_JINJA_BLOCK_START);
			setState(318);
			match(BLOCK_ENDBLOCK);
			setState(320);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==BLOCK_ID) {
				{
				setState(319);
				match(BLOCK_ID);
				}
			}

			setState(322);
			match(BLOCK_END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class WithBlockContext extends ParserRuleContext {
		public List<TerminalNode> TEMPLATE_JINJA_BLOCK_START() { return getTokens(FlaskTemplateParser.TEMPLATE_JINJA_BLOCK_START); }
		public TerminalNode TEMPLATE_JINJA_BLOCK_START(int i) {
			return getToken(FlaskTemplateParser.TEMPLATE_JINJA_BLOCK_START, i);
		}
		public TerminalNode BLOCK_WITH() { return getToken(FlaskTemplateParser.BLOCK_WITH, 0); }
		public BlockExpressionContext blockExpression() {
			return getRuleContext(BlockExpressionContext.class,0);
		}
		public List<TerminalNode> BLOCK_END() { return getTokens(FlaskTemplateParser.BLOCK_END); }
		public TerminalNode BLOCK_END(int i) {
			return getToken(FlaskTemplateParser.BLOCK_END, i);
		}
		public TemplateContentContext templateContent() {
			return getRuleContext(TemplateContentContext.class,0);
		}
		public TerminalNode BLOCK_ENDWITH() { return getToken(FlaskTemplateParser.BLOCK_ENDWITH, 0); }
		public TerminalNode BLOCK_ID() { return getToken(FlaskTemplateParser.BLOCK_ID, 0); }
		public TerminalNode BLOCK_EQ() { return getToken(FlaskTemplateParser.BLOCK_EQ, 0); }
		public WithBlockContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_withBlock; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitWithBlock(this);
			else return visitor.visitChildren(this);
		}
	}

	public final WithBlockContext withBlock() throws RecognitionException {
		WithBlockContext _localctx = new WithBlockContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_withBlock);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(324);
			match(TEMPLATE_JINJA_BLOCK_START);
			setState(325);
			match(BLOCK_WITH);
			setState(328);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,18,_ctx) ) {
			case 1:
				{
				setState(326);
				match(BLOCK_ID);
				setState(327);
				match(BLOCK_EQ);
				}
				break;
			}
			setState(330);
			blockExpression();
			setState(331);
			match(BLOCK_END);
			setState(332);
			templateContent();
			setState(333);
			match(TEMPLATE_JINJA_BLOCK_START);
			setState(334);
			match(BLOCK_ENDWITH);
			setState(335);
			match(BLOCK_END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JinjaTagContext extends ParserRuleContext {
		public JinjaTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jinjaTag; }
	 
		public JinjaTagContext() { }
		public void copyFrom(JinjaTagContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class JinjaTagNodeContext extends JinjaTagContext {
		public TerminalNode TEMPLATE_JINJA_BLOCK_START() { return getToken(FlaskTemplateParser.TEMPLATE_JINJA_BLOCK_START, 0); }
		public JinjaTagStatementContext jinjaTagStatement() {
			return getRuleContext(JinjaTagStatementContext.class,0);
		}
		public TerminalNode BLOCK_END() { return getToken(FlaskTemplateParser.BLOCK_END, 0); }
		public JinjaTagNodeContext(JinjaTagContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitJinjaTagNode(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JinjaTagContext jinjaTag() throws RecognitionException {
		JinjaTagContext _localctx = new JinjaTagContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_jinjaTag);
		try {
			_localctx = new JinjaTagNodeContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(337);
			match(TEMPLATE_JINJA_BLOCK_START);
			setState(338);
			jinjaTagStatement();
			setState(339);
			match(BLOCK_END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JinjaTagStatementContext extends ParserRuleContext {
		public JinjaTagStatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jinjaTagStatement; }
	 
		public JinjaTagStatementContext() { }
		public void copyFrom(JinjaTagStatementContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FromImportBlockContext extends JinjaTagStatementContext {
		public TerminalNode BLOCK_FROM() { return getToken(FlaskTemplateParser.BLOCK_FROM, 0); }
		public TerminalNode BLOCK_STRING() { return getToken(FlaskTemplateParser.BLOCK_STRING, 0); }
		public TerminalNode BLOCK_IMPORT() { return getToken(FlaskTemplateParser.BLOCK_IMPORT, 0); }
		public ImportListContext importList() {
			return getRuleContext(ImportListContext.class,0);
		}
		public FromImportBlockContext(JinjaTagStatementContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitFromImportBlock(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ExtendsBlockContext extends JinjaTagStatementContext {
		public TerminalNode BLOCK_EXTENDS() { return getToken(FlaskTemplateParser.BLOCK_EXTENDS, 0); }
		public TerminalNode BLOCK_STRING() { return getToken(FlaskTemplateParser.BLOCK_STRING, 0); }
		public ExtendsBlockContext(JinjaTagStatementContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitExtendsBlock(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SetBlockContext extends JinjaTagStatementContext {
		public TerminalNode BLOCK_SET() { return getToken(FlaskTemplateParser.BLOCK_SET, 0); }
		public TerminalNode BLOCK_ID() { return getToken(FlaskTemplateParser.BLOCK_ID, 0); }
		public TerminalNode BLOCK_EQ() { return getToken(FlaskTemplateParser.BLOCK_EQ, 0); }
		public BlockExpressionContext blockExpression() {
			return getRuleContext(BlockExpressionContext.class,0);
		}
		public SetBlockContext(JinjaTagStatementContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitSetBlock(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ImportBlockContext extends JinjaTagStatementContext {
		public TerminalNode BLOCK_IMPORT() { return getToken(FlaskTemplateParser.BLOCK_IMPORT, 0); }
		public TerminalNode BLOCK_STRING() { return getToken(FlaskTemplateParser.BLOCK_STRING, 0); }
		public TerminalNode BLOCK_AS() { return getToken(FlaskTemplateParser.BLOCK_AS, 0); }
		public TerminalNode BLOCK_ID() { return getToken(FlaskTemplateParser.BLOCK_ID, 0); }
		public ImportBlockContext(JinjaTagStatementContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitImportBlock(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class IncludeBlockContext extends JinjaTagStatementContext {
		public TerminalNode BLOCK_INCLUDE() { return getToken(FlaskTemplateParser.BLOCK_INCLUDE, 0); }
		public TerminalNode BLOCK_STRING() { return getToken(FlaskTemplateParser.BLOCK_STRING, 0); }
		public IncludeBlockContext(JinjaTagStatementContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitIncludeBlock(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class GenericBlockContext extends JinjaTagStatementContext {
		public TerminalNode BLOCK_ID() { return getToken(FlaskTemplateParser.BLOCK_ID, 0); }
		public TerminalNode BLOCK_EQ() { return getToken(FlaskTemplateParser.BLOCK_EQ, 0); }
		public BlockExpressionContext blockExpression() {
			return getRuleContext(BlockExpressionContext.class,0);
		}
		public GenericBlockContext(JinjaTagStatementContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitGenericBlock(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JinjaTagStatementContext jinjaTagStatement() throws RecognitionException {
		JinjaTagStatementContext _localctx = new JinjaTagStatementContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_jinjaTagStatement);
		int _la;
		try {
			setState(364);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case BLOCK_SET:
				_localctx = new SetBlockContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(341);
				match(BLOCK_SET);
				setState(342);
				match(BLOCK_ID);
				setState(343);
				match(BLOCK_EQ);
				setState(344);
				blockExpression();
				}
				break;
			case BLOCK_INCLUDE:
				_localctx = new IncludeBlockContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(345);
				match(BLOCK_INCLUDE);
				setState(346);
				match(BLOCK_STRING);
				}
				break;
			case BLOCK_IMPORT:
				_localctx = new ImportBlockContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(347);
				match(BLOCK_IMPORT);
				setState(348);
				match(BLOCK_STRING);
				setState(351);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==BLOCK_AS) {
					{
					setState(349);
					match(BLOCK_AS);
					setState(350);
					match(BLOCK_ID);
					}
				}

				}
				break;
			case BLOCK_FROM:
				_localctx = new FromImportBlockContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(353);
				match(BLOCK_FROM);
				setState(354);
				match(BLOCK_STRING);
				setState(355);
				match(BLOCK_IMPORT);
				setState(356);
				importList();
				}
				break;
			case BLOCK_EXTENDS:
				_localctx = new ExtendsBlockContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(357);
				match(BLOCK_EXTENDS);
				setState(358);
				match(BLOCK_STRING);
				}
				break;
			case BLOCK_ID:
				_localctx = new GenericBlockContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(359);
				match(BLOCK_ID);
				setState(362);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==BLOCK_EQ) {
					{
					setState(360);
					match(BLOCK_EQ);
					setState(361);
					blockExpression();
					}
				}

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BlockExpressionContext extends ParserRuleContext {
		public BlockLogicalOrExpressionContext blockLogicalOrExpression() {
			return getRuleContext(BlockLogicalOrExpressionContext.class,0);
		}
		public BlockExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_blockExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockExpressionContext blockExpression() throws RecognitionException {
		BlockExpressionContext _localctx = new BlockExpressionContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_blockExpression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(366);
			blockLogicalOrExpression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BlockLogicalOrExpressionContext extends ParserRuleContext {
		public List<BlockLogicalAndExpressionContext> blockLogicalAndExpression() {
			return getRuleContexts(BlockLogicalAndExpressionContext.class);
		}
		public BlockLogicalAndExpressionContext blockLogicalAndExpression(int i) {
			return getRuleContext(BlockLogicalAndExpressionContext.class,i);
		}
		public List<TerminalNode> BLOCK_OR() { return getTokens(FlaskTemplateParser.BLOCK_OR); }
		public TerminalNode BLOCK_OR(int i) {
			return getToken(FlaskTemplateParser.BLOCK_OR, i);
		}
		public BlockLogicalOrExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_blockLogicalOrExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockLogicalOrExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockLogicalOrExpressionContext blockLogicalOrExpression() throws RecognitionException {
		BlockLogicalOrExpressionContext _localctx = new BlockLogicalOrExpressionContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_blockLogicalOrExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(368);
			blockLogicalAndExpression();
			setState(373);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==BLOCK_OR) {
				{
				{
				setState(369);
				match(BLOCK_OR);
				setState(370);
				blockLogicalAndExpression();
				}
				}
				setState(375);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BlockLogicalAndExpressionContext extends ParserRuleContext {
		public List<BlockEqualityExpressionContext> blockEqualityExpression() {
			return getRuleContexts(BlockEqualityExpressionContext.class);
		}
		public BlockEqualityExpressionContext blockEqualityExpression(int i) {
			return getRuleContext(BlockEqualityExpressionContext.class,i);
		}
		public List<TerminalNode> BLOCK_AND() { return getTokens(FlaskTemplateParser.BLOCK_AND); }
		public TerminalNode BLOCK_AND(int i) {
			return getToken(FlaskTemplateParser.BLOCK_AND, i);
		}
		public BlockLogicalAndExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_blockLogicalAndExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockLogicalAndExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockLogicalAndExpressionContext blockLogicalAndExpression() throws RecognitionException {
		BlockLogicalAndExpressionContext _localctx = new BlockLogicalAndExpressionContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_blockLogicalAndExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(376);
			blockEqualityExpression();
			setState(381);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==BLOCK_AND) {
				{
				{
				setState(377);
				match(BLOCK_AND);
				setState(378);
				blockEqualityExpression();
				}
				}
				setState(383);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BlockEqualityExpressionContext extends ParserRuleContext {
		public List<BlockComparisonExpressionContext> blockComparisonExpression() {
			return getRuleContexts(BlockComparisonExpressionContext.class);
		}
		public BlockComparisonExpressionContext blockComparisonExpression(int i) {
			return getRuleContext(BlockComparisonExpressionContext.class,i);
		}
		public List<TerminalNode> BLOCK_EQEQ() { return getTokens(FlaskTemplateParser.BLOCK_EQEQ); }
		public TerminalNode BLOCK_EQEQ(int i) {
			return getToken(FlaskTemplateParser.BLOCK_EQEQ, i);
		}
		public List<TerminalNode> BLOCK_NEQ() { return getTokens(FlaskTemplateParser.BLOCK_NEQ); }
		public TerminalNode BLOCK_NEQ(int i) {
			return getToken(FlaskTemplateParser.BLOCK_NEQ, i);
		}
		public BlockEqualityExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_blockEqualityExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockEqualityExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockEqualityExpressionContext blockEqualityExpression() throws RecognitionException {
		BlockEqualityExpressionContext _localctx = new BlockEqualityExpressionContext(_ctx, getState());
		enterRule(_localctx, 62, RULE_blockEqualityExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(384);
			blockComparisonExpression();
			setState(389);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==BLOCK_EQEQ || _la==BLOCK_NEQ) {
				{
				{
				setState(385);
				_la = _input.LA(1);
				if ( !(_la==BLOCK_EQEQ || _la==BLOCK_NEQ) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(386);
				blockComparisonExpression();
				}
				}
				setState(391);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BlockComparisonExpressionContext extends ParserRuleContext {
		public List<BlockAdditiveExpressionContext> blockAdditiveExpression() {
			return getRuleContexts(BlockAdditiveExpressionContext.class);
		}
		public BlockAdditiveExpressionContext blockAdditiveExpression(int i) {
			return getRuleContext(BlockAdditiveExpressionContext.class,i);
		}
		public List<TerminalNode> BLOCK_LT() { return getTokens(FlaskTemplateParser.BLOCK_LT); }
		public TerminalNode BLOCK_LT(int i) {
			return getToken(FlaskTemplateParser.BLOCK_LT, i);
		}
		public List<TerminalNode> BLOCK_LTE() { return getTokens(FlaskTemplateParser.BLOCK_LTE); }
		public TerminalNode BLOCK_LTE(int i) {
			return getToken(FlaskTemplateParser.BLOCK_LTE, i);
		}
		public List<TerminalNode> BLOCK_GT() { return getTokens(FlaskTemplateParser.BLOCK_GT); }
		public TerminalNode BLOCK_GT(int i) {
			return getToken(FlaskTemplateParser.BLOCK_GT, i);
		}
		public List<TerminalNode> BLOCK_GTE() { return getTokens(FlaskTemplateParser.BLOCK_GTE); }
		public TerminalNode BLOCK_GTE(int i) {
			return getToken(FlaskTemplateParser.BLOCK_GTE, i);
		}
		public List<TerminalNode> BLOCK_IN() { return getTokens(FlaskTemplateParser.BLOCK_IN); }
		public TerminalNode BLOCK_IN(int i) {
			return getToken(FlaskTemplateParser.BLOCK_IN, i);
		}
		public List<TerminalNode> BLOCK_IS() { return getTokens(FlaskTemplateParser.BLOCK_IS); }
		public TerminalNode BLOCK_IS(int i) {
			return getToken(FlaskTemplateParser.BLOCK_IS, i);
		}
		public BlockComparisonExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_blockComparisonExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockComparisonExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockComparisonExpressionContext blockComparisonExpression() throws RecognitionException {
		BlockComparisonExpressionContext _localctx = new BlockComparisonExpressionContext(_ctx, getState());
		enterRule(_localctx, 64, RULE_blockComparisonExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(392);
			blockAdditiveExpression();
			setState(397);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & 540435253819342848L) != 0)) {
				{
				{
				setState(393);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 540435253819342848L) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(394);
				blockAdditiveExpression();
				}
				}
				setState(399);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BlockAdditiveExpressionContext extends ParserRuleContext {
		public List<BlockMultiplicativeExpressionContext> blockMultiplicativeExpression() {
			return getRuleContexts(BlockMultiplicativeExpressionContext.class);
		}
		public BlockMultiplicativeExpressionContext blockMultiplicativeExpression(int i) {
			return getRuleContext(BlockMultiplicativeExpressionContext.class,i);
		}
		public List<TerminalNode> BLOCK_PLUS() { return getTokens(FlaskTemplateParser.BLOCK_PLUS); }
		public TerminalNode BLOCK_PLUS(int i) {
			return getToken(FlaskTemplateParser.BLOCK_PLUS, i);
		}
		public List<TerminalNode> BLOCK_MINUS() { return getTokens(FlaskTemplateParser.BLOCK_MINUS); }
		public TerminalNode BLOCK_MINUS(int i) {
			return getToken(FlaskTemplateParser.BLOCK_MINUS, i);
		}
		public BlockAdditiveExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_blockAdditiveExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockAdditiveExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockAdditiveExpressionContext blockAdditiveExpression() throws RecognitionException {
		BlockAdditiveExpressionContext _localctx = new BlockAdditiveExpressionContext(_ctx, getState());
		enterRule(_localctx, 66, RULE_blockAdditiveExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(400);
			blockMultiplicativeExpression();
			setState(405);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==BLOCK_PLUS || _la==BLOCK_MINUS) {
				{
				{
				setState(401);
				_la = _input.LA(1);
				if ( !(_la==BLOCK_PLUS || _la==BLOCK_MINUS) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(402);
				blockMultiplicativeExpression();
				}
				}
				setState(407);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BlockMultiplicativeExpressionContext extends ParserRuleContext {
		public List<BlockUnaryExpressionContext> blockUnaryExpression() {
			return getRuleContexts(BlockUnaryExpressionContext.class);
		}
		public BlockUnaryExpressionContext blockUnaryExpression(int i) {
			return getRuleContext(BlockUnaryExpressionContext.class,i);
		}
		public List<TerminalNode> BLOCK_STAR() { return getTokens(FlaskTemplateParser.BLOCK_STAR); }
		public TerminalNode BLOCK_STAR(int i) {
			return getToken(FlaskTemplateParser.BLOCK_STAR, i);
		}
		public List<TerminalNode> BLOCK_SLASH() { return getTokens(FlaskTemplateParser.BLOCK_SLASH); }
		public TerminalNode BLOCK_SLASH(int i) {
			return getToken(FlaskTemplateParser.BLOCK_SLASH, i);
		}
		public List<TerminalNode> BLOCK_PERCENT() { return getTokens(FlaskTemplateParser.BLOCK_PERCENT); }
		public TerminalNode BLOCK_PERCENT(int i) {
			return getToken(FlaskTemplateParser.BLOCK_PERCENT, i);
		}
		public BlockMultiplicativeExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_blockMultiplicativeExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockMultiplicativeExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockMultiplicativeExpressionContext blockMultiplicativeExpression() throws RecognitionException {
		BlockMultiplicativeExpressionContext _localctx = new BlockMultiplicativeExpressionContext(_ctx, getState());
		enterRule(_localctx, 68, RULE_blockMultiplicativeExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(408);
			blockUnaryExpression();
			setState(413);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & -2305843009213693952L) != 0)) {
				{
				{
				setState(409);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & -2305843009213693952L) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(410);
				blockUnaryExpression();
				}
				}
				setState(415);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BlockUnaryExpressionContext extends ParserRuleContext {
		public BlockUnaryExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_blockUnaryExpression; }
	 
		public BlockUnaryExpressionContext() { }
		public void copyFrom(BlockUnaryExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BlockUnaryBaseContext extends BlockUnaryExpressionContext {
		public BlockPrimaryExpressionContext blockPrimaryExpression() {
			return getRuleContext(BlockPrimaryExpressionContext.class,0);
		}
		public BlockUnaryBaseContext(BlockUnaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockUnaryBase(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BlockUnaryOpContext extends BlockUnaryExpressionContext {
		public BlockUnaryExpressionContext blockUnaryExpression() {
			return getRuleContext(BlockUnaryExpressionContext.class,0);
		}
		public TerminalNode BLOCK_PLUS() { return getToken(FlaskTemplateParser.BLOCK_PLUS, 0); }
		public TerminalNode BLOCK_MINUS() { return getToken(FlaskTemplateParser.BLOCK_MINUS, 0); }
		public TerminalNode BLOCK_NOT() { return getToken(FlaskTemplateParser.BLOCK_NOT, 0); }
		public BlockUnaryOpContext(BlockUnaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockUnaryOp(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockUnaryExpressionContext blockUnaryExpression() throws RecognitionException {
		BlockUnaryExpressionContext _localctx = new BlockUnaryExpressionContext(_ctx, getState());
		enterRule(_localctx, 70, RULE_blockUnaryExpression);
		int _la;
		try {
			setState(419);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case BLOCK_NOT:
			case BLOCK_PLUS:
			case BLOCK_MINUS:
				_localctx = new BlockUnaryOpContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(416);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 1733885856537640960L) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(417);
				blockUnaryExpression();
				}
				break;
			case BLOCK_LPAREN:
			case BLOCK_TRUE:
			case BLOCK_FALSE:
			case BLOCK_NONE:
			case BLOCK_LBRACK:
			case BLOCK_LBRACE:
			case BLOCK_ID:
			case BLOCK_STRING:
			case BLOCK_NUMBER:
				_localctx = new BlockUnaryBaseContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(418);
				blockPrimaryExpression();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BlockPrimaryExpressionContext extends ParserRuleContext {
		public BlockPrimaryExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_blockPrimaryExpression; }
	 
		public BlockPrimaryExpressionContext() { }
		public void copyFrom(BlockPrimaryExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BlockPrimaryContext extends BlockPrimaryExpressionContext {
		public BlockAtomContext blockAtom() {
			return getRuleContext(BlockAtomContext.class,0);
		}
		public List<BlockPostfixContext> blockPostfix() {
			return getRuleContexts(BlockPostfixContext.class);
		}
		public BlockPostfixContext blockPostfix(int i) {
			return getRuleContext(BlockPostfixContext.class,i);
		}
		public BlockPrimaryContext(BlockPrimaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockPrimary(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockPrimaryExpressionContext blockPrimaryExpression() throws RecognitionException {
		BlockPrimaryExpressionContext _localctx = new BlockPrimaryExpressionContext(_ctx, getState());
		enterRule(_localctx, 72, RULE_blockPrimaryExpression);
		int _la;
		try {
			_localctx = new BlockPrimaryContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(421);
			blockAtom();
			setState(425);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((((_la - 46)) & ~0x3f) == 0 && ((1L << (_la - 46)) & 18087937L) != 0)) {
				{
				{
				setState(422);
				blockPostfix();
				}
				}
				setState(427);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BlockAtomContext extends ParserRuleContext {
		public BlockAtomContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_blockAtom; }
	 
		public BlockAtomContext() { }
		public void copyFrom(BlockAtomContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BlockNoneLiteralContext extends BlockAtomContext {
		public TerminalNode BLOCK_NONE() { return getToken(FlaskTemplateParser.BLOCK_NONE, 0); }
		public BlockNoneLiteralContext(BlockAtomContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockNoneLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BlockIdentifierContext extends BlockAtomContext {
		public TerminalNode BLOCK_ID() { return getToken(FlaskTemplateParser.BLOCK_ID, 0); }
		public BlockIdentifierContext(BlockAtomContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockIdentifier(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BlockListLiteralContext extends BlockAtomContext {
		public TerminalNode BLOCK_LBRACK() { return getToken(FlaskTemplateParser.BLOCK_LBRACK, 0); }
		public TerminalNode BLOCK_RBRACK() { return getToken(FlaskTemplateParser.BLOCK_RBRACK, 0); }
		public BlockExpressionListContext blockExpressionList() {
			return getRuleContext(BlockExpressionListContext.class,0);
		}
		public BlockListLiteralContext(BlockAtomContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockListLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BlockTrueLiteralContext extends BlockAtomContext {
		public TerminalNode BLOCK_TRUE() { return getToken(FlaskTemplateParser.BLOCK_TRUE, 0); }
		public BlockTrueLiteralContext(BlockAtomContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockTrueLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BlockStringLiteralContext extends BlockAtomContext {
		public TerminalNode BLOCK_STRING() { return getToken(FlaskTemplateParser.BLOCK_STRING, 0); }
		public BlockStringLiteralContext(BlockAtomContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockStringLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BlockDictLiteralContext extends BlockAtomContext {
		public TerminalNode BLOCK_LBRACE() { return getToken(FlaskTemplateParser.BLOCK_LBRACE, 0); }
		public TerminalNode BLOCK_RBRACE() { return getToken(FlaskTemplateParser.BLOCK_RBRACE, 0); }
		public BlockDictPairListContext blockDictPairList() {
			return getRuleContext(BlockDictPairListContext.class,0);
		}
		public BlockDictLiteralContext(BlockAtomContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockDictLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BlockParenExprContext extends BlockAtomContext {
		public TerminalNode BLOCK_LPAREN() { return getToken(FlaskTemplateParser.BLOCK_LPAREN, 0); }
		public BlockExpressionContext blockExpression() {
			return getRuleContext(BlockExpressionContext.class,0);
		}
		public TerminalNode BLOCK_RPAREN() { return getToken(FlaskTemplateParser.BLOCK_RPAREN, 0); }
		public BlockParenExprContext(BlockAtomContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockParenExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BlockFalseLiteralContext extends BlockAtomContext {
		public TerminalNode BLOCK_FALSE() { return getToken(FlaskTemplateParser.BLOCK_FALSE, 0); }
		public BlockFalseLiteralContext(BlockAtomContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockFalseLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BlockNumberLiteralContext extends BlockAtomContext {
		public TerminalNode BLOCK_NUMBER() { return getToken(FlaskTemplateParser.BLOCK_NUMBER, 0); }
		public BlockNumberLiteralContext(BlockAtomContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockNumberLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockAtomContext blockAtom() throws RecognitionException {
		BlockAtomContext _localctx = new BlockAtomContext(_ctx, getState());
		enterRule(_localctx, 74, RULE_blockAtom);
		int _la;
		try {
			setState(448);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case BLOCK_LPAREN:
				_localctx = new BlockParenExprContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(428);
				match(BLOCK_LPAREN);
				setState(429);
				blockExpression();
				setState(430);
				match(BLOCK_RPAREN);
				}
				break;
			case BLOCK_ID:
				_localctx = new BlockIdentifierContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(432);
				match(BLOCK_ID);
				}
				break;
			case BLOCK_STRING:
				_localctx = new BlockStringLiteralContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(433);
				match(BLOCK_STRING);
				}
				break;
			case BLOCK_NUMBER:
				_localctx = new BlockNumberLiteralContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(434);
				match(BLOCK_NUMBER);
				}
				break;
			case BLOCK_TRUE:
				_localctx = new BlockTrueLiteralContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(435);
				match(BLOCK_TRUE);
				}
				break;
			case BLOCK_FALSE:
				_localctx = new BlockFalseLiteralContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(436);
				match(BLOCK_FALSE);
				}
				break;
			case BLOCK_NONE:
				_localctx = new BlockNoneLiteralContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(437);
				match(BLOCK_NONE);
				}
				break;
			case BLOCK_LBRACK:
				_localctx = new BlockListLiteralContext(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(438);
				match(BLOCK_LBRACK);
				setState(440);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (((((_la - 52)) & ~0x3f) == 0 && ((1L << (_la - 52)) & 60264833L) != 0)) {
					{
					setState(439);
					blockExpressionList();
					}
				}

				setState(442);
				match(BLOCK_RBRACK);
				}
				break;
			case BLOCK_LBRACE:
				_localctx = new BlockDictLiteralContext(_localctx);
				enterOuterAlt(_localctx, 9);
				{
				setState(443);
				match(BLOCK_LBRACE);
				setState(445);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (((((_la - 52)) & ~0x3f) == 0 && ((1L << (_la - 52)) & 60264833L) != 0)) {
					{
					setState(444);
					blockDictPairList();
					}
				}

				setState(447);
				match(BLOCK_RBRACE);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BlockPostfixContext extends ParserRuleContext {
		public BlockPostfixContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_blockPostfix; }
	 
		public BlockPostfixContext() { }
		public void copyFrom(BlockPostfixContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BlockIndexOpContext extends BlockPostfixContext {
		public TerminalNode BLOCK_LBRACK() { return getToken(FlaskTemplateParser.BLOCK_LBRACK, 0); }
		public BlockSliceItemContext blockSliceItem() {
			return getRuleContext(BlockSliceItemContext.class,0);
		}
		public TerminalNode BLOCK_RBRACK() { return getToken(FlaskTemplateParser.BLOCK_RBRACK, 0); }
		public BlockIndexOpContext(BlockPostfixContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockIndexOp(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BlockMemberOpContext extends BlockPostfixContext {
		public TerminalNode BLOCK_DOT() { return getToken(FlaskTemplateParser.BLOCK_DOT, 0); }
		public TerminalNode BLOCK_ID() { return getToken(FlaskTemplateParser.BLOCK_ID, 0); }
		public BlockMemberOpContext(BlockPostfixContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockMemberOp(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BlockFilterOpContext extends BlockPostfixContext {
		public TerminalNode BLOCK_PIPE() { return getToken(FlaskTemplateParser.BLOCK_PIPE, 0); }
		public TerminalNode BLOCK_ID() { return getToken(FlaskTemplateParser.BLOCK_ID, 0); }
		public TerminalNode BLOCK_LPAREN() { return getToken(FlaskTemplateParser.BLOCK_LPAREN, 0); }
		public TerminalNode BLOCK_RPAREN() { return getToken(FlaskTemplateParser.BLOCK_RPAREN, 0); }
		public BlockArgumentListContext blockArgumentList() {
			return getRuleContext(BlockArgumentListContext.class,0);
		}
		public BlockFilterOpContext(BlockPostfixContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockFilterOp(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BlockCallOpContext extends BlockPostfixContext {
		public TerminalNode BLOCK_LPAREN() { return getToken(FlaskTemplateParser.BLOCK_LPAREN, 0); }
		public TerminalNode BLOCK_RPAREN() { return getToken(FlaskTemplateParser.BLOCK_RPAREN, 0); }
		public BlockArgumentListContext blockArgumentList() {
			return getRuleContext(BlockArgumentListContext.class,0);
		}
		public BlockCallOpContext(BlockPostfixContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockCallOp(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockPostfixContext blockPostfix() throws RecognitionException {
		BlockPostfixContext _localctx = new BlockPostfixContext(_ctx, getState());
		enterRule(_localctx, 76, RULE_blockPostfix);
		int _la;
		try {
			setState(470);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case BLOCK_PIPE:
				_localctx = new BlockFilterOpContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(450);
				match(BLOCK_PIPE);
				setState(451);
				match(BLOCK_ID);
				setState(457);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,34,_ctx) ) {
				case 1:
					{
					setState(452);
					match(BLOCK_LPAREN);
					setState(454);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if (((((_la - 52)) & ~0x3f) == 0 && ((1L << (_la - 52)) & 60264833L) != 0)) {
						{
						setState(453);
						blockArgumentList();
						}
					}

					setState(456);
					match(BLOCK_RPAREN);
					}
					break;
				}
				}
				break;
			case BLOCK_LPAREN:
				_localctx = new BlockCallOpContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(459);
				match(BLOCK_LPAREN);
				setState(461);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (((((_la - 52)) & ~0x3f) == 0 && ((1L << (_la - 52)) & 60264833L) != 0)) {
					{
					setState(460);
					blockArgumentList();
					}
				}

				setState(463);
				match(BLOCK_RPAREN);
				}
				break;
			case BLOCK_DOT:
				_localctx = new BlockMemberOpContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(464);
				match(BLOCK_DOT);
				setState(465);
				match(BLOCK_ID);
				}
				break;
			case BLOCK_LBRACK:
				_localctx = new BlockIndexOpContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(466);
				match(BLOCK_LBRACK);
				setState(467);
				blockSliceItem();
				setState(468);
				match(BLOCK_RBRACK);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BlockSliceItemContext extends ParserRuleContext {
		public BlockSliceItemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_blockSliceItem; }
	 
		public BlockSliceItemContext() { }
		public void copyFrom(BlockSliceItemContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BlockIndexContext extends BlockSliceItemContext {
		public BlockExpressionContext blockExpression() {
			return getRuleContext(BlockExpressionContext.class,0);
		}
		public BlockIndexContext(BlockSliceItemContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockIndex(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BlockSliceContext extends BlockSliceItemContext {
		public List<TerminalNode> BLOCK_COLON() { return getTokens(FlaskTemplateParser.BLOCK_COLON); }
		public TerminalNode BLOCK_COLON(int i) {
			return getToken(FlaskTemplateParser.BLOCK_COLON, i);
		}
		public List<BlockExpressionContext> blockExpression() {
			return getRuleContexts(BlockExpressionContext.class);
		}
		public BlockExpressionContext blockExpression(int i) {
			return getRuleContext(BlockExpressionContext.class,i);
		}
		public BlockSliceContext(BlockSliceItemContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockSlice(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockSliceItemContext blockSliceItem() throws RecognitionException {
		BlockSliceItemContext _localctx = new BlockSliceItemContext(_ctx, getState());
		enterRule(_localctx, 78, RULE_blockSliceItem);
		int _la;
		try {
			setState(486);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,41,_ctx) ) {
			case 1:
				_localctx = new BlockIndexContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(472);
				blockExpression();
				}
				break;
			case 2:
				_localctx = new BlockSliceContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(474);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (((((_la - 52)) & ~0x3f) == 0 && ((1L << (_la - 52)) & 60264833L) != 0)) {
					{
					setState(473);
					blockExpression();
					}
				}

				setState(476);
				match(BLOCK_COLON);
				setState(478);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (((((_la - 52)) & ~0x3f) == 0 && ((1L << (_la - 52)) & 60264833L) != 0)) {
					{
					setState(477);
					blockExpression();
					}
				}

				setState(484);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==BLOCK_COLON) {
					{
					setState(480);
					match(BLOCK_COLON);
					setState(482);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if (((((_la - 52)) & ~0x3f) == 0 && ((1L << (_la - 52)) & 60264833L) != 0)) {
						{
						setState(481);
						blockExpression();
						}
					}

					}
				}

				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BlockArgumentListContext extends ParserRuleContext {
		public List<BlockArgumentContext> blockArgument() {
			return getRuleContexts(BlockArgumentContext.class);
		}
		public BlockArgumentContext blockArgument(int i) {
			return getRuleContext(BlockArgumentContext.class,i);
		}
		public List<TerminalNode> BLOCK_COMMA() { return getTokens(FlaskTemplateParser.BLOCK_COMMA); }
		public TerminalNode BLOCK_COMMA(int i) {
			return getToken(FlaskTemplateParser.BLOCK_COMMA, i);
		}
		public BlockArgumentListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_blockArgumentList; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockArgumentList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockArgumentListContext blockArgumentList() throws RecognitionException {
		BlockArgumentListContext _localctx = new BlockArgumentListContext(_ctx, getState());
		enterRule(_localctx, 80, RULE_blockArgumentList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(488);
			blockArgument();
			setState(493);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==BLOCK_COMMA) {
				{
				{
				setState(489);
				match(BLOCK_COMMA);
				setState(490);
				blockArgument();
				}
				}
				setState(495);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BlockArgumentContext extends ParserRuleContext {
		public BlockArgumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_blockArgument; }
	 
		public BlockArgumentContext() { }
		public void copyFrom(BlockArgumentContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BlockPositionalArgumentContext extends BlockArgumentContext {
		public BlockExpressionContext blockExpression() {
			return getRuleContext(BlockExpressionContext.class,0);
		}
		public BlockPositionalArgumentContext(BlockArgumentContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockPositionalArgument(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BlockKeywordArgumentContext extends BlockArgumentContext {
		public TerminalNode BLOCK_ID() { return getToken(FlaskTemplateParser.BLOCK_ID, 0); }
		public TerminalNode BLOCK_EQ() { return getToken(FlaskTemplateParser.BLOCK_EQ, 0); }
		public BlockExpressionContext blockExpression() {
			return getRuleContext(BlockExpressionContext.class,0);
		}
		public BlockKeywordArgumentContext(BlockArgumentContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockKeywordArgument(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockArgumentContext blockArgument() throws RecognitionException {
		BlockArgumentContext _localctx = new BlockArgumentContext(_ctx, getState());
		enterRule(_localctx, 82, RULE_blockArgument);
		try {
			setState(500);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,43,_ctx) ) {
			case 1:
				_localctx = new BlockKeywordArgumentContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(496);
				match(BLOCK_ID);
				setState(497);
				match(BLOCK_EQ);
				setState(498);
				blockExpression();
				}
				break;
			case 2:
				_localctx = new BlockPositionalArgumentContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(499);
				blockExpression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BlockExpressionListContext extends ParserRuleContext {
		public List<BlockExpressionContext> blockExpression() {
			return getRuleContexts(BlockExpressionContext.class);
		}
		public BlockExpressionContext blockExpression(int i) {
			return getRuleContext(BlockExpressionContext.class,i);
		}
		public List<TerminalNode> BLOCK_COMMA() { return getTokens(FlaskTemplateParser.BLOCK_COMMA); }
		public TerminalNode BLOCK_COMMA(int i) {
			return getToken(FlaskTemplateParser.BLOCK_COMMA, i);
		}
		public BlockExpressionListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_blockExpressionList; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockExpressionList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockExpressionListContext blockExpressionList() throws RecognitionException {
		BlockExpressionListContext _localctx = new BlockExpressionListContext(_ctx, getState());
		enterRule(_localctx, 84, RULE_blockExpressionList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(502);
			blockExpression();
			setState(507);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==BLOCK_COMMA) {
				{
				{
				setState(503);
				match(BLOCK_COMMA);
				setState(504);
				blockExpression();
				}
				}
				setState(509);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BlockDictPairListContext extends ParserRuleContext {
		public List<BlockDictPairContext> blockDictPair() {
			return getRuleContexts(BlockDictPairContext.class);
		}
		public BlockDictPairContext blockDictPair(int i) {
			return getRuleContext(BlockDictPairContext.class,i);
		}
		public List<TerminalNode> BLOCK_COMMA() { return getTokens(FlaskTemplateParser.BLOCK_COMMA); }
		public TerminalNode BLOCK_COMMA(int i) {
			return getToken(FlaskTemplateParser.BLOCK_COMMA, i);
		}
		public BlockDictPairListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_blockDictPairList; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockDictPairList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockDictPairListContext blockDictPairList() throws RecognitionException {
		BlockDictPairListContext _localctx = new BlockDictPairListContext(_ctx, getState());
		enterRule(_localctx, 86, RULE_blockDictPairList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(510);
			blockDictPair();
			setState(515);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==BLOCK_COMMA) {
				{
				{
				setState(511);
				match(BLOCK_COMMA);
				setState(512);
				blockDictPair();
				}
				}
				setState(517);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BlockDictPairContext extends ParserRuleContext {
		public List<BlockExpressionContext> blockExpression() {
			return getRuleContexts(BlockExpressionContext.class);
		}
		public BlockExpressionContext blockExpression(int i) {
			return getRuleContext(BlockExpressionContext.class,i);
		}
		public TerminalNode BLOCK_COLON() { return getToken(FlaskTemplateParser.BLOCK_COLON, 0); }
		public BlockDictPairContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_blockDictPair; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitBlockDictPair(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockDictPairContext blockDictPair() throws RecognitionException {
		BlockDictPairContext _localctx = new BlockDictPairContext(_ctx, getState());
		enterRule(_localctx, 88, RULE_blockDictPair);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(518);
			blockExpression();
			setState(519);
			match(BLOCK_COLON);
			setState(520);
			blockExpression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ImportListContext extends ParserRuleContext {
		public List<TerminalNode> BLOCK_ID() { return getTokens(FlaskTemplateParser.BLOCK_ID); }
		public TerminalNode BLOCK_ID(int i) {
			return getToken(FlaskTemplateParser.BLOCK_ID, i);
		}
		public List<TerminalNode> BLOCK_COMMA() { return getTokens(FlaskTemplateParser.BLOCK_COMMA); }
		public TerminalNode BLOCK_COMMA(int i) {
			return getToken(FlaskTemplateParser.BLOCK_COMMA, i);
		}
		public ImportListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_importList; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitImportList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ImportListContext importList() throws RecognitionException {
		ImportListContext _localctx = new ImportListContext(_ctx, getState());
		enterRule(_localctx, 90, RULE_importList);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(522);
			match(BLOCK_ID);
			setState(527);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==BLOCK_COMMA) {
				{
				{
				setState(523);
				match(BLOCK_COMMA);
				setState(524);
				match(BLOCK_ID);
				}
				}
				setState(529);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JinjaExprContext extends ParserRuleContext {
		public JinjaExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jinjaExpr; }
	 
		public JinjaExprContext() { }
		public void copyFrom(JinjaExprContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class JinjaExprNodeContext extends JinjaExprContext {
		public TerminalNode TEMPLATE_JINJA_EXPR_START() { return getToken(FlaskTemplateParser.TEMPLATE_JINJA_EXPR_START, 0); }
		public JinjaExpressionContext jinjaExpression() {
			return getRuleContext(JinjaExpressionContext.class,0);
		}
		public TerminalNode EXPR_END() { return getToken(FlaskTemplateParser.EXPR_END, 0); }
		public JinjaExprNodeContext(JinjaExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitJinjaExprNode(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JinjaExprContext jinjaExpr() throws RecognitionException {
		JinjaExprContext _localctx = new JinjaExprContext(_ctx, getState());
		enterRule(_localctx, 92, RULE_jinjaExpr);
		try {
			_localctx = new JinjaExprNodeContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(530);
			match(TEMPLATE_JINJA_EXPR_START);
			setState(531);
			jinjaExpression();
			setState(532);
			match(EXPR_END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JinjaExpressionContext extends ParserRuleContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public JinjaExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jinjaExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitJinjaExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JinjaExpressionContext jinjaExpression() throws RecognitionException {
		JinjaExpressionContext _localctx = new JinjaExpressionContext(_ctx, getState());
		enterRule(_localctx, 94, RULE_jinjaExpression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(534);
			expression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExpressionContext extends ParserRuleContext {
		public ExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expression; }
	 
		public ExpressionContext() { }
		public void copyFrom(ExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ExpressionRootContext extends ExpressionContext {
		public LogicalOrExpressionContext logicalOrExpression() {
			return getRuleContext(LogicalOrExpressionContext.class,0);
		}
		public ExpressionRootContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitExpressionRoot(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExpressionContext expression() throws RecognitionException {
		ExpressionContext _localctx = new ExpressionContext(_ctx, getState());
		enterRule(_localctx, 96, RULE_expression);
		try {
			_localctx = new ExpressionRootContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(536);
			logicalOrExpression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LogicalOrExpressionContext extends ParserRuleContext {
		public List<LogicalAndExpressionContext> logicalAndExpression() {
			return getRuleContexts(LogicalAndExpressionContext.class);
		}
		public LogicalAndExpressionContext logicalAndExpression(int i) {
			return getRuleContext(LogicalAndExpressionContext.class,i);
		}
		public List<TerminalNode> EXPR_OR() { return getTokens(FlaskTemplateParser.EXPR_OR); }
		public TerminalNode EXPR_OR(int i) {
			return getToken(FlaskTemplateParser.EXPR_OR, i);
		}
		public LogicalOrExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_logicalOrExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitLogicalOrExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LogicalOrExpressionContext logicalOrExpression() throws RecognitionException {
		LogicalOrExpressionContext _localctx = new LogicalOrExpressionContext(_ctx, getState());
		enterRule(_localctx, 98, RULE_logicalOrExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(538);
			logicalAndExpression();
			setState(543);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==EXPR_OR) {
				{
				{
				setState(539);
				match(EXPR_OR);
				setState(540);
				logicalAndExpression();
				}
				}
				setState(545);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LogicalAndExpressionContext extends ParserRuleContext {
		public List<EqualityExpressionContext> equalityExpression() {
			return getRuleContexts(EqualityExpressionContext.class);
		}
		public EqualityExpressionContext equalityExpression(int i) {
			return getRuleContext(EqualityExpressionContext.class,i);
		}
		public List<TerminalNode> EXPR_AND() { return getTokens(FlaskTemplateParser.EXPR_AND); }
		public TerminalNode EXPR_AND(int i) {
			return getToken(FlaskTemplateParser.EXPR_AND, i);
		}
		public LogicalAndExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_logicalAndExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitLogicalAndExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LogicalAndExpressionContext logicalAndExpression() throws RecognitionException {
		LogicalAndExpressionContext _localctx = new LogicalAndExpressionContext(_ctx, getState());
		enterRule(_localctx, 100, RULE_logicalAndExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(546);
			equalityExpression();
			setState(551);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==EXPR_AND) {
				{
				{
				setState(547);
				match(EXPR_AND);
				setState(548);
				equalityExpression();
				}
				}
				setState(553);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EqualityExpressionContext extends ParserRuleContext {
		public List<ComparisonExpressionContext> comparisonExpression() {
			return getRuleContexts(ComparisonExpressionContext.class);
		}
		public ComparisonExpressionContext comparisonExpression(int i) {
			return getRuleContext(ComparisonExpressionContext.class,i);
		}
		public List<TerminalNode> EXPR_EQEQ() { return getTokens(FlaskTemplateParser.EXPR_EQEQ); }
		public TerminalNode EXPR_EQEQ(int i) {
			return getToken(FlaskTemplateParser.EXPR_EQEQ, i);
		}
		public List<TerminalNode> EXPR_NEQ() { return getTokens(FlaskTemplateParser.EXPR_NEQ); }
		public TerminalNode EXPR_NEQ(int i) {
			return getToken(FlaskTemplateParser.EXPR_NEQ, i);
		}
		public EqualityExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_equalityExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitEqualityExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EqualityExpressionContext equalityExpression() throws RecognitionException {
		EqualityExpressionContext _localctx = new EqualityExpressionContext(_ctx, getState());
		enterRule(_localctx, 102, RULE_equalityExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(554);
			comparisonExpression();
			setState(559);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==EXPR_EQEQ || _la==EXPR_NEQ) {
				{
				{
				setState(555);
				_la = _input.LA(1);
				if ( !(_la==EXPR_EQEQ || _la==EXPR_NEQ) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(556);
				comparisonExpression();
				}
				}
				setState(561);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ComparisonExpressionContext extends ParserRuleContext {
		public List<AdditiveExpressionContext> additiveExpression() {
			return getRuleContexts(AdditiveExpressionContext.class);
		}
		public AdditiveExpressionContext additiveExpression(int i) {
			return getRuleContext(AdditiveExpressionContext.class,i);
		}
		public List<TerminalNode> EXPR_LT() { return getTokens(FlaskTemplateParser.EXPR_LT); }
		public TerminalNode EXPR_LT(int i) {
			return getToken(FlaskTemplateParser.EXPR_LT, i);
		}
		public List<TerminalNode> EXPR_LTE() { return getTokens(FlaskTemplateParser.EXPR_LTE); }
		public TerminalNode EXPR_LTE(int i) {
			return getToken(FlaskTemplateParser.EXPR_LTE, i);
		}
		public List<TerminalNode> EXPR_GT() { return getTokens(FlaskTemplateParser.EXPR_GT); }
		public TerminalNode EXPR_GT(int i) {
			return getToken(FlaskTemplateParser.EXPR_GT, i);
		}
		public List<TerminalNode> EXPR_GTE() { return getTokens(FlaskTemplateParser.EXPR_GTE); }
		public TerminalNode EXPR_GTE(int i) {
			return getToken(FlaskTemplateParser.EXPR_GTE, i);
		}
		public List<TerminalNode> EXPR_IN() { return getTokens(FlaskTemplateParser.EXPR_IN); }
		public TerminalNode EXPR_IN(int i) {
			return getToken(FlaskTemplateParser.EXPR_IN, i);
		}
		public List<TerminalNode> EXPR_IS() { return getTokens(FlaskTemplateParser.EXPR_IS); }
		public TerminalNode EXPR_IS(int i) {
			return getToken(FlaskTemplateParser.EXPR_IS, i);
		}
		public ComparisonExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_comparisonExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitComparisonExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ComparisonExpressionContext comparisonExpression() throws RecognitionException {
		ComparisonExpressionContext _localctx = new ComparisonExpressionContext(_ctx, getState());
		enterRule(_localctx, 104, RULE_comparisonExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(562);
			additiveExpression();
			setState(567);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((((_la - 102)) & ~0x3f) == 0 && ((1L << (_la - 102)) & 399L) != 0)) {
				{
				{
				setState(563);
				_la = _input.LA(1);
				if ( !(((((_la - 102)) & ~0x3f) == 0 && ((1L << (_la - 102)) & 399L) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(564);
				additiveExpression();
				}
				}
				setState(569);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AdditiveExpressionContext extends ParserRuleContext {
		public List<MultiplicativeExpressionContext> multiplicativeExpression() {
			return getRuleContexts(MultiplicativeExpressionContext.class);
		}
		public MultiplicativeExpressionContext multiplicativeExpression(int i) {
			return getRuleContext(MultiplicativeExpressionContext.class,i);
		}
		public List<TerminalNode> EXPR_PLUS() { return getTokens(FlaskTemplateParser.EXPR_PLUS); }
		public TerminalNode EXPR_PLUS(int i) {
			return getToken(FlaskTemplateParser.EXPR_PLUS, i);
		}
		public List<TerminalNode> EXPR_MINUS() { return getTokens(FlaskTemplateParser.EXPR_MINUS); }
		public TerminalNode EXPR_MINUS(int i) {
			return getToken(FlaskTemplateParser.EXPR_MINUS, i);
		}
		public AdditiveExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_additiveExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitAdditiveExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AdditiveExpressionContext additiveExpression() throws RecognitionException {
		AdditiveExpressionContext _localctx = new AdditiveExpressionContext(_ctx, getState());
		enterRule(_localctx, 106, RULE_additiveExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(570);
			multiplicativeExpression();
			setState(575);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==EXPR_PLUS || _la==EXPR_MINUS) {
				{
				{
				setState(571);
				_la = _input.LA(1);
				if ( !(_la==EXPR_PLUS || _la==EXPR_MINUS) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(572);
				multiplicativeExpression();
				}
				}
				setState(577);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class MultiplicativeExpressionContext extends ParserRuleContext {
		public List<UnaryExpressionContext> unaryExpression() {
			return getRuleContexts(UnaryExpressionContext.class);
		}
		public UnaryExpressionContext unaryExpression(int i) {
			return getRuleContext(UnaryExpressionContext.class,i);
		}
		public List<TerminalNode> EXPR_STAR() { return getTokens(FlaskTemplateParser.EXPR_STAR); }
		public TerminalNode EXPR_STAR(int i) {
			return getToken(FlaskTemplateParser.EXPR_STAR, i);
		}
		public List<TerminalNode> EXPR_SLASH() { return getTokens(FlaskTemplateParser.EXPR_SLASH); }
		public TerminalNode EXPR_SLASH(int i) {
			return getToken(FlaskTemplateParser.EXPR_SLASH, i);
		}
		public List<TerminalNode> EXPR_PERCENT() { return getTokens(FlaskTemplateParser.EXPR_PERCENT); }
		public TerminalNode EXPR_PERCENT(int i) {
			return getToken(FlaskTemplateParser.EXPR_PERCENT, i);
		}
		public List<TerminalNode> EXPR_FLOORDIV() { return getTokens(FlaskTemplateParser.EXPR_FLOORDIV); }
		public TerminalNode EXPR_FLOORDIV(int i) {
			return getToken(FlaskTemplateParser.EXPR_FLOORDIV, i);
		}
		public MultiplicativeExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_multiplicativeExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitMultiplicativeExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MultiplicativeExpressionContext multiplicativeExpression() throws RecognitionException {
		MultiplicativeExpressionContext _localctx = new MultiplicativeExpressionContext(_ctx, getState());
		enterRule(_localctx, 108, RULE_multiplicativeExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(578);
			unaryExpression();
			setState(583);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((((_la - 94)) & ~0x3f) == 0 && ((1L << (_la - 94)) & 23L) != 0)) {
				{
				{
				setState(579);
				_la = _input.LA(1);
				if ( !(((((_la - 94)) & ~0x3f) == 0 && ((1L << (_la - 94)) & 23L) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(580);
				unaryExpression();
				}
				}
				setState(585);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class UnaryExpressionContext extends ParserRuleContext {
		public UnaryExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_unaryExpression; }
	 
		public UnaryExpressionContext() { }
		public void copyFrom(UnaryExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class UnaryBaseContext extends UnaryExpressionContext {
		public PrimaryExpressionContext primaryExpression() {
			return getRuleContext(PrimaryExpressionContext.class,0);
		}
		public UnaryBaseContext(UnaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitUnaryBase(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class UnaryOpContext extends UnaryExpressionContext {
		public UnaryExpressionContext unaryExpression() {
			return getRuleContext(UnaryExpressionContext.class,0);
		}
		public TerminalNode EXPR_PLUS() { return getToken(FlaskTemplateParser.EXPR_PLUS, 0); }
		public TerminalNode EXPR_MINUS() { return getToken(FlaskTemplateParser.EXPR_MINUS, 0); }
		public TerminalNode EXPR_NOT() { return getToken(FlaskTemplateParser.EXPR_NOT, 0); }
		public UnaryOpContext(UnaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitUnaryOp(this);
			else return visitor.visitChildren(this);
		}
	}

	public final UnaryExpressionContext unaryExpression() throws RecognitionException {
		UnaryExpressionContext _localctx = new UnaryExpressionContext(_ctx, getState());
		enterRule(_localctx, 110, RULE_unaryExpression);
		int _la;
		try {
			setState(589);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case EXPR_PLUS:
			case EXPR_MINUS:
			case EXPR_NOT:
				_localctx = new UnaryOpContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(586);
				_la = _input.LA(1);
				if ( !(((((_la - 92)) & ~0x3f) == 0 && ((1L << (_la - 92)) & 65539L) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(587);
				unaryExpression();
				}
				break;
			case EXPR_LPAREN:
			case EXPR_LBRACK:
			case EXPR_LBRACE:
			case EXPR_TRUE:
			case EXPR_FALSE:
			case EXPR_NONE:
			case EXPR_ID:
			case EXPR_STRING:
			case EXPR_NUMBER:
				_localctx = new UnaryBaseContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(588);
				primaryExpression();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PrimaryExpressionContext extends ParserRuleContext {
		public PrimaryExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_primaryExpression; }
	 
		public PrimaryExpressionContext() { }
		public void copyFrom(PrimaryExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class PrimaryContext extends PrimaryExpressionContext {
		public AtomContext atom() {
			return getRuleContext(AtomContext.class,0);
		}
		public List<PostfixContext> postfix() {
			return getRuleContexts(PostfixContext.class);
		}
		public PostfixContext postfix(int i) {
			return getRuleContext(PostfixContext.class,i);
		}
		public PrimaryContext(PrimaryExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitPrimary(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PrimaryExpressionContext primaryExpression() throws RecognitionException {
		PrimaryExpressionContext _localctx = new PrimaryExpressionContext(_ctx, getState());
		enterRule(_localctx, 112, RULE_primaryExpression);
		int _la;
		try {
			_localctx = new PrimaryContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(591);
			atom();
			setState(595);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((((_la - 80)) & ~0x3f) == 0 && ((1L << (_la - 80)) & 773L) != 0)) {
				{
				{
				setState(592);
				postfix();
				}
				}
				setState(597);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AtomContext extends ParserRuleContext {
		public AtomContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_atom; }
	 
		public AtomContext() { }
		public void copyFrom(AtomContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class StringExprContext extends AtomContext {
		public TerminalNode EXPR_STRING() { return getToken(FlaskTemplateParser.EXPR_STRING, 0); }
		public StringExprContext(AtomContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitStringExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class TrueExprContext extends AtomContext {
		public TerminalNode EXPR_TRUE() { return getToken(FlaskTemplateParser.EXPR_TRUE, 0); }
		public TrueExprContext(AtomContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitTrueExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NumberExprContext extends AtomContext {
		public TerminalNode EXPR_NUMBER() { return getToken(FlaskTemplateParser.EXPR_NUMBER, 0); }
		public NumberExprContext(AtomContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitNumberExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NoneExprContext extends AtomContext {
		public TerminalNode EXPR_NONE() { return getToken(FlaskTemplateParser.EXPR_NONE, 0); }
		public NoneExprContext(AtomContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitNoneExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FalseExprContext extends AtomContext {
		public TerminalNode EXPR_FALSE() { return getToken(FlaskTemplateParser.EXPR_FALSE, 0); }
		public FalseExprContext(AtomContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitFalseExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DictExprContext extends AtomContext {
		public TerminalNode EXPR_LBRACE() { return getToken(FlaskTemplateParser.EXPR_LBRACE, 0); }
		public TerminalNode EXPR_RBRACE() { return getToken(FlaskTemplateParser.EXPR_RBRACE, 0); }
		public DictPairListContext dictPairList() {
			return getRuleContext(DictPairListContext.class,0);
		}
		public DictExprContext(AtomContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitDictExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ListExprContext extends AtomContext {
		public TerminalNode EXPR_LBRACK() { return getToken(FlaskTemplateParser.EXPR_LBRACK, 0); }
		public TerminalNode EXPR_RBRACK() { return getToken(FlaskTemplateParser.EXPR_RBRACK, 0); }
		public ExpressionListContext expressionList() {
			return getRuleContext(ExpressionListContext.class,0);
		}
		public ListExprContext(AtomContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitListExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ParenExprContext extends AtomContext {
		public TerminalNode EXPR_LPAREN() { return getToken(FlaskTemplateParser.EXPR_LPAREN, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode EXPR_RPAREN() { return getToken(FlaskTemplateParser.EXPR_RPAREN, 0); }
		public ParenExprContext(AtomContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitParenExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class IdentifierExprContext extends AtomContext {
		public TerminalNode EXPR_ID() { return getToken(FlaskTemplateParser.EXPR_ID, 0); }
		public IdentifierExprContext(AtomContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitIdentifierExpr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AtomContext atom() throws RecognitionException {
		AtomContext _localctx = new AtomContext(_ctx, getState());
		enterRule(_localctx, 114, RULE_atom);
		int _la;
		try {
			setState(618);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case EXPR_LPAREN:
				_localctx = new ParenExprContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(598);
				match(EXPR_LPAREN);
				setState(599);
				expression();
				setState(600);
				match(EXPR_RPAREN);
				}
				break;
			case EXPR_ID:
				_localctx = new IdentifierExprContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(602);
				match(EXPR_ID);
				}
				break;
			case EXPR_STRING:
				_localctx = new StringExprContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(603);
				match(EXPR_STRING);
				}
				break;
			case EXPR_NUMBER:
				_localctx = new NumberExprContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(604);
				match(EXPR_NUMBER);
				}
				break;
			case EXPR_TRUE:
				_localctx = new TrueExprContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(605);
				match(EXPR_TRUE);
				}
				break;
			case EXPR_FALSE:
				_localctx = new FalseExprContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(606);
				match(EXPR_FALSE);
				}
				break;
			case EXPR_NONE:
				_localctx = new NoneExprContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(607);
				match(EXPR_NONE);
				}
				break;
			case EXPR_LBRACK:
				_localctx = new ListExprContext(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(608);
				match(EXPR_LBRACK);
				setState(610);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (((((_la - 80)) & ~0x3f) == 0 && ((1L << (_la - 80)) & 541434327061L) != 0)) {
					{
					setState(609);
					expressionList();
					}
				}

				setState(612);
				match(EXPR_RBRACK);
				}
				break;
			case EXPR_LBRACE:
				_localctx = new DictExprContext(_localctx);
				enterOuterAlt(_localctx, 9);
				{
				setState(613);
				match(EXPR_LBRACE);
				setState(615);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (((((_la - 80)) & ~0x3f) == 0 && ((1L << (_la - 80)) & 541434327061L) != 0)) {
					{
					setState(614);
					dictPairList();
					}
				}

				setState(617);
				match(EXPR_RBRACE);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PostfixContext extends ParserRuleContext {
		public PostfixContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_postfix; }
	 
		public PostfixContext() { }
		public void copyFrom(PostfixContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class MemberOpContext extends PostfixContext {
		public TerminalNode EXPR_DOT() { return getToken(FlaskTemplateParser.EXPR_DOT, 0); }
		public TerminalNode EXPR_ID() { return getToken(FlaskTemplateParser.EXPR_ID, 0); }
		public MemberOpContext(PostfixContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitMemberOp(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class IndexOpContext extends PostfixContext {
		public TerminalNode EXPR_LBRACK() { return getToken(FlaskTemplateParser.EXPR_LBRACK, 0); }
		public SliceItemContext sliceItem() {
			return getRuleContext(SliceItemContext.class,0);
		}
		public TerminalNode EXPR_RBRACK() { return getToken(FlaskTemplateParser.EXPR_RBRACK, 0); }
		public IndexOpContext(PostfixContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitIndexOp(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FilterExprContext extends PostfixContext {
		public TerminalNode EXPR_PIPE() { return getToken(FlaskTemplateParser.EXPR_PIPE, 0); }
		public TerminalNode EXPR_ID() { return getToken(FlaskTemplateParser.EXPR_ID, 0); }
		public TerminalNode EXPR_LPAREN() { return getToken(FlaskTemplateParser.EXPR_LPAREN, 0); }
		public TerminalNode EXPR_RPAREN() { return getToken(FlaskTemplateParser.EXPR_RPAREN, 0); }
		public ArgumentListContext argumentList() {
			return getRuleContext(ArgumentListContext.class,0);
		}
		public FilterExprContext(PostfixContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitFilterExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CallExprContext extends PostfixContext {
		public TerminalNode EXPR_LPAREN() { return getToken(FlaskTemplateParser.EXPR_LPAREN, 0); }
		public TerminalNode EXPR_RPAREN() { return getToken(FlaskTemplateParser.EXPR_RPAREN, 0); }
		public ArgumentListContext argumentList() {
			return getRuleContext(ArgumentListContext.class,0);
		}
		public CallExprContext(PostfixContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitCallExpr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PostfixContext postfix() throws RecognitionException {
		PostfixContext _localctx = new PostfixContext(_ctx, getState());
		enterRule(_localctx, 116, RULE_postfix);
		int _la;
		try {
			setState(640);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case EXPR_PIPE:
				_localctx = new FilterExprContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(620);
				match(EXPR_PIPE);
				setState(621);
				match(EXPR_ID);
				setState(627);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,59,_ctx) ) {
				case 1:
					{
					setState(622);
					match(EXPR_LPAREN);
					setState(624);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if (((((_la - 80)) & ~0x3f) == 0 && ((1L << (_la - 80)) & 541434327061L) != 0)) {
						{
						setState(623);
						argumentList();
						}
					}

					setState(626);
					match(EXPR_RPAREN);
					}
					break;
				}
				}
				break;
			case EXPR_LPAREN:
				_localctx = new CallExprContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(629);
				match(EXPR_LPAREN);
				setState(631);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (((((_la - 80)) & ~0x3f) == 0 && ((1L << (_la - 80)) & 541434327061L) != 0)) {
					{
					setState(630);
					argumentList();
					}
				}

				setState(633);
				match(EXPR_RPAREN);
				}
				break;
			case EXPR_DOT:
				_localctx = new MemberOpContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(634);
				match(EXPR_DOT);
				setState(635);
				match(EXPR_ID);
				}
				break;
			case EXPR_LBRACK:
				_localctx = new IndexOpContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(636);
				match(EXPR_LBRACK);
				setState(637);
				sliceItem();
				setState(638);
				match(EXPR_RBRACK);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SliceItemContext extends ParserRuleContext {
		public SliceItemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sliceItem; }
	 
		public SliceItemContext() { }
		public void copyFrom(SliceItemContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SliceContext extends SliceItemContext {
		public List<TerminalNode> EXPR_COLON() { return getTokens(FlaskTemplateParser.EXPR_COLON); }
		public TerminalNode EXPR_COLON(int i) {
			return getToken(FlaskTemplateParser.EXPR_COLON, i);
		}
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public SliceContext(SliceItemContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitSlice(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class IndexContext extends SliceItemContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public IndexContext(SliceItemContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitIndex(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SliceItemContext sliceItem() throws RecognitionException {
		SliceItemContext _localctx = new SliceItemContext(_ctx, getState());
		enterRule(_localctx, 118, RULE_sliceItem);
		int _la;
		try {
			setState(656);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,66,_ctx) ) {
			case 1:
				_localctx = new IndexContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(642);
				expression();
				}
				break;
			case 2:
				_localctx = new SliceContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(644);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (((((_la - 80)) & ~0x3f) == 0 && ((1L << (_la - 80)) & 541434327061L) != 0)) {
					{
					setState(643);
					expression();
					}
				}

				setState(646);
				match(EXPR_COLON);
				setState(648);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (((((_la - 80)) & ~0x3f) == 0 && ((1L << (_la - 80)) & 541434327061L) != 0)) {
					{
					setState(647);
					expression();
					}
				}

				setState(654);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==EXPR_COLON) {
					{
					setState(650);
					match(EXPR_COLON);
					setState(652);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if (((((_la - 80)) & ~0x3f) == 0 && ((1L << (_la - 80)) & 541434327061L) != 0)) {
						{
						setState(651);
						expression();
						}
					}

					}
				}

				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ArgumentListContext extends ParserRuleContext {
		public ArgumentListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_argumentList; }
	 
		public ArgumentListContext() { }
		public void copyFrom(ArgumentListContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ArgListContext extends ArgumentListContext {
		public List<JinjaArgumentContext> jinjaArgument() {
			return getRuleContexts(JinjaArgumentContext.class);
		}
		public JinjaArgumentContext jinjaArgument(int i) {
			return getRuleContext(JinjaArgumentContext.class,i);
		}
		public List<TerminalNode> EXPR_COMMA() { return getTokens(FlaskTemplateParser.EXPR_COMMA); }
		public TerminalNode EXPR_COMMA(int i) {
			return getToken(FlaskTemplateParser.EXPR_COMMA, i);
		}
		public ArgListContext(ArgumentListContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitArgList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ArgumentListContext argumentList() throws RecognitionException {
		ArgumentListContext _localctx = new ArgumentListContext(_ctx, getState());
		enterRule(_localctx, 120, RULE_argumentList);
		int _la;
		try {
			_localctx = new ArgListContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(658);
			jinjaArgument();
			setState(663);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==EXPR_COMMA) {
				{
				{
				setState(659);
				match(EXPR_COMMA);
				setState(660);
				jinjaArgument();
				}
				}
				setState(665);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JinjaArgumentContext extends ParserRuleContext {
		public JinjaArgumentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jinjaArgument; }
	 
		public JinjaArgumentContext() { }
		public void copyFrom(JinjaArgumentContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class PositionalArgumentContext extends JinjaArgumentContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public PositionalArgumentContext(JinjaArgumentContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitPositionalArgument(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class KeywordArgumentContext extends JinjaArgumentContext {
		public TerminalNode EXPR_ID() { return getToken(FlaskTemplateParser.EXPR_ID, 0); }
		public TerminalNode EXPR_EQ() { return getToken(FlaskTemplateParser.EXPR_EQ, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public KeywordArgumentContext(JinjaArgumentContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitKeywordArgument(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JinjaArgumentContext jinjaArgument() throws RecognitionException {
		JinjaArgumentContext _localctx = new JinjaArgumentContext(_ctx, getState());
		enterRule(_localctx, 122, RULE_jinjaArgument);
		try {
			setState(670);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,68,_ctx) ) {
			case 1:
				_localctx = new KeywordArgumentContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(666);
				match(EXPR_ID);
				setState(667);
				match(EXPR_EQ);
				setState(668);
				expression();
				}
				break;
			case 2:
				_localctx = new PositionalArgumentContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(669);
				expression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExpressionListContext extends ParserRuleContext {
		public ExpressionListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expressionList; }
	 
		public ExpressionListContext() { }
		public void copyFrom(ExpressionListContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ExprListContext extends ExpressionListContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public List<TerminalNode> EXPR_COMMA() { return getTokens(FlaskTemplateParser.EXPR_COMMA); }
		public TerminalNode EXPR_COMMA(int i) {
			return getToken(FlaskTemplateParser.EXPR_COMMA, i);
		}
		public ExprListContext(ExpressionListContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitExprList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExpressionListContext expressionList() throws RecognitionException {
		ExpressionListContext _localctx = new ExpressionListContext(_ctx, getState());
		enterRule(_localctx, 124, RULE_expressionList);
		int _la;
		try {
			_localctx = new ExprListContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(672);
			expression();
			setState(677);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==EXPR_COMMA) {
				{
				{
				setState(673);
				match(EXPR_COMMA);
				setState(674);
				expression();
				}
				}
				setState(679);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DictPairListContext extends ParserRuleContext {
		public DictPairListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dictPairList; }
	 
		public DictPairListContext() { }
		public void copyFrom(DictPairListContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DictPairListNodeContext extends DictPairListContext {
		public List<DictPairContext> dictPair() {
			return getRuleContexts(DictPairContext.class);
		}
		public DictPairContext dictPair(int i) {
			return getRuleContext(DictPairContext.class,i);
		}
		public List<TerminalNode> EXPR_COMMA() { return getTokens(FlaskTemplateParser.EXPR_COMMA); }
		public TerminalNode EXPR_COMMA(int i) {
			return getToken(FlaskTemplateParser.EXPR_COMMA, i);
		}
		public DictPairListNodeContext(DictPairListContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitDictPairListNode(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DictPairListContext dictPairList() throws RecognitionException {
		DictPairListContext _localctx = new DictPairListContext(_ctx, getState());
		enterRule(_localctx, 126, RULE_dictPairList);
		int _la;
		try {
			_localctx = new DictPairListNodeContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(680);
			dictPair();
			setState(685);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==EXPR_COMMA) {
				{
				{
				setState(681);
				match(EXPR_COMMA);
				setState(682);
				dictPair();
				}
				}
				setState(687);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DictPairContext extends ParserRuleContext {
		public DictPairContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dictPair; }
	 
		public DictPairContext() { }
		public void copyFrom(DictPairContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DictPairNodeContext extends DictPairContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public TerminalNode EXPR_COLON() { return getToken(FlaskTemplateParser.EXPR_COLON, 0); }
		public DictPairNodeContext(DictPairContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitDictPairNode(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DictPairContext dictPair() throws RecognitionException {
		DictPairContext _localctx = new DictPairContext(_ctx, getState());
		enterRule(_localctx, 128, RULE_dictPair);
		try {
			_localctx = new DictPairNodeContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(688);
			expression();
			setState(689);
			match(EXPR_COLON);
			setState(690);
			expression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CssStyleContext extends ParserRuleContext {
		public CssStyleContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cssStyle; }
	 
		public CssStyleContext() { }
		public void copyFrom(CssStyleContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class StyleWithAttributesContext extends CssStyleContext {
		public TerminalNode CSS_START() { return getToken(FlaskTemplateParser.CSS_START, 0); }
		public TerminalNode CSS_TAG_CLOSE() { return getToken(FlaskTemplateParser.CSS_TAG_CLOSE, 0); }
		public CssStyleContentContext cssStyleContent() {
			return getRuleContext(CssStyleContentContext.class,0);
		}
		public TerminalNode STYLE_TAG_END() { return getToken(FlaskTemplateParser.STYLE_TAG_END, 0); }
		public CssTagAttributesContext cssTagAttributes() {
			return getRuleContext(CssTagAttributesContext.class,0);
		}
		public StyleWithAttributesContext(CssStyleContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitStyleWithAttributes(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CssStyleContext cssStyle() throws RecognitionException {
		CssStyleContext _localctx = new CssStyleContext(_ctx, getState());
		enterRule(_localctx, 130, RULE_cssStyle);
		try {
			_localctx = new StyleWithAttributesContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(692);
			match(CSS_START);
			setState(694);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,71,_ctx) ) {
			case 1:
				{
				setState(693);
				cssTagAttributes();
				}
				break;
			}
			setState(696);
			match(CSS_TAG_CLOSE);
			setState(697);
			cssStyleContent();
			setState(698);
			match(STYLE_TAG_END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CssTagAttributesContext extends ParserRuleContext {
		public List<CssTagAttributeContext> cssTagAttribute() {
			return getRuleContexts(CssTagAttributeContext.class);
		}
		public CssTagAttributeContext cssTagAttribute(int i) {
			return getRuleContext(CssTagAttributeContext.class,i);
		}
		public CssTagAttributesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cssTagAttributes; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitCssTagAttributes(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CssTagAttributesContext cssTagAttributes() throws RecognitionException {
		CssTagAttributesContext _localctx = new CssTagAttributesContext(_ctx, getState());
		enterRule(_localctx, 132, RULE_cssTagAttributes);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(703);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==CSS_TAG_ATTR) {
				{
				{
				setState(700);
				cssTagAttribute();
				}
				}
				setState(705);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CssTagAttributeContext extends ParserRuleContext {
		public CssTagAttributeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cssTagAttribute; }
	 
		public CssTagAttributeContext() { }
		public void copyFrom(CssTagAttributeContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CssTagAttrNodeContext extends CssTagAttributeContext {
		public TerminalNode CSS_TAG_ATTR() { return getToken(FlaskTemplateParser.CSS_TAG_ATTR, 0); }
		public TerminalNode CSS_TAG_EQ() { return getToken(FlaskTemplateParser.CSS_TAG_EQ, 0); }
		public TerminalNode CSS_TAG_STRING() { return getToken(FlaskTemplateParser.CSS_TAG_STRING, 0); }
		public CssTagAttrNodeContext(CssTagAttributeContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitCssTagAttrNode(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CssTagAttributeContext cssTagAttribute() throws RecognitionException {
		CssTagAttributeContext _localctx = new CssTagAttributeContext(_ctx, getState());
		enterRule(_localctx, 134, RULE_cssTagAttribute);
		try {
			_localctx = new CssTagAttrNodeContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(706);
			match(CSS_TAG_ATTR);
			setState(707);
			match(CSS_TAG_EQ);
			setState(708);
			match(CSS_TAG_STRING);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CssStyleContentContext extends ParserRuleContext {
		public List<CssRuleContext> cssRule() {
			return getRuleContexts(CssRuleContext.class);
		}
		public CssRuleContext cssRule(int i) {
			return getRuleContext(CssRuleContext.class,i);
		}
		public CssStyleContentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cssStyleContent; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitCssStyleContent(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CssStyleContentContext cssStyleContent() throws RecognitionException {
		CssStyleContentContext _localctx = new CssStyleContentContext(_ctx, getState());
		enterRule(_localctx, 136, RULE_cssStyleContent);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(713);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==CSS_CONTENT) {
				{
				{
				setState(710);
				cssRule();
				}
				}
				setState(715);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CssRuleContext extends ParserRuleContext {
		public CssRuleContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cssRule; }
	 
		public CssRuleContext() { }
		public void copyFrom(CssRuleContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CssRuleNodeContext extends CssRuleContext {
		public CssSelectorsContext cssSelectors() {
			return getRuleContext(CssSelectorsContext.class,0);
		}
		public TerminalNode CSS_LBRACE() { return getToken(FlaskTemplateParser.CSS_LBRACE, 0); }
		public CssDeclarationsContext cssDeclarations() {
			return getRuleContext(CssDeclarationsContext.class,0);
		}
		public TerminalNode CSS_RBRACE() { return getToken(FlaskTemplateParser.CSS_RBRACE, 0); }
		public List<TerminalNode> CSS_CONTENT() { return getTokens(FlaskTemplateParser.CSS_CONTENT); }
		public TerminalNode CSS_CONTENT(int i) {
			return getToken(FlaskTemplateParser.CSS_CONTENT, i);
		}
		public CssRuleNodeContext(CssRuleContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitCssRuleNode(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CssRuleContext cssRule() throws RecognitionException {
		CssRuleContext _localctx = new CssRuleContext(_ctx, getState());
		enterRule(_localctx, 138, RULE_cssRule);
		int _la;
		try {
			_localctx = new CssRuleNodeContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(716);
			cssSelectors();
			setState(720);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==CSS_CONTENT) {
				{
				{
				setState(717);
				match(CSS_CONTENT);
				}
				}
				setState(722);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(723);
			match(CSS_LBRACE);
			setState(724);
			cssDeclarations();
			setState(725);
			match(CSS_RBRACE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CssSelectorsContext extends ParserRuleContext {
		public CssSelectorsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cssSelectors; }
	 
		public CssSelectorsContext() { }
		public void copyFrom(CssSelectorsContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CssSelectorExprContext extends CssSelectorsContext {
		public List<CssSelectorContext> cssSelector() {
			return getRuleContexts(CssSelectorContext.class);
		}
		public CssSelectorContext cssSelector(int i) {
			return getRuleContext(CssSelectorContext.class,i);
		}
		public List<TerminalNode> CSS_COMMA() { return getTokens(FlaskTemplateParser.CSS_COMMA); }
		public TerminalNode CSS_COMMA(int i) {
			return getToken(FlaskTemplateParser.CSS_COMMA, i);
		}
		public CssSelectorExprContext(CssSelectorsContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitCssSelectorExpr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CssSelectorsContext cssSelectors() throws RecognitionException {
		CssSelectorsContext _localctx = new CssSelectorsContext(_ctx, getState());
		enterRule(_localctx, 140, RULE_cssSelectors);
		int _la;
		try {
			_localctx = new CssSelectorExprContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(727);
			cssSelector();
			setState(732);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==CSS_COMMA) {
				{
				{
				setState(728);
				match(CSS_COMMA);
				setState(729);
				cssSelector();
				}
				}
				setState(734);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CssSelectorContext extends ParserRuleContext {
		public CssSelectorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cssSelector; }
	 
		public CssSelectorContext() { }
		public void copyFrom(CssSelectorContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CssSelectorNodeContext extends CssSelectorContext {
		public List<TerminalNode> CSS_CONTENT() { return getTokens(FlaskTemplateParser.CSS_CONTENT); }
		public TerminalNode CSS_CONTENT(int i) {
			return getToken(FlaskTemplateParser.CSS_CONTENT, i);
		}
		public List<TerminalNode> CSS_DOT() { return getTokens(FlaskTemplateParser.CSS_DOT); }
		public TerminalNode CSS_DOT(int i) {
			return getToken(FlaskTemplateParser.CSS_DOT, i);
		}
		public CssSelectorNodeContext(CssSelectorContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitCssSelectorNode(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CssSelectorContext cssSelector() throws RecognitionException {
		CssSelectorContext _localctx = new CssSelectorContext(_ctx, getState());
		enterRule(_localctx, 142, RULE_cssSelector);
		int _la;
		try {
			_localctx = new CssSelectorNodeContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(735);
			match(CSS_CONTENT);
			setState(740);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==CSS_DOT) {
				{
				{
				setState(736);
				match(CSS_DOT);
				setState(737);
				match(CSS_CONTENT);
				}
				}
				setState(742);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CssDeclarationsContext extends ParserRuleContext {
		public CssDeclarationsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cssDeclarations; }
	 
		public CssDeclarationsContext() { }
		public void copyFrom(CssDeclarationsContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CssDeclarationListContext extends CssDeclarationsContext {
		public List<CssDeclarationContext> cssDeclaration() {
			return getRuleContexts(CssDeclarationContext.class);
		}
		public CssDeclarationContext cssDeclaration(int i) {
			return getRuleContext(CssDeclarationContext.class,i);
		}
		public CssDeclarationListContext(CssDeclarationsContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitCssDeclarationList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CssDeclarationsContext cssDeclarations() throws RecognitionException {
		CssDeclarationsContext _localctx = new CssDeclarationsContext(_ctx, getState());
		enterRule(_localctx, 144, RULE_cssDeclarations);
		int _la;
		try {
			_localctx = new CssDeclarationListContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(746);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==CSS_PROPERTY) {
				{
				{
				setState(743);
				cssDeclaration();
				}
				}
				setState(748);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CssDeclarationContext extends ParserRuleContext {
		public CssDeclarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cssDeclaration; }
	 
		public CssDeclarationContext() { }
		public void copyFrom(CssDeclarationContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CssDeclarationNodeContext extends CssDeclarationContext {
		public TerminalNode CSS_PROPERTY() { return getToken(FlaskTemplateParser.CSS_PROPERTY, 0); }
		public TerminalNode CSS_COLON() { return getToken(FlaskTemplateParser.CSS_COLON, 0); }
		public CssValuesContext cssValues() {
			return getRuleContext(CssValuesContext.class,0);
		}
		public TerminalNode CSS_SEMICOLON() { return getToken(FlaskTemplateParser.CSS_SEMICOLON, 0); }
		public CssDeclarationNodeContext(CssDeclarationContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitCssDeclarationNode(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CssDeclarationContext cssDeclaration() throws RecognitionException {
		CssDeclarationContext _localctx = new CssDeclarationContext(_ctx, getState());
		enterRule(_localctx, 146, RULE_cssDeclaration);
		try {
			_localctx = new CssDeclarationNodeContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(749);
			match(CSS_PROPERTY);
			setState(750);
			match(CSS_COLON);
			setState(751);
			cssValues();
			setState(752);
			match(CSS_SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CssValuesContext extends ParserRuleContext {
		public CssValuesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cssValues; }
	 
		public CssValuesContext() { }
		public void copyFrom(CssValuesContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CssValueListContext extends CssValuesContext {
		public List<CssValueContext> cssValue() {
			return getRuleContexts(CssValueContext.class);
		}
		public CssValueContext cssValue(int i) {
			return getRuleContext(CssValueContext.class,i);
		}
		public List<TerminalNode> CSS_COMMA() { return getTokens(FlaskTemplateParser.CSS_COMMA); }
		public TerminalNode CSS_COMMA(int i) {
			return getToken(FlaskTemplateParser.CSS_COMMA, i);
		}
		public CssValueListContext(CssValuesContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitCssValueList(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CssValuesContext cssValues() throws RecognitionException {
		CssValuesContext _localctx = new CssValuesContext(_ctx, getState());
		enterRule(_localctx, 148, RULE_cssValues);
		int _la;
		try {
			_localctx = new CssValueListContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(754);
			cssValue();
			setState(761);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((((_la - 139)) & ~0x3f) == 0 && ((1L << (_la - 139)) & 481L) != 0)) {
				{
				{
				setState(756);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==CSS_COMMA) {
					{
					setState(755);
					match(CSS_COMMA);
					}
				}

				setState(758);
				cssValue();
				}
				}
				setState(763);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CssValueContext extends ParserRuleContext {
		public CssValueContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cssValue; }
	 
		public CssValueContext() { }
		public void copyFrom(CssValueContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CssKeywordValueContext extends CssValueContext {
		public TerminalNode CSS_KEYWORD() { return getToken(FlaskTemplateParser.CSS_KEYWORD, 0); }
		public CssKeywordValueContext(CssValueContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitCssKeywordValue(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CssStringValueContext extends CssValueContext {
		public TerminalNode CSS_STRING() { return getToken(FlaskTemplateParser.CSS_STRING, 0); }
		public CssStringValueContext(CssValueContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitCssStringValue(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CssNumericValueContext extends CssValueContext {
		public TerminalNode CSS_NUMERIC() { return getToken(FlaskTemplateParser.CSS_NUMERIC, 0); }
		public CssNumericValueContext(CssValueContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitCssNumericValue(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CssColorValueContext extends CssValueContext {
		public TerminalNode CSS_COLOR() { return getToken(FlaskTemplateParser.CSS_COLOR, 0); }
		public CssColorValueContext(CssValueContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof FlaskTemplateParserVisitor ) return ((FlaskTemplateParserVisitor<? extends T>)visitor).visitCssColorValue(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CssValueContext cssValue() throws RecognitionException {
		CssValueContext _localctx = new CssValueContext(_ctx, getState());
		enterRule(_localctx, 150, RULE_cssValue);
		try {
			setState(768);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CSS_STRING:
				_localctx = new CssStringValueContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(764);
				match(CSS_STRING);
				}
				break;
			case CSS_NUMERIC:
				_localctx = new CssNumericValueContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(765);
				match(CSS_NUMERIC);
				}
				break;
			case CSS_COLOR:
				_localctx = new CssColorValueContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(766);
				match(CSS_COLOR);
				}
				break;
			case CSS_KEYWORD:
				_localctx = new CssKeywordValueContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(767);
				match(CSS_KEYWORD);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\u0004\u0001\u0096\u0303\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001"+
		"\u0002\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004"+
		"\u0002\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007"+
		"\u0002\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b"+
		"\u0002\f\u0007\f\u0002\r\u0007\r\u0002\u000e\u0007\u000e\u0002\u000f\u0007"+
		"\u000f\u0002\u0010\u0007\u0010\u0002\u0011\u0007\u0011\u0002\u0012\u0007"+
		"\u0012\u0002\u0013\u0007\u0013\u0002\u0014\u0007\u0014\u0002\u0015\u0007"+
		"\u0015\u0002\u0016\u0007\u0016\u0002\u0017\u0007\u0017\u0002\u0018\u0007"+
		"\u0018\u0002\u0019\u0007\u0019\u0002\u001a\u0007\u001a\u0002\u001b\u0007"+
		"\u001b\u0002\u001c\u0007\u001c\u0002\u001d\u0007\u001d\u0002\u001e\u0007"+
		"\u001e\u0002\u001f\u0007\u001f\u0002 \u0007 \u0002!\u0007!\u0002\"\u0007"+
		"\"\u0002#\u0007#\u0002$\u0007$\u0002%\u0007%\u0002&\u0007&\u0002\'\u0007"+
		"\'\u0002(\u0007(\u0002)\u0007)\u0002*\u0007*\u0002+\u0007+\u0002,\u0007"+
		",\u0002-\u0007-\u0002.\u0007.\u0002/\u0007/\u00020\u00070\u00021\u0007"+
		"1\u00022\u00072\u00023\u00073\u00024\u00074\u00025\u00075\u00026\u0007"+
		"6\u00027\u00077\u00028\u00078\u00029\u00079\u0002:\u0007:\u0002;\u0007"+
		";\u0002<\u0007<\u0002=\u0007=\u0002>\u0007>\u0002?\u0007?\u0002@\u0007"+
		"@\u0002A\u0007A\u0002B\u0007B\u0002C\u0007C\u0002D\u0007D\u0002E\u0007"+
		"E\u0002F\u0007F\u0002G\u0007G\u0002H\u0007H\u0002I\u0007I\u0002J\u0007"+
		"J\u0002K\u0007K\u0001\u0000\u0003\u0000\u009a\b\u0000\u0001\u0000\u0001"+
		"\u0000\u0003\u0000\u009e\b\u0000\u0001\u0000\u0005\u0000\u00a1\b\u0000"+
		"\n\u0000\f\u0000\u00a4\t\u0000\u0001\u0000\u0001\u0000\u0001\u0001\u0001"+
		"\u0001\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001"+
		"\u0002\u0001\u0002\u0001\u0003\u0005\u0003\u00b2\b\u0003\n\u0003\f\u0003"+
		"\u00b5\t\u0003\u0001\u0004\u0001\u0004\u0001\u0004\u0001\u0004\u0001\u0004"+
		"\u0001\u0004\u0001\u0004\u0003\u0004\u00be\b\u0004\u0001\u0005\u0001\u0005"+
		"\u0003\u0005\u00c2\b\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005"+
		"\u0003\u0005\u00c8\b\u0005\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006"+
		"\u0001\u0006\u0001\u0007\u0001\u0007\u0001\u0007\u0001\u0007\u0001\b\u0001"+
		"\b\u0001\b\u0001\b\u0001\b\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001"+
		"\n\u0005\n\u00de\b\n\n\n\f\n\u00e1\t\n\u0001\u000b\u0001\u000b\u0001\u000b"+
		"\u0001\u000b\u0003\u000b\u00e7\b\u000b\u0001\f\u0001\f\u0003\f\u00eb\b"+
		"\f\u0001\f\u0001\f\u0001\r\u0004\r\u00f0\b\r\u000b\r\f\r\u00f1\u0001\u000e"+
		"\u0001\u000e\u0001\u000e\u0003\u000e\u00f7\b\u000e\u0001\u000f\u0001\u000f"+
		"\u0001\u000f\u0001\u000f\u0001\u0010\u0001\u0010\u0001\u0011\u0001\u0011"+
		"\u0001\u0011\u0001\u0011\u0001\u0012\u0004\u0012\u0104\b\u0012\u000b\u0012"+
		"\f\u0012\u0105\u0001\u0013\u0001\u0013\u0001\u0013\u0001\u0013\u0003\u0013"+
		"\u010c\b\u0013\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014"+
		"\u0001\u0014\u0005\u0014\u0114\b\u0014\n\u0014\f\u0014\u0117\t\u0014\u0001"+
		"\u0014\u0003\u0014\u011a\b\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001"+
		"\u0014\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0001"+
		"\u0015\u0001\u0016\u0001\u0016\u0001\u0016\u0001\u0016\u0001\u0016\u0001"+
		"\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001"+
		"\u0017\u0001\u0017\u0003\u0017\u0133\b\u0017\u0001\u0017\u0001\u0017\u0001"+
		"\u0017\u0001\u0017\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001"+
		"\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0003\u0018\u0141\b\u0018\u0001"+
		"\u0018\u0001\u0018\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0003"+
		"\u0019\u0149\b\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001\u0019\u0001"+
		"\u0019\u0001\u0019\u0001\u0019\u0001\u001a\u0001\u001a\u0001\u001a\u0001"+
		"\u001a\u0001\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0001"+
		"\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0003\u001b\u0160"+
		"\b\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0001"+
		"\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0003\u001b\u016b\b\u001b\u0003"+
		"\u001b\u016d\b\u001b\u0001\u001c\u0001\u001c\u0001\u001d\u0001\u001d\u0001"+
		"\u001d\u0005\u001d\u0174\b\u001d\n\u001d\f\u001d\u0177\t\u001d\u0001\u001e"+
		"\u0001\u001e\u0001\u001e\u0005\u001e\u017c\b\u001e\n\u001e\f\u001e\u017f"+
		"\t\u001e\u0001\u001f\u0001\u001f\u0001\u001f\u0005\u001f\u0184\b\u001f"+
		"\n\u001f\f\u001f\u0187\t\u001f\u0001 \u0001 \u0001 \u0005 \u018c\b \n"+
		" \f \u018f\t \u0001!\u0001!\u0001!\u0005!\u0194\b!\n!\f!\u0197\t!\u0001"+
		"\"\u0001\"\u0001\"\u0005\"\u019c\b\"\n\"\f\"\u019f\t\"\u0001#\u0001#\u0001"+
		"#\u0003#\u01a4\b#\u0001$\u0001$\u0005$\u01a8\b$\n$\f$\u01ab\t$\u0001%"+
		"\u0001%\u0001%\u0001%\u0001%\u0001%\u0001%\u0001%\u0001%\u0001%\u0001"+
		"%\u0001%\u0003%\u01b9\b%\u0001%\u0001%\u0001%\u0003%\u01be\b%\u0001%\u0003"+
		"%\u01c1\b%\u0001&\u0001&\u0001&\u0001&\u0003&\u01c7\b&\u0001&\u0003&\u01ca"+
		"\b&\u0001&\u0001&\u0003&\u01ce\b&\u0001&\u0001&\u0001&\u0001&\u0001&\u0001"+
		"&\u0001&\u0003&\u01d7\b&\u0001\'\u0001\'\u0003\'\u01db\b\'\u0001\'\u0001"+
		"\'\u0003\'\u01df\b\'\u0001\'\u0001\'\u0003\'\u01e3\b\'\u0003\'\u01e5\b"+
		"\'\u0003\'\u01e7\b\'\u0001(\u0001(\u0001(\u0005(\u01ec\b(\n(\f(\u01ef"+
		"\t(\u0001)\u0001)\u0001)\u0001)\u0003)\u01f5\b)\u0001*\u0001*\u0001*\u0005"+
		"*\u01fa\b*\n*\f*\u01fd\t*\u0001+\u0001+\u0001+\u0005+\u0202\b+\n+\f+\u0205"+
		"\t+\u0001,\u0001,\u0001,\u0001,\u0001-\u0001-\u0001-\u0005-\u020e\b-\n"+
		"-\f-\u0211\t-\u0001.\u0001.\u0001.\u0001.\u0001/\u0001/\u00010\u00010"+
		"\u00011\u00011\u00011\u00051\u021e\b1\n1\f1\u0221\t1\u00012\u00012\u0001"+
		"2\u00052\u0226\b2\n2\f2\u0229\t2\u00013\u00013\u00013\u00053\u022e\b3"+
		"\n3\f3\u0231\t3\u00014\u00014\u00014\u00054\u0236\b4\n4\f4\u0239\t4\u0001"+
		"5\u00015\u00015\u00055\u023e\b5\n5\f5\u0241\t5\u00016\u00016\u00016\u0005"+
		"6\u0246\b6\n6\f6\u0249\t6\u00017\u00017\u00017\u00037\u024e\b7\u00018"+
		"\u00018\u00058\u0252\b8\n8\f8\u0255\t8\u00019\u00019\u00019\u00019\u0001"+
		"9\u00019\u00019\u00019\u00019\u00019\u00019\u00019\u00039\u0263\b9\u0001"+
		"9\u00019\u00019\u00039\u0268\b9\u00019\u00039\u026b\b9\u0001:\u0001:\u0001"+
		":\u0001:\u0003:\u0271\b:\u0001:\u0003:\u0274\b:\u0001:\u0001:\u0003:\u0278"+
		"\b:\u0001:\u0001:\u0001:\u0001:\u0001:\u0001:\u0001:\u0003:\u0281\b:\u0001"+
		";\u0001;\u0003;\u0285\b;\u0001;\u0001;\u0003;\u0289\b;\u0001;\u0001;\u0003"+
		";\u028d\b;\u0003;\u028f\b;\u0003;\u0291\b;\u0001<\u0001<\u0001<\u0005"+
		"<\u0296\b<\n<\f<\u0299\t<\u0001=\u0001=\u0001=\u0001=\u0003=\u029f\b="+
		"\u0001>\u0001>\u0001>\u0005>\u02a4\b>\n>\f>\u02a7\t>\u0001?\u0001?\u0001"+
		"?\u0005?\u02ac\b?\n?\f?\u02af\t?\u0001@\u0001@\u0001@\u0001@\u0001A\u0001"+
		"A\u0003A\u02b7\bA\u0001A\u0001A\u0001A\u0001A\u0001B\u0005B\u02be\bB\n"+
		"B\fB\u02c1\tB\u0001C\u0001C\u0001C\u0001C\u0001D\u0005D\u02c8\bD\nD\f"+
		"D\u02cb\tD\u0001E\u0001E\u0005E\u02cf\bE\nE\fE\u02d2\tE\u0001E\u0001E"+
		"\u0001E\u0001E\u0001F\u0001F\u0001F\u0005F\u02db\bF\nF\fF\u02de\tF\u0001"+
		"G\u0001G\u0001G\u0005G\u02e3\bG\nG\fG\u02e6\tG\u0001H\u0005H\u02e9\bH"+
		"\nH\fH\u02ec\tH\u0001I\u0001I\u0001I\u0001I\u0001I\u0001J\u0001J\u0003"+
		"J\u02f5\bJ\u0001J\u0005J\u02f8\bJ\nJ\fJ\u02fb\tJ\u0001K\u0001K\u0001K"+
		"\u0001K\u0003K\u0301\bK\u0001K\u0000\u0000L\u0000\u0002\u0004\u0006\b"+
		"\n\f\u000e\u0010\u0012\u0014\u0016\u0018\u001a\u001c\u001e \"$&(*,.02"+
		"468:<>@BDFHJLNPRTVXZ\\^`bdfhjlnprtvxz|~\u0080\u0082\u0084\u0086\u0088"+
		"\u008a\u008c\u008e\u0090\u0092\u0094\u0096\u0000\n\u0001\u000056\u0002"+
		"\u0000()7:\u0001\u0000;<\u0001\u0000=?\u0002\u000044;<\u0001\u0000de\u0002"+
		"\u0000fimn\u0001\u0000\\]\u0002\u0000^`bb\u0002\u0000\\]ll\u0328\u0000"+
		"\u0099\u0001\u0000\u0000\u0000\u0002\u00a7\u0001\u0000\u0000\u0000\u0004"+
		"\u00a9\u0001\u0000\u0000\u0000\u0006\u00b3\u0001\u0000\u0000\u0000\b\u00bd"+
		"\u0001\u0000\u0000\u0000\n\u00c7\u0001\u0000\u0000\u0000\f\u00c9\u0001"+
		"\u0000\u0000\u0000\u000e\u00ce\u0001\u0000\u0000\u0000\u0010\u00d2\u0001"+
		"\u0000\u0000\u0000\u0012\u00d7\u0001\u0000\u0000\u0000\u0014\u00df\u0001"+
		"\u0000\u0000\u0000\u0016\u00e6\u0001\u0000\u0000\u0000\u0018\u00e8\u0001"+
		"\u0000\u0000\u0000\u001a\u00ef\u0001\u0000\u0000\u0000\u001c\u00f6\u0001"+
		"\u0000\u0000\u0000\u001e\u00f8\u0001\u0000\u0000\u0000 \u00fc\u0001\u0000"+
		"\u0000\u0000\"\u00fe\u0001\u0000\u0000\u0000$\u0103\u0001\u0000\u0000"+
		"\u0000&\u010b\u0001\u0000\u0000\u0000(\u010d\u0001\u0000\u0000\u0000*"+
		"\u011f\u0001\u0000\u0000\u0000,\u0125\u0001\u0000\u0000\u0000.\u012a\u0001"+
		"\u0000\u0000\u00000\u0138\u0001\u0000\u0000\u00002\u0144\u0001\u0000\u0000"+
		"\u00004\u0151\u0001\u0000\u0000\u00006\u016c\u0001\u0000\u0000\u00008"+
		"\u016e\u0001\u0000\u0000\u0000:\u0170\u0001\u0000\u0000\u0000<\u0178\u0001"+
		"\u0000\u0000\u0000>\u0180\u0001\u0000\u0000\u0000@\u0188\u0001\u0000\u0000"+
		"\u0000B\u0190\u0001\u0000\u0000\u0000D\u0198\u0001\u0000\u0000\u0000F"+
		"\u01a3\u0001\u0000\u0000\u0000H\u01a5\u0001\u0000\u0000\u0000J\u01c0\u0001"+
		"\u0000\u0000\u0000L\u01d6\u0001\u0000\u0000\u0000N\u01e6\u0001\u0000\u0000"+
		"\u0000P\u01e8\u0001\u0000\u0000\u0000R\u01f4\u0001\u0000\u0000\u0000T"+
		"\u01f6\u0001\u0000\u0000\u0000V\u01fe\u0001\u0000\u0000\u0000X\u0206\u0001"+
		"\u0000\u0000\u0000Z\u020a\u0001\u0000\u0000\u0000\\\u0212\u0001\u0000"+
		"\u0000\u0000^\u0216\u0001\u0000\u0000\u0000`\u0218\u0001\u0000\u0000\u0000"+
		"b\u021a\u0001\u0000\u0000\u0000d\u0222\u0001\u0000\u0000\u0000f\u022a"+
		"\u0001\u0000\u0000\u0000h\u0232\u0001\u0000\u0000\u0000j\u023a\u0001\u0000"+
		"\u0000\u0000l\u0242\u0001\u0000\u0000\u0000n\u024d\u0001\u0000\u0000\u0000"+
		"p\u024f\u0001\u0000\u0000\u0000r\u026a\u0001\u0000\u0000\u0000t\u0280"+
		"\u0001\u0000\u0000\u0000v\u0290\u0001\u0000\u0000\u0000x\u0292\u0001\u0000"+
		"\u0000\u0000z\u029e\u0001\u0000\u0000\u0000|\u02a0\u0001\u0000\u0000\u0000"+
		"~\u02a8\u0001\u0000\u0000\u0000\u0080\u02b0\u0001\u0000\u0000\u0000\u0082"+
		"\u02b4\u0001\u0000\u0000\u0000\u0084\u02bf\u0001\u0000\u0000\u0000\u0086"+
		"\u02c2\u0001\u0000\u0000\u0000\u0088\u02c9\u0001\u0000\u0000\u0000\u008a"+
		"\u02cc\u0001\u0000\u0000\u0000\u008c\u02d7\u0001\u0000\u0000\u0000\u008e"+
		"\u02df\u0001\u0000\u0000\u0000\u0090\u02ea\u0001\u0000\u0000\u0000\u0092"+
		"\u02ed\u0001\u0000\u0000\u0000\u0094\u02f2\u0001\u0000\u0000\u0000\u0096"+
		"\u0300\u0001\u0000\u0000\u0000\u0098\u009a\u0003\u0002\u0001\u0000\u0099"+
		"\u0098\u0001\u0000\u0000\u0000\u0099\u009a\u0001\u0000\u0000\u0000\u009a"+
		"\u009d\u0001\u0000\u0000\u0000\u009b\u009e\u0003\u0004\u0002\u0000\u009c"+
		"\u009e\u0003\u0006\u0003\u0000\u009d\u009b\u0001\u0000\u0000\u0000\u009d"+
		"\u009c\u0001\u0000\u0000\u0000\u009e\u00a2\u0001\u0000\u0000\u0000\u009f"+
		"\u00a1\u0005\u0001\u0000\u0000\u00a0\u009f\u0001\u0000\u0000\u0000\u00a1"+
		"\u00a4\u0001\u0000\u0000\u0000\u00a2\u00a0\u0001\u0000\u0000\u0000\u00a2"+
		"\u00a3\u0001\u0000\u0000\u0000\u00a3\u00a5\u0001\u0000\u0000\u0000\u00a4"+
		"\u00a2\u0001\u0000\u0000\u0000\u00a5\u00a6\u0005\u0000\u0000\u0001\u00a6"+
		"\u0001\u0001\u0000\u0000\u0000\u00a7\u00a8\u0005\u0002\u0000\u0000\u00a8"+
		"\u0003\u0001\u0000\u0000\u0000\u00a9\u00aa\u0005\t\u0000\u0000\u00aa\u00ab"+
		"\u0005\u0013\u0000\u0000\u00ab\u00ac\u0003\u0014\n\u0000\u00ac\u00ad\u0005"+
		"\u000e\u0000\u0000\u00ad\u00ae\u0003\u0006\u0003\u0000\u00ae\u00af\u0005"+
		"\f\u0000\u0000\u00af\u0005\u0001\u0000\u0000\u0000\u00b0\u00b2\u0003\b"+
		"\u0004\u0000\u00b1\u00b0\u0001\u0000\u0000\u0000\u00b2\u00b5\u0001\u0000"+
		"\u0000\u0000\u00b3\u00b1\u0001\u0000\u0000\u0000\u00b3\u00b4\u0001\u0000"+
		"\u0000\u0000\u00b4\u0007\u0001\u0000\u0000\u0000\u00b5\u00b3\u0001\u0000"+
		"\u0000\u0000\u00b6\u00be\u0003\n\u0005\u0000\u00b7\u00be\u0003&\u0013"+
		"\u0000\u00b8\u00be\u00034\u001a\u0000\u00b9\u00be\u0003\\.\u0000\u00ba"+
		"\u00be\u0003$\u0012\u0000\u00bb\u00be\u0003\u0082A\u0000\u00bc\u00be\u0005"+
		"\u0001\u0000\u0000\u00bd\u00b6\u0001\u0000\u0000\u0000\u00bd\u00b7\u0001"+
		"\u0000\u0000\u0000\u00bd\u00b8\u0001\u0000\u0000\u0000\u00bd\u00b9\u0001"+
		"\u0000\u0000\u0000\u00bd\u00ba\u0001\u0000\u0000\u0000\u00bd\u00bb\u0001"+
		"\u0000\u0000\u0000\u00bd\u00bc\u0001\u0000\u0000\u0000\u00be\t\u0001\u0000"+
		"\u0000\u0000\u00bf\u00c1\u0003\f\u0006\u0000\u00c0\u00c2\u0003\u0006\u0003"+
		"\u0000\u00c1\u00c0\u0001\u0000\u0000\u0000\u00c1\u00c2\u0001\u0000\u0000"+
		"\u0000\u00c2\u00c3\u0001\u0000\u0000\u0000\u00c3\u00c4\u0003\u000e\u0007"+
		"\u0000\u00c4\u00c8\u0001\u0000\u0000\u0000\u00c5\u00c8\u0003\u0012\t\u0000"+
		"\u00c6\u00c8\u0003\u0010\b\u0000\u00c7\u00bf\u0001\u0000\u0000\u0000\u00c7"+
		"\u00c5\u0001\u0000\u0000\u0000\u00c7\u00c6\u0001\u0000\u0000\u0000\u00c8"+
		"\u000b\u0001\u0000\u0000\u0000\u00c9\u00ca\u0005\t\u0000\u0000\u00ca\u00cb"+
		"\u0005\u0013\u0000\u0000\u00cb\u00cc\u0003\u0014\n\u0000\u00cc\u00cd\u0005"+
		"\u000e\u0000\u0000\u00cd\r\u0001\u0000\u0000\u0000\u00ce\u00cf\u0005\b"+
		"\u0000\u0000\u00cf\u00d0\u0005\u0013\u0000\u0000\u00d0\u00d1\u0005\u000e"+
		"\u0000\u0000\u00d1\u000f\u0001\u0000\u0000\u0000\u00d2\u00d3\u0005\t\u0000"+
		"\u0000\u00d3\u00d4\u0005\u0013\u0000\u0000\u00d4\u00d5\u0003\u0014\n\u0000"+
		"\u00d5\u00d6\u0005\u000f\u0000\u0000\u00d6\u0011\u0001\u0000\u0000\u0000"+
		"\u00d7\u00d8\u0005\t\u0000\u0000\u00d8\u00d9\u0005\u0011\u0000\u0000\u00d9"+
		"\u00da\u0003\u0014\n\u0000\u00da\u00db\u0005\u000e\u0000\u0000\u00db\u0013"+
		"\u0001\u0000\u0000\u0000\u00dc\u00de\u0003\u0016\u000b\u0000\u00dd\u00dc"+
		"\u0001\u0000\u0000\u0000\u00de\u00e1\u0001\u0000\u0000\u0000\u00df\u00dd"+
		"\u0001\u0000\u0000\u0000\u00df\u00e0\u0001\u0000\u0000\u0000\u00e0\u0015"+
		"\u0001\u0000\u0000\u0000\u00e1\u00df\u0001\u0000\u0000\u0000\u00e2\u00e3"+
		"\u0005\u0013\u0000\u0000\u00e3\u00e4\u0005\u0010\u0000\u0000\u00e4\u00e7"+
		"\u0003\u0018\f\u0000\u00e5\u00e7\u0005\u0012\u0000\u0000\u00e6\u00e2\u0001"+
		"\u0000\u0000\u0000\u00e6\u00e5\u0001\u0000\u0000\u0000\u00e7\u0017\u0001"+
		"\u0000\u0000\u0000\u00e8\u00ea\u0005\u0014\u0000\u0000\u00e9\u00eb\u0003"+
		"\u001a\r\u0000\u00ea\u00e9\u0001\u0000\u0000\u0000\u00ea\u00eb\u0001\u0000"+
		"\u0000\u0000\u00eb\u00ec\u0001\u0000\u0000\u0000\u00ec\u00ed\u0005\u0016"+
		"\u0000\u0000\u00ed\u0019\u0001\u0000\u0000\u0000\u00ee\u00f0\u0003\u001c"+
		"\u000e\u0000\u00ef\u00ee\u0001\u0000\u0000\u0000\u00f0\u00f1\u0001\u0000"+
		"\u0000\u0000\u00f1\u00ef\u0001\u0000\u0000\u0000\u00f1\u00f2\u0001\u0000"+
		"\u0000\u0000\u00f2\u001b\u0001\u0000\u0000\u0000\u00f3\u00f7\u0005\u001b"+
		"\u0000\u0000\u00f4\u00f7\u0003\u001e\u000f\u0000\u00f5\u00f7\u0003\"\u0011"+
		"\u0000\u00f6\u00f3\u0001\u0000\u0000\u0000\u00f6\u00f4\u0001\u0000\u0000"+
		"\u0000\u00f6\u00f5\u0001\u0000\u0000\u0000\u00f7\u001d\u0001\u0000\u0000"+
		"\u0000\u00f8\u00f9\u0005\u0017\u0000\u0000\u00f9\u00fa\u0003 \u0010\u0000"+
		"\u00fa\u00fb\u0005z\u0000\u0000\u00fb\u001f\u0001\u0000\u0000\u0000\u00fc"+
		"\u00fd\u0003^/\u0000\u00fd!\u0001\u0000\u0000\u0000\u00fe\u00ff\u0005"+
		"\u0018\u0000\u0000\u00ff\u0100\u00036\u001b\u0000\u0100\u0101\u0005O\u0000"+
		"\u0000\u0101#\u0001\u0000\u0000\u0000\u0102\u0104\u0005\u000b\u0000\u0000"+
		"\u0103\u0102\u0001\u0000\u0000\u0000\u0104\u0105\u0001\u0000\u0000\u0000"+
		"\u0105\u0103\u0001\u0000\u0000\u0000\u0105\u0106\u0001\u0000\u0000\u0000"+
		"\u0106%\u0001\u0000\u0000\u0000\u0107\u010c\u0003(\u0014\u0000\u0108\u010c"+
		"\u0003.\u0017\u0000\u0109\u010c\u00030\u0018\u0000\u010a\u010c\u00032"+
		"\u0019\u0000\u010b\u0107\u0001\u0000\u0000\u0000\u010b\u0108\u0001\u0000"+
		"\u0000\u0000\u010b\u0109\u0001\u0000\u0000\u0000\u010b\u010a\u0001\u0000"+
		"\u0000\u0000\u010c\'\u0001\u0000\u0000\u0000\u010d\u010e\u0005\u0004\u0000"+
		"\u0000\u010e\u010f\u0005 \u0000\u0000\u010f\u0110\u00038\u001c\u0000\u0110"+
		"\u0111\u0005O\u0000\u0000\u0111\u0115\u0003\u0006\u0003\u0000\u0112\u0114"+
		"\u0003*\u0015\u0000\u0113\u0112\u0001\u0000\u0000\u0000\u0114\u0117\u0001"+
		"\u0000\u0000\u0000\u0115\u0113\u0001\u0000\u0000\u0000\u0115\u0116\u0001"+
		"\u0000\u0000\u0000\u0116\u0119\u0001\u0000\u0000\u0000\u0117\u0115\u0001"+
		"\u0000\u0000\u0000\u0118\u011a\u0003,\u0016\u0000\u0119\u0118\u0001\u0000"+
		"\u0000\u0000\u0119\u011a\u0001\u0000\u0000\u0000\u011a\u011b\u0001\u0000"+
		"\u0000\u0000\u011b\u011c\u0005\u0004\u0000\u0000\u011c\u011d\u0005#\u0000"+
		"\u0000\u011d\u011e\u0005O\u0000\u0000\u011e)\u0001\u0000\u0000\u0000\u011f"+
		"\u0120\u0005\u0004\u0000\u0000\u0120\u0121\u0005!\u0000\u0000\u0121\u0122"+
		"\u00038\u001c\u0000\u0122\u0123\u0005O\u0000\u0000\u0123\u0124\u0003\u0006"+
		"\u0003\u0000\u0124+\u0001\u0000\u0000\u0000\u0125\u0126\u0005\u0004\u0000"+
		"\u0000\u0126\u0127\u0005\"\u0000\u0000\u0127\u0128\u0005O\u0000\u0000"+
		"\u0128\u0129\u0003\u0006\u0003\u0000\u0129-\u0001\u0000\u0000\u0000\u012a"+
		"\u012b\u0005\u0004\u0000\u0000\u012b\u012c\u0005$\u0000\u0000\u012c\u012d"+
		"\u0005K\u0000\u0000\u012d\u012e\u0005(\u0000\u0000\u012e\u012f\u00038"+
		"\u001c\u0000\u012f\u0130\u0005O\u0000\u0000\u0130\u0132\u0003\u0006\u0003"+
		"\u0000\u0131\u0133\u0003,\u0016\u0000\u0132\u0131\u0001\u0000\u0000\u0000"+
		"\u0132\u0133\u0001\u0000\u0000\u0000\u0133\u0134\u0001\u0000\u0000\u0000"+
		"\u0134\u0135\u0005\u0004\u0000\u0000\u0135\u0136\u0005%\u0000\u0000\u0136"+
		"\u0137\u0005O\u0000\u0000\u0137/\u0001\u0000\u0000\u0000\u0138\u0139\u0005"+
		"\u0004\u0000\u0000\u0139\u013a\u0005\u001e\u0000\u0000\u013a\u013b\u0005"+
		"K\u0000\u0000\u013b\u013c\u0005O\u0000\u0000\u013c\u013d\u0003\u0006\u0003"+
		"\u0000\u013d\u013e\u0005\u0004\u0000\u0000\u013e\u0140\u0005\u001f\u0000"+
		"\u0000\u013f\u0141\u0005K\u0000\u0000\u0140\u013f\u0001\u0000\u0000\u0000"+
		"\u0140\u0141\u0001\u0000\u0000\u0000\u0141\u0142\u0001\u0000\u0000\u0000"+
		"\u0142\u0143\u0005O\u0000\u0000\u01431\u0001\u0000\u0000\u0000\u0144\u0145"+
		"\u0005\u0004\u0000\u0000\u0145\u0148\u0005,\u0000\u0000\u0146\u0147\u0005"+
		"K\u0000\u0000\u0147\u0149\u0005/\u0000\u0000\u0148\u0146\u0001\u0000\u0000"+
		"\u0000\u0148\u0149\u0001\u0000\u0000\u0000\u0149\u014a\u0001\u0000\u0000"+
		"\u0000\u014a\u014b\u00038\u001c\u0000\u014b\u014c\u0005O\u0000\u0000\u014c"+
		"\u014d\u0003\u0006\u0003\u0000\u014d\u014e\u0005\u0004\u0000\u0000\u014e"+
		"\u014f\u0005-\u0000\u0000\u014f\u0150\u0005O\u0000\u0000\u01503\u0001"+
		"\u0000\u0000\u0000\u0151\u0152\u0005\u0004\u0000\u0000\u0152\u0153\u0003"+
		"6\u001b\u0000\u0153\u0154\u0005O\u0000\u0000\u01545\u0001\u0000\u0000"+
		"\u0000\u0155\u0156\u0005&\u0000\u0000\u0156\u0157\u0005K\u0000\u0000\u0157"+
		"\u0158\u0005/\u0000\u0000\u0158\u016d\u00038\u001c\u0000\u0159\u015a\u0005"+
		"\'\u0000\u0000\u015a\u016d\u0005L\u0000\u0000\u015b\u015c\u0005*\u0000"+
		"\u0000\u015c\u015f\u0005L\u0000\u0000\u015d\u015e\u00050\u0000\u0000\u015e"+
		"\u0160\u0005K\u0000\u0000\u015f\u015d\u0001\u0000\u0000\u0000\u015f\u0160"+
		"\u0001\u0000\u0000\u0000\u0160\u016d\u0001\u0000\u0000\u0000\u0161\u0162"+
		"\u0005+\u0000\u0000\u0162\u0163\u0005L\u0000\u0000\u0163\u0164\u0005*"+
		"\u0000\u0000\u0164\u016d\u0003Z-\u0000\u0165\u0166\u0005\u001d\u0000\u0000"+
		"\u0166\u016d\u0005L\u0000\u0000\u0167\u016a\u0005K\u0000\u0000\u0168\u0169"+
		"\u0005/\u0000\u0000\u0169\u016b\u00038\u001c\u0000\u016a\u0168\u0001\u0000"+
		"\u0000\u0000\u016a\u016b\u0001\u0000\u0000\u0000\u016b\u016d\u0001\u0000"+
		"\u0000\u0000\u016c\u0155\u0001\u0000\u0000\u0000\u016c\u0159\u0001\u0000"+
		"\u0000\u0000\u016c\u015b\u0001\u0000\u0000\u0000\u016c\u0161\u0001\u0000"+
		"\u0000\u0000\u016c\u0165\u0001\u0000\u0000\u0000\u016c\u0167\u0001\u0000"+
		"\u0000\u0000\u016d7\u0001\u0000\u0000\u0000\u016e\u016f\u0003:\u001d\u0000"+
		"\u016f9\u0001\u0000\u0000\u0000\u0170\u0175\u0003<\u001e\u0000\u0171\u0172"+
		"\u00053\u0000\u0000\u0172\u0174\u0003<\u001e\u0000\u0173\u0171\u0001\u0000"+
		"\u0000\u0000\u0174\u0177\u0001\u0000\u0000\u0000\u0175\u0173\u0001\u0000"+
		"\u0000\u0000\u0175\u0176\u0001\u0000\u0000\u0000\u0176;\u0001\u0000\u0000"+
		"\u0000\u0177\u0175\u0001\u0000\u0000\u0000\u0178\u017d\u0003>\u001f\u0000"+
		"\u0179\u017a\u00052\u0000\u0000\u017a\u017c\u0003>\u001f\u0000\u017b\u0179"+
		"\u0001\u0000\u0000\u0000\u017c\u017f\u0001\u0000\u0000\u0000\u017d\u017b"+
		"\u0001\u0000\u0000\u0000\u017d\u017e\u0001\u0000\u0000\u0000\u017e=\u0001"+
		"\u0000\u0000\u0000\u017f\u017d\u0001\u0000\u0000\u0000\u0180\u0185\u0003"+
		"@ \u0000\u0181\u0182\u0007\u0000\u0000\u0000\u0182\u0184\u0003@ \u0000"+
		"\u0183\u0181\u0001\u0000\u0000\u0000\u0184\u0187\u0001\u0000\u0000\u0000"+
		"\u0185\u0183\u0001\u0000\u0000\u0000\u0185\u0186\u0001\u0000\u0000\u0000"+
		"\u0186?\u0001\u0000\u0000\u0000\u0187\u0185\u0001\u0000\u0000\u0000\u0188"+
		"\u018d\u0003B!\u0000\u0189\u018a\u0007\u0001\u0000\u0000\u018a\u018c\u0003"+
		"B!\u0000\u018b\u0189\u0001\u0000\u0000\u0000\u018c\u018f\u0001\u0000\u0000"+
		"\u0000\u018d\u018b\u0001\u0000\u0000\u0000\u018d\u018e\u0001\u0000\u0000"+
		"\u0000\u018eA\u0001\u0000\u0000\u0000\u018f\u018d\u0001\u0000\u0000\u0000"+
		"\u0190\u0195\u0003D\"\u0000\u0191\u0192\u0007\u0002\u0000\u0000\u0192"+
		"\u0194\u0003D\"\u0000\u0193\u0191\u0001\u0000\u0000\u0000\u0194\u0197"+
		"\u0001\u0000\u0000\u0000\u0195\u0193\u0001\u0000\u0000\u0000\u0195\u0196"+
		"\u0001\u0000\u0000\u0000\u0196C\u0001\u0000\u0000\u0000\u0197\u0195\u0001"+
		"\u0000\u0000\u0000\u0198\u019d\u0003F#\u0000\u0199\u019a\u0007\u0003\u0000"+
		"\u0000\u019a\u019c\u0003F#\u0000\u019b\u0199\u0001\u0000\u0000\u0000\u019c"+
		"\u019f\u0001\u0000\u0000\u0000\u019d\u019b\u0001\u0000\u0000\u0000\u019d"+
		"\u019e\u0001\u0000\u0000\u0000\u019eE\u0001\u0000\u0000\u0000\u019f\u019d"+
		"\u0001\u0000\u0000\u0000\u01a0\u01a1\u0007\u0004\u0000\u0000\u01a1\u01a4"+
		"\u0003F#\u0000\u01a2\u01a4\u0003H$\u0000\u01a3\u01a0\u0001\u0000\u0000"+
		"\u0000\u01a3\u01a2\u0001\u0000\u0000\u0000\u01a4G\u0001\u0000\u0000\u0000"+
		"\u01a5\u01a9\u0003J%\u0000\u01a6\u01a8\u0003L&\u0000\u01a7\u01a6\u0001"+
		"\u0000\u0000\u0000\u01a8\u01ab\u0001\u0000\u0000\u0000\u01a9\u01a7\u0001"+
		"\u0000\u0000\u0000\u01a9\u01aa\u0001\u0000\u0000\u0000\u01aaI\u0001\u0000"+
		"\u0000\u0000\u01ab\u01a9\u0001\u0000\u0000\u0000\u01ac\u01ad\u0005@\u0000"+
		"\u0000\u01ad\u01ae\u00038\u001c\u0000\u01ae\u01af\u0005A\u0000\u0000\u01af"+
		"\u01c1\u0001\u0000\u0000\u0000\u01b0\u01c1\u0005K\u0000\u0000\u01b1\u01c1"+
		"\u0005L\u0000\u0000\u01b2\u01c1\u0005M\u0000\u0000\u01b3\u01c1\u0005C"+
		"\u0000\u0000\u01b4\u01c1\u0005D\u0000\u0000\u01b5\u01c1\u0005E\u0000\u0000"+
		"\u01b6\u01b8\u0005F\u0000\u0000\u01b7\u01b9\u0003T*\u0000\u01b8\u01b7"+
		"\u0001\u0000\u0000\u0000\u01b8\u01b9\u0001\u0000\u0000\u0000\u01b9\u01ba"+
		"\u0001\u0000\u0000\u0000\u01ba\u01c1\u0005G\u0000\u0000\u01bb\u01bd\u0005"+
		"H\u0000\u0000\u01bc\u01be\u0003V+\u0000\u01bd\u01bc\u0001\u0000\u0000"+
		"\u0000\u01bd\u01be\u0001\u0000\u0000\u0000\u01be\u01bf\u0001\u0000\u0000"+
		"\u0000\u01bf\u01c1\u0005I\u0000\u0000\u01c0\u01ac\u0001\u0000\u0000\u0000"+
		"\u01c0\u01b0\u0001\u0000\u0000\u0000\u01c0\u01b1\u0001\u0000\u0000\u0000"+
		"\u01c0\u01b2\u0001\u0000\u0000\u0000\u01c0\u01b3\u0001\u0000\u0000\u0000"+
		"\u01c0\u01b4\u0001\u0000\u0000\u0000\u01c0\u01b5\u0001\u0000\u0000\u0000"+
		"\u01c0\u01b6\u0001\u0000\u0000\u0000\u01c0\u01bb\u0001\u0000\u0000\u0000"+
		"\u01c1K\u0001\u0000\u0000\u0000\u01c2\u01c3\u0005B\u0000\u0000\u01c3\u01c9"+
		"\u0005K\u0000\u0000\u01c4\u01c6\u0005@\u0000\u0000\u01c5\u01c7\u0003P"+
		"(\u0000\u01c6\u01c5\u0001\u0000\u0000\u0000\u01c6\u01c7\u0001\u0000\u0000"+
		"\u0000\u01c7\u01c8\u0001\u0000\u0000\u0000\u01c8\u01ca\u0005A\u0000\u0000"+
		"\u01c9\u01c4\u0001\u0000\u0000\u0000\u01c9\u01ca\u0001\u0000\u0000\u0000"+
		"\u01ca\u01d7\u0001\u0000\u0000\u0000\u01cb\u01cd\u0005@\u0000\u0000\u01cc"+
		"\u01ce\u0003P(\u0000\u01cd\u01cc\u0001\u0000\u0000\u0000\u01cd\u01ce\u0001"+
		"\u0000\u0000\u0000\u01ce\u01cf\u0001\u0000\u0000\u0000\u01cf\u01d7\u0005"+
		"A\u0000\u0000\u01d0\u01d1\u0005.\u0000\u0000\u01d1\u01d7\u0005K\u0000"+
		"\u0000\u01d2\u01d3\u0005F\u0000\u0000\u01d3\u01d4\u0003N\'\u0000\u01d4"+
		"\u01d5\u0005G\u0000\u0000\u01d5\u01d7\u0001\u0000\u0000\u0000\u01d6\u01c2"+
		"\u0001\u0000\u0000\u0000\u01d6\u01cb\u0001\u0000\u0000\u0000\u01d6\u01d0"+
		"\u0001\u0000\u0000\u0000\u01d6\u01d2\u0001\u0000\u0000\u0000\u01d7M\u0001"+
		"\u0000\u0000\u0000\u01d8\u01e7\u00038\u001c\u0000\u01d9\u01db\u00038\u001c"+
		"\u0000\u01da\u01d9\u0001\u0000\u0000\u0000\u01da\u01db\u0001\u0000\u0000"+
		"\u0000\u01db\u01dc\u0001\u0000\u0000\u0000\u01dc\u01de\u0005J\u0000\u0000"+
		"\u01dd\u01df\u00038\u001c\u0000\u01de\u01dd\u0001\u0000\u0000\u0000\u01de"+
		"\u01df\u0001\u0000\u0000\u0000\u01df\u01e4\u0001\u0000\u0000\u0000\u01e0"+
		"\u01e2\u0005J\u0000\u0000\u01e1\u01e3\u00038\u001c\u0000\u01e2\u01e1\u0001"+
		"\u0000\u0000\u0000\u01e2\u01e3\u0001\u0000\u0000\u0000\u01e3\u01e5\u0001"+
		"\u0000\u0000\u0000\u01e4\u01e0\u0001\u0000\u0000\u0000\u01e4\u01e5\u0001"+
		"\u0000\u0000\u0000\u01e5\u01e7\u0001\u0000\u0000\u0000\u01e6\u01d8\u0001"+
		"\u0000\u0000\u0000\u01e6\u01da\u0001\u0000\u0000\u0000\u01e7O\u0001\u0000"+
		"\u0000\u0000\u01e8\u01ed\u0003R)\u0000\u01e9\u01ea\u00051\u0000\u0000"+
		"\u01ea\u01ec\u0003R)\u0000\u01eb\u01e9\u0001\u0000\u0000\u0000\u01ec\u01ef"+
		"\u0001\u0000\u0000\u0000\u01ed\u01eb\u0001\u0000\u0000\u0000\u01ed\u01ee"+
		"\u0001\u0000\u0000\u0000\u01eeQ\u0001\u0000\u0000\u0000\u01ef\u01ed\u0001"+
		"\u0000\u0000\u0000\u01f0\u01f1\u0005K\u0000\u0000\u01f1\u01f2\u0005/\u0000"+
		"\u0000\u01f2\u01f5\u00038\u001c\u0000\u01f3\u01f5\u00038\u001c\u0000\u01f4"+
		"\u01f0\u0001\u0000\u0000\u0000\u01f4\u01f3\u0001\u0000\u0000\u0000\u01f5"+
		"S\u0001\u0000\u0000\u0000\u01f6\u01fb\u00038\u001c\u0000\u01f7\u01f8\u0005"+
		"1\u0000\u0000\u01f8\u01fa\u00038\u001c\u0000\u01f9\u01f7\u0001\u0000\u0000"+
		"\u0000\u01fa\u01fd\u0001\u0000\u0000\u0000\u01fb\u01f9\u0001\u0000\u0000"+
		"\u0000\u01fb\u01fc\u0001\u0000\u0000\u0000\u01fcU\u0001\u0000\u0000\u0000"+
		"\u01fd\u01fb\u0001\u0000\u0000\u0000\u01fe\u0203\u0003X,\u0000\u01ff\u0200"+
		"\u00051\u0000\u0000\u0200\u0202\u0003X,\u0000\u0201\u01ff\u0001\u0000"+
		"\u0000\u0000\u0202\u0205\u0001\u0000\u0000\u0000\u0203\u0201\u0001\u0000"+
		"\u0000\u0000\u0203\u0204\u0001\u0000\u0000\u0000\u0204W\u0001\u0000\u0000"+
		"\u0000\u0205\u0203\u0001\u0000\u0000\u0000\u0206\u0207\u00038\u001c\u0000"+
		"\u0207\u0208\u0005J\u0000\u0000\u0208\u0209\u00038\u001c\u0000\u0209Y"+
		"\u0001\u0000\u0000\u0000\u020a\u020f\u0005K\u0000\u0000\u020b\u020c\u0005"+
		"1\u0000\u0000\u020c\u020e\u0005K\u0000\u0000\u020d\u020b\u0001\u0000\u0000"+
		"\u0000\u020e\u0211\u0001\u0000\u0000\u0000\u020f\u020d\u0001\u0000\u0000"+
		"\u0000\u020f\u0210\u0001\u0000\u0000\u0000\u0210[\u0001\u0000\u0000\u0000"+
		"\u0211\u020f\u0001\u0000\u0000\u0000\u0212\u0213\u0005\u0005\u0000\u0000"+
		"\u0213\u0214\u0003^/\u0000\u0214\u0215\u0005z\u0000\u0000\u0215]\u0001"+
		"\u0000\u0000\u0000\u0216\u0217\u0003`0\u0000\u0217_\u0001\u0000\u0000"+
		"\u0000\u0218\u0219\u0003b1\u0000\u0219a\u0001\u0000\u0000\u0000\u021a"+
		"\u021f\u0003d2\u0000\u021b\u021c\u0005k\u0000\u0000\u021c\u021e\u0003"+
		"d2\u0000\u021d\u021b\u0001\u0000\u0000\u0000\u021e\u0221\u0001\u0000\u0000"+
		"\u0000\u021f\u021d\u0001\u0000\u0000\u0000\u021f\u0220\u0001\u0000\u0000"+
		"\u0000\u0220c\u0001\u0000\u0000\u0000\u0221\u021f\u0001\u0000\u0000\u0000"+
		"\u0222\u0227\u0003f3\u0000\u0223\u0224\u0005j\u0000\u0000\u0224\u0226"+
		"\u0003f3\u0000\u0225\u0223\u0001\u0000\u0000\u0000\u0226\u0229\u0001\u0000"+
		"\u0000\u0000\u0227\u0225\u0001\u0000\u0000\u0000\u0227\u0228\u0001\u0000"+
		"\u0000\u0000\u0228e\u0001\u0000\u0000\u0000\u0229\u0227\u0001\u0000\u0000"+
		"\u0000\u022a\u022f\u0003h4\u0000\u022b\u022c\u0007\u0005\u0000\u0000\u022c"+
		"\u022e\u0003h4\u0000\u022d\u022b\u0001\u0000\u0000\u0000\u022e\u0231\u0001"+
		"\u0000\u0000\u0000\u022f\u022d\u0001\u0000\u0000\u0000\u022f\u0230\u0001"+
		"\u0000\u0000\u0000\u0230g\u0001\u0000\u0000\u0000\u0231\u022f\u0001\u0000"+
		"\u0000\u0000\u0232\u0237\u0003j5\u0000\u0233\u0234\u0007\u0006\u0000\u0000"+
		"\u0234\u0236\u0003j5\u0000\u0235\u0233\u0001\u0000\u0000\u0000\u0236\u0239"+
		"\u0001\u0000\u0000\u0000\u0237\u0235\u0001\u0000\u0000\u0000\u0237\u0238"+
		"\u0001\u0000\u0000\u0000\u0238i\u0001\u0000\u0000\u0000\u0239\u0237\u0001"+
		"\u0000\u0000\u0000\u023a\u023f\u0003l6\u0000\u023b\u023c\u0007\u0007\u0000"+
		"\u0000\u023c\u023e\u0003l6\u0000\u023d\u023b\u0001\u0000\u0000\u0000\u023e"+
		"\u0241\u0001\u0000\u0000\u0000\u023f\u023d\u0001\u0000\u0000\u0000\u023f"+
		"\u0240\u0001\u0000\u0000\u0000\u0240k\u0001\u0000\u0000\u0000\u0241\u023f"+
		"\u0001\u0000\u0000\u0000\u0242\u0247\u0003n7\u0000\u0243\u0244\u0007\b"+
		"\u0000\u0000\u0244\u0246\u0003n7\u0000\u0245\u0243\u0001\u0000\u0000\u0000"+
		"\u0246\u0249\u0001\u0000\u0000\u0000\u0247\u0245\u0001\u0000\u0000\u0000"+
		"\u0247\u0248\u0001\u0000\u0000\u0000\u0248m\u0001\u0000\u0000\u0000\u0249"+
		"\u0247\u0001\u0000\u0000\u0000\u024a\u024b\u0007\t\u0000\u0000\u024b\u024e"+
		"\u0003n7\u0000\u024c\u024e\u0003p8\u0000\u024d\u024a\u0001\u0000\u0000"+
		"\u0000\u024d\u024c\u0001\u0000\u0000\u0000\u024eo\u0001\u0000\u0000\u0000"+
		"\u024f\u0253\u0003r9\u0000\u0250\u0252\u0003t:\u0000\u0251\u0250\u0001"+
		"\u0000\u0000\u0000\u0252\u0255\u0001\u0000\u0000\u0000\u0253\u0251\u0001"+
		"\u0000\u0000\u0000\u0253\u0254\u0001\u0000\u0000\u0000\u0254q\u0001\u0000"+
		"\u0000\u0000\u0255\u0253\u0001\u0000\u0000\u0000\u0256\u0257\u0005P\u0000"+
		"\u0000\u0257\u0258\u0003`0\u0000\u0258\u0259\u0005Q\u0000\u0000\u0259"+
		"\u026b\u0001\u0000\u0000\u0000\u025a\u026b\u0005t\u0000\u0000\u025b\u026b"+
		"\u0005u\u0000\u0000\u025c\u026b\u0005v\u0000\u0000\u025d\u026b\u0005q"+
		"\u0000\u0000\u025e\u026b\u0005r\u0000\u0000\u025f\u026b\u0005s\u0000\u0000"+
		"\u0260\u0262\u0005R\u0000\u0000\u0261\u0263\u0003|>\u0000\u0262\u0261"+
		"\u0001\u0000\u0000\u0000\u0262\u0263\u0001\u0000\u0000\u0000\u0263\u0264"+
		"\u0001\u0000\u0000\u0000\u0264\u026b\u0005S\u0000\u0000\u0265\u0267\u0005"+
		"T\u0000\u0000\u0266\u0268\u0003~?\u0000\u0267\u0266\u0001\u0000\u0000"+
		"\u0000\u0267\u0268\u0001\u0000\u0000\u0000\u0268\u0269\u0001\u0000\u0000"+
		"\u0000\u0269\u026b\u0005U\u0000\u0000\u026a\u0256\u0001\u0000\u0000\u0000"+
		"\u026a\u025a\u0001\u0000\u0000\u0000\u026a\u025b\u0001\u0000\u0000\u0000"+
		"\u026a\u025c\u0001\u0000\u0000\u0000\u026a\u025d\u0001\u0000\u0000\u0000"+
		"\u026a\u025e\u0001\u0000\u0000\u0000\u026a\u025f\u0001\u0000\u0000\u0000"+
		"\u026a\u0260\u0001\u0000\u0000\u0000\u026a\u0265\u0001\u0000\u0000\u0000"+
		"\u026bs\u0001\u0000\u0000\u0000\u026c\u026d\u0005Y\u0000\u0000\u026d\u0273"+
		"\u0005t\u0000\u0000\u026e\u0270\u0005P\u0000\u0000\u026f\u0271\u0003x"+
		"<\u0000\u0270\u026f\u0001\u0000\u0000\u0000\u0270\u0271\u0001\u0000\u0000"+
		"\u0000\u0271\u0272\u0001\u0000\u0000\u0000\u0272\u0274\u0005Q\u0000\u0000"+
		"\u0273\u026e\u0001\u0000\u0000\u0000\u0273\u0274\u0001\u0000\u0000\u0000"+
		"\u0274\u0281\u0001\u0000\u0000\u0000\u0275\u0277\u0005P\u0000\u0000\u0276"+
		"\u0278\u0003x<\u0000\u0277\u0276\u0001\u0000\u0000\u0000\u0277\u0278\u0001"+
		"\u0000\u0000\u0000\u0278\u0279\u0001\u0000\u0000\u0000\u0279\u0281\u0005"+
		"Q\u0000\u0000\u027a\u027b\u0005X\u0000\u0000\u027b\u0281\u0005t\u0000"+
		"\u0000\u027c\u027d\u0005R\u0000\u0000\u027d\u027e\u0003v;\u0000\u027e"+
		"\u027f\u0005S\u0000\u0000\u027f\u0281\u0001\u0000\u0000\u0000\u0280\u026c"+
		"\u0001\u0000\u0000\u0000\u0280\u0275\u0001\u0000\u0000\u0000\u0280\u027a"+
		"\u0001\u0000\u0000\u0000\u0280\u027c\u0001\u0000\u0000\u0000\u0281u\u0001"+
		"\u0000\u0000\u0000\u0282\u0291\u0003`0\u0000\u0283\u0285\u0003`0\u0000"+
		"\u0284\u0283\u0001\u0000\u0000\u0000\u0284\u0285\u0001\u0000\u0000\u0000"+
		"\u0285\u0286\u0001\u0000\u0000\u0000\u0286\u0288\u0005W\u0000\u0000\u0287"+
		"\u0289\u0003`0\u0000\u0288\u0287\u0001\u0000\u0000\u0000\u0288\u0289\u0001"+
		"\u0000\u0000\u0000\u0289\u028e\u0001\u0000\u0000\u0000\u028a\u028c\u0005"+
		"W\u0000\u0000\u028b\u028d\u0003`0\u0000\u028c\u028b\u0001\u0000\u0000"+
		"\u0000\u028c\u028d\u0001\u0000\u0000\u0000\u028d\u028f\u0001\u0000\u0000"+
		"\u0000\u028e\u028a\u0001\u0000\u0000\u0000\u028e\u028f\u0001\u0000\u0000"+
		"\u0000\u028f\u0291\u0001\u0000\u0000\u0000\u0290\u0282\u0001\u0000\u0000"+
		"\u0000\u0290\u0284\u0001\u0000\u0000\u0000\u0291w\u0001\u0000\u0000\u0000"+
		"\u0292\u0297\u0003z=\u0000\u0293\u0294\u0005V\u0000\u0000\u0294\u0296"+
		"\u0003z=\u0000\u0295\u0293\u0001\u0000\u0000\u0000\u0296\u0299\u0001\u0000"+
		"\u0000\u0000\u0297\u0295\u0001\u0000\u0000\u0000\u0297\u0298\u0001\u0000"+
		"\u0000\u0000\u0298y\u0001\u0000\u0000\u0000\u0299\u0297\u0001\u0000\u0000"+
		"\u0000\u029a\u029b\u0005t\u0000\u0000\u029b\u029c\u0005c\u0000\u0000\u029c"+
		"\u029f\u0003`0\u0000\u029d\u029f\u0003`0\u0000\u029e\u029a\u0001\u0000"+
		"\u0000\u0000\u029e\u029d\u0001\u0000\u0000\u0000\u029f{\u0001\u0000\u0000"+
		"\u0000\u02a0\u02a5\u0003`0\u0000\u02a1\u02a2\u0005V\u0000\u0000\u02a2"+
		"\u02a4\u0003`0\u0000\u02a3\u02a1\u0001\u0000\u0000\u0000\u02a4\u02a7\u0001"+
		"\u0000\u0000\u0000\u02a5\u02a3\u0001\u0000\u0000\u0000\u02a5\u02a6\u0001"+
		"\u0000\u0000\u0000\u02a6}\u0001\u0000\u0000\u0000\u02a7\u02a5\u0001\u0000"+
		"\u0000\u0000\u02a8\u02ad\u0003\u0080@\u0000\u02a9\u02aa\u0005V\u0000\u0000"+
		"\u02aa\u02ac\u0003\u0080@\u0000\u02ab\u02a9\u0001\u0000\u0000\u0000\u02ac"+
		"\u02af\u0001\u0000\u0000\u0000\u02ad\u02ab\u0001\u0000\u0000\u0000\u02ad"+
		"\u02ae\u0001\u0000\u0000\u0000\u02ae\u007f\u0001\u0000\u0000\u0000\u02af"+
		"\u02ad\u0001\u0000\u0000\u0000\u02b0\u02b1\u0003`0\u0000\u02b1\u02b2\u0005"+
		"W\u0000\u0000\u02b2\u02b3\u0003`0\u0000\u02b3\u0081\u0001\u0000\u0000"+
		"\u0000\u02b4\u02b6\u0005\u0007\u0000\u0000\u02b5\u02b7\u0003\u0084B\u0000"+
		"\u02b6\u02b5\u0001\u0000\u0000\u0000\u02b6\u02b7\u0001\u0000\u0000\u0000"+
		"\u02b7\u02b8\u0001\u0000\u0000\u0000\u02b8\u02b9\u0005~\u0000\u0000\u02b9"+
		"\u02ba\u0003\u0088D\u0000\u02ba\u02bb\u0005\u0083\u0000\u0000\u02bb\u0083"+
		"\u0001\u0000\u0000\u0000\u02bc\u02be\u0003\u0086C\u0000\u02bd\u02bc\u0001"+
		"\u0000\u0000\u0000\u02be\u02c1\u0001\u0000\u0000\u0000\u02bf\u02bd\u0001"+
		"\u0000\u0000\u0000\u02bf\u02c0\u0001\u0000\u0000\u0000\u02c0\u0085\u0001"+
		"\u0000\u0000\u0000\u02c1\u02bf\u0001\u0000\u0000\u0000\u02c2\u02c3\u0005"+
		"\u007f\u0000\u0000\u02c3\u02c4\u0005\u0080\u0000\u0000\u02c4\u02c5\u0005"+
		"\u0081\u0000\u0000\u02c5\u0087\u0001\u0000\u0000\u0000\u02c6\u02c8\u0003"+
		"\u008aE\u0000\u02c7\u02c6\u0001\u0000\u0000\u0000\u02c8\u02cb\u0001\u0000"+
		"\u0000\u0000\u02c9\u02c7\u0001\u0000\u0000\u0000\u02c9\u02ca\u0001\u0000"+
		"\u0000\u0000\u02ca\u0089\u0001\u0000\u0000\u0000\u02cb\u02c9\u0001\u0000"+
		"\u0000\u0000\u02cc\u02d0\u0003\u008cF\u0000\u02cd\u02cf\u0005\u0087\u0000"+
		"\u0000\u02ce\u02cd\u0001\u0000\u0000\u0000\u02cf\u02d2\u0001\u0000\u0000"+
		"\u0000\u02d0\u02ce\u0001\u0000\u0000\u0000\u02d0\u02d1\u0001\u0000\u0000"+
		"\u0000\u02d1\u02d3\u0001\u0000\u0000\u0000\u02d2\u02d0\u0001\u0000\u0000"+
		"\u0000\u02d3\u02d4\u0005\u0085\u0000\u0000\u02d4\u02d5\u0003\u0090H\u0000"+
		"\u02d5\u02d6\u0005\u0088\u0000\u0000\u02d6\u008b\u0001\u0000\u0000\u0000"+
		"\u02d7\u02dc\u0003\u008eG\u0000\u02d8\u02d9\u0005\u008b\u0000\u0000\u02d9"+
		"\u02db\u0003\u008eG\u0000\u02da\u02d8\u0001\u0000\u0000\u0000\u02db\u02de"+
		"\u0001\u0000\u0000\u0000\u02dc\u02da\u0001\u0000\u0000\u0000\u02dc\u02dd"+
		"\u0001\u0000\u0000\u0000\u02dd\u008d\u0001\u0000\u0000\u0000\u02de\u02dc"+
		"\u0001\u0000\u0000\u0000\u02df\u02e4\u0005\u0087\u0000\u0000\u02e0\u02e1"+
		"\u0005\u008c\u0000\u0000\u02e1\u02e3\u0005\u0087\u0000\u0000\u02e2\u02e0"+
		"\u0001\u0000\u0000\u0000\u02e3\u02e6\u0001\u0000\u0000\u0000\u02e4\u02e2"+
		"\u0001\u0000\u0000\u0000\u02e4\u02e5\u0001\u0000\u0000\u0000\u02e5\u008f"+
		"\u0001\u0000\u0000\u0000\u02e6\u02e4\u0001\u0000\u0000\u0000\u02e7\u02e9"+
		"\u0003\u0092I\u0000\u02e8\u02e7\u0001\u0000\u0000\u0000\u02e9\u02ec\u0001"+
		"\u0000\u0000\u0000\u02ea\u02e8\u0001\u0000\u0000\u0000\u02ea\u02eb\u0001"+
		"\u0000\u0000\u0000\u02eb\u0091\u0001\u0000\u0000\u0000\u02ec\u02ea\u0001"+
		"\u0000\u0000\u0000\u02ed\u02ee\u0005\u008d\u0000\u0000\u02ee\u02ef\u0005"+
		"\u0089\u0000\u0000\u02ef\u02f0\u0003\u0094J\u0000\u02f0\u02f1\u0005\u008a"+
		"\u0000\u0000\u02f1\u0093\u0001\u0000\u0000\u0000\u02f2\u02f9\u0003\u0096"+
		"K\u0000\u02f3\u02f5\u0005\u008b\u0000\u0000\u02f4\u02f3\u0001\u0000\u0000"+
		"\u0000\u02f4\u02f5\u0001\u0000\u0000\u0000\u02f5\u02f6\u0001\u0000\u0000"+
		"\u0000\u02f6\u02f8\u0003\u0096K\u0000\u02f7\u02f4\u0001\u0000\u0000\u0000"+
		"\u02f8\u02fb\u0001\u0000\u0000\u0000\u02f9\u02f7\u0001\u0000\u0000\u0000"+
		"\u02f9\u02fa\u0001\u0000\u0000\u0000\u02fa\u0095\u0001\u0000\u0000\u0000"+
		"\u02fb\u02f9\u0001\u0000\u0000\u0000\u02fc\u0301\u0005\u0092\u0000\u0000"+
		"\u02fd\u0301\u0005\u0090\u0000\u0000\u02fe\u0301\u0005\u0091\u0000\u0000"+
		"\u02ff\u0301\u0005\u0093\u0000\u0000\u0300\u02fc\u0001\u0000\u0000\u0000"+
		"\u0300\u02fd\u0001\u0000\u0000\u0000\u0300\u02fe\u0001\u0000\u0000\u0000"+
		"\u0300\u02ff\u0001\u0000\u0000\u0000\u0301\u0097\u0001\u0000\u0000\u0000"+
		"Q\u0099\u009d\u00a2\u00b3\u00bd\u00c1\u00c7\u00df\u00e6\u00ea\u00f1\u00f6"+
		"\u0105\u010b\u0115\u0119\u0132\u0140\u0148\u015f\u016a\u016c\u0175\u017d"+
		"\u0185\u018d\u0195\u019d\u01a3\u01a9\u01b8\u01bd\u01c0\u01c6\u01c9\u01cd"+
		"\u01d6\u01da\u01de\u01e2\u01e4\u01e6\u01ed\u01f4\u01fb\u0203\u020f\u021f"+
		"\u0227\u022f\u0237\u023f\u0247\u024d\u0253\u0262\u0267\u026a\u0270\u0273"+
		"\u0277\u0280\u0284\u0288\u028c\u028e\u0290\u0297\u029e\u02a5\u02ad\u02b6"+
		"\u02bf\u02c9\u02d0\u02dc\u02e4\u02ea\u02f4\u02f9\u0300";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}