// Generated from FlaskTemplateParser.g4 by ANTLR 4.13.2
package gen;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link FlaskTemplateParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface FlaskTemplateParserVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by the {@code templateRoot}
	 * labeled alternative in {@link FlaskTemplateParser#template}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTemplateRoot(FlaskTemplateParser.TemplateRootContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#doctype}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDoctype(FlaskTemplateParser.DoctypeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code htmlDocument}
	 * labeled alternative in {@link FlaskTemplateParser#html}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHtmlDocument(FlaskTemplateParser.HtmlDocumentContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#templateContent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTemplateContent(FlaskTemplateParser.TemplateContentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code htmlContent}
	 * labeled alternative in {@link FlaskTemplateParser#contentItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHtmlContent(FlaskTemplateParser.HtmlContentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code jinjaBlockContent}
	 * labeled alternative in {@link FlaskTemplateParser#contentItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJinjaBlockContent(FlaskTemplateParser.JinjaBlockContentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code jinjaTagContent}
	 * labeled alternative in {@link FlaskTemplateParser#contentItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJinjaTagContent(FlaskTemplateParser.JinjaTagContentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code jinjaExprContent}
	 * labeled alternative in {@link FlaskTemplateParser#contentItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJinjaExprContent(FlaskTemplateParser.JinjaExprContentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code htmlTextContent}
	 * labeled alternative in {@link FlaskTemplateParser#contentItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHtmlTextContent(FlaskTemplateParser.HtmlTextContentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code cssContent}
	 * labeled alternative in {@link FlaskTemplateParser#contentItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCssContent(FlaskTemplateParser.CssContentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code newlineContent}
	 * labeled alternative in {@link FlaskTemplateParser#contentItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNewlineContent(FlaskTemplateParser.NewlineContentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code normalElement}
	 * labeled alternative in {@link FlaskTemplateParser#htmlElement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNormalElement(FlaskTemplateParser.NormalElementContext ctx);
	/**
	 * Visit a parse tree produced by the {@code voidElementTag}
	 * labeled alternative in {@link FlaskTemplateParser#htmlElement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVoidElementTag(FlaskTemplateParser.VoidElementTagContext ctx);
	/**
	 * Visit a parse tree produced by the {@code selfClosingElementTag}
	 * labeled alternative in {@link FlaskTemplateParser#htmlElement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelfClosingElementTag(FlaskTemplateParser.SelfClosingElementTagContext ctx);
	/**
	 * Visit a parse tree produced by the {@code openingTagNode}
	 * labeled alternative in {@link FlaskTemplateParser#openingTag}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOpeningTagNode(FlaskTemplateParser.OpeningTagNodeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code closingTagNode}
	 * labeled alternative in {@link FlaskTemplateParser#closingTag}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClosingTagNode(FlaskTemplateParser.ClosingTagNodeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code selfClosingTagNode}
	 * labeled alternative in {@link FlaskTemplateParser#selfClosingTag}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSelfClosingTagNode(FlaskTemplateParser.SelfClosingTagNodeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code voidTagNode}
	 * labeled alternative in {@link FlaskTemplateParser#voidTag}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVoidTagNode(FlaskTemplateParser.VoidTagNodeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code htmlAttributeList}
	 * labeled alternative in {@link FlaskTemplateParser#htmlAttributes}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHtmlAttributeList(FlaskTemplateParser.HtmlAttributeListContext ctx);
	/**
	 * Visit a parse tree produced by the {@code attributeWithValue}
	 * labeled alternative in {@link FlaskTemplateParser#htmlAttribute}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAttributeWithValue(FlaskTemplateParser.AttributeWithValueContext ctx);
	/**
	 * Visit a parse tree produced by the {@code booleanAttribute}
	 * labeled alternative in {@link FlaskTemplateParser#htmlAttribute}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBooleanAttribute(FlaskTemplateParser.BooleanAttributeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code doubleQuotedValue}
	 * labeled alternative in {@link FlaskTemplateParser#htmlAttributeValue}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDoubleQuotedValue(FlaskTemplateParser.DoubleQuotedValueContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#attrValueContent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAttrValueContent(FlaskTemplateParser.AttrValueContentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code attrText}
	 * labeled alternative in {@link FlaskTemplateParser#attrValueItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAttrText(FlaskTemplateParser.AttrTextContext ctx);
	/**
	 * Visit a parse tree produced by the {@code attrJinjaExprItem}
	 * labeled alternative in {@link FlaskTemplateParser#attrValueItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAttrJinjaExprItem(FlaskTemplateParser.AttrJinjaExprItemContext ctx);
	/**
	 * Visit a parse tree produced by the {@code attrJinjaBlockItem}
	 * labeled alternative in {@link FlaskTemplateParser#attrValueItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAttrJinjaBlockItem(FlaskTemplateParser.AttrJinjaBlockItemContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#attrJinjaExpr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAttrJinjaExpr(FlaskTemplateParser.AttrJinjaExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#attrJinjaExprContent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAttrJinjaExprContent(FlaskTemplateParser.AttrJinjaExprContentContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#attrJinjaBlock}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAttrJinjaBlock(FlaskTemplateParser.AttrJinjaBlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#htmlText}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHtmlText(FlaskTemplateParser.HtmlTextContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#jinjaBlock}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJinjaBlock(FlaskTemplateParser.JinjaBlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#ifBlock}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfBlock(FlaskTemplateParser.IfBlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#elifClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElifClause(FlaskTemplateParser.ElifClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#elseClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElseClause(FlaskTemplateParser.ElseClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#forBlock}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitForBlock(FlaskTemplateParser.ForBlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#blockBlock}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockBlock(FlaskTemplateParser.BlockBlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#withBlock}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWithBlock(FlaskTemplateParser.WithBlockContext ctx);
	/**
	 * Visit a parse tree produced by the {@code jinjaTagNode}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaTag}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJinjaTagNode(FlaskTemplateParser.JinjaTagNodeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code setBlock}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaTagStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSetBlock(FlaskTemplateParser.SetBlockContext ctx);
	/**
	 * Visit a parse tree produced by the {@code includeBlock}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaTagStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIncludeBlock(FlaskTemplateParser.IncludeBlockContext ctx);
	/**
	 * Visit a parse tree produced by the {@code importBlock}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaTagStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitImportBlock(FlaskTemplateParser.ImportBlockContext ctx);
	/**
	 * Visit a parse tree produced by the {@code fromImportBlock}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaTagStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFromImportBlock(FlaskTemplateParser.FromImportBlockContext ctx);
	/**
	 * Visit a parse tree produced by the {@code extendsBlock}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaTagStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExtendsBlock(FlaskTemplateParser.ExtendsBlockContext ctx);
	/**
	 * Visit a parse tree produced by the {@code genericBlock}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaTagStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGenericBlock(FlaskTemplateParser.GenericBlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#blockExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockExpression(FlaskTemplateParser.BlockExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#blockLogicalOrExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockLogicalOrExpression(FlaskTemplateParser.BlockLogicalOrExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#blockLogicalAndExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockLogicalAndExpression(FlaskTemplateParser.BlockLogicalAndExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#blockEqualityExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockEqualityExpression(FlaskTemplateParser.BlockEqualityExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#blockComparisonExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockComparisonExpression(FlaskTemplateParser.BlockComparisonExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#blockAdditiveExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockAdditiveExpression(FlaskTemplateParser.BlockAdditiveExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#blockMultiplicativeExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockMultiplicativeExpression(FlaskTemplateParser.BlockMultiplicativeExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code blockUnaryOp}
	 * labeled alternative in {@link FlaskTemplateParser#blockUnaryExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockUnaryOp(FlaskTemplateParser.BlockUnaryOpContext ctx);
	/**
	 * Visit a parse tree produced by the {@code blockUnaryBase}
	 * labeled alternative in {@link FlaskTemplateParser#blockUnaryExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockUnaryBase(FlaskTemplateParser.BlockUnaryBaseContext ctx);
	/**
	 * Visit a parse tree produced by the {@code blockPrimary}
	 * labeled alternative in {@link FlaskTemplateParser#blockPrimaryExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockPrimary(FlaskTemplateParser.BlockPrimaryContext ctx);
	/**
	 * Visit a parse tree produced by the {@code blockParenExpr}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockParenExpr(FlaskTemplateParser.BlockParenExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code blockIdentifier}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockIdentifier(FlaskTemplateParser.BlockIdentifierContext ctx);
	/**
	 * Visit a parse tree produced by the {@code blockStringLiteral}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockStringLiteral(FlaskTemplateParser.BlockStringLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code blockNumberLiteral}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockNumberLiteral(FlaskTemplateParser.BlockNumberLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code blockTrueLiteral}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockTrueLiteral(FlaskTemplateParser.BlockTrueLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code blockFalseLiteral}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockFalseLiteral(FlaskTemplateParser.BlockFalseLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code blockNoneLiteral}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockNoneLiteral(FlaskTemplateParser.BlockNoneLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code blockListLiteral}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockListLiteral(FlaskTemplateParser.BlockListLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code blockDictLiteral}
	 * labeled alternative in {@link FlaskTemplateParser#blockAtom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockDictLiteral(FlaskTemplateParser.BlockDictLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code blockFilterOp}
	 * labeled alternative in {@link FlaskTemplateParser#blockPostfix}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockFilterOp(FlaskTemplateParser.BlockFilterOpContext ctx);
	/**
	 * Visit a parse tree produced by the {@code blockCallOp}
	 * labeled alternative in {@link FlaskTemplateParser#blockPostfix}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockCallOp(FlaskTemplateParser.BlockCallOpContext ctx);
	/**
	 * Visit a parse tree produced by the {@code blockMemberOp}
	 * labeled alternative in {@link FlaskTemplateParser#blockPostfix}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockMemberOp(FlaskTemplateParser.BlockMemberOpContext ctx);
	/**
	 * Visit a parse tree produced by the {@code blockIndexOp}
	 * labeled alternative in {@link FlaskTemplateParser#blockPostfix}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockIndexOp(FlaskTemplateParser.BlockIndexOpContext ctx);
	/**
	 * Visit a parse tree produced by the {@code blockIndex}
	 * labeled alternative in {@link FlaskTemplateParser#blockSliceItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockIndex(FlaskTemplateParser.BlockIndexContext ctx);
	/**
	 * Visit a parse tree produced by the {@code blockSlice}
	 * labeled alternative in {@link FlaskTemplateParser#blockSliceItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockSlice(FlaskTemplateParser.BlockSliceContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#blockArgumentList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockArgumentList(FlaskTemplateParser.BlockArgumentListContext ctx);
	/**
	 * Visit a parse tree produced by the {@code blockKeywordArgument}
	 * labeled alternative in {@link FlaskTemplateParser#blockArgument}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockKeywordArgument(FlaskTemplateParser.BlockKeywordArgumentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code blockPositionalArgument}
	 * labeled alternative in {@link FlaskTemplateParser#blockArgument}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockPositionalArgument(FlaskTemplateParser.BlockPositionalArgumentContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#blockExpressionList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockExpressionList(FlaskTemplateParser.BlockExpressionListContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#blockDictPairList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockDictPairList(FlaskTemplateParser.BlockDictPairListContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#blockDictPair}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockDictPair(FlaskTemplateParser.BlockDictPairContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#importList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitImportList(FlaskTemplateParser.ImportListContext ctx);
	/**
	 * Visit a parse tree produced by the {@code jinjaExprNode}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaExpr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJinjaExprNode(FlaskTemplateParser.JinjaExprNodeContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#jinjaExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitJinjaExpression(FlaskTemplateParser.JinjaExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code expressionRoot}
	 * labeled alternative in {@link FlaskTemplateParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpressionRoot(FlaskTemplateParser.ExpressionRootContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#logicalOrExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLogicalOrExpression(FlaskTemplateParser.LogicalOrExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#logicalAndExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLogicalAndExpression(FlaskTemplateParser.LogicalAndExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#equalityExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEqualityExpression(FlaskTemplateParser.EqualityExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#comparisonExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComparisonExpression(FlaskTemplateParser.ComparisonExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#additiveExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAdditiveExpression(FlaskTemplateParser.AdditiveExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#multiplicativeExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMultiplicativeExpression(FlaskTemplateParser.MultiplicativeExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unaryOp}
	 * labeled alternative in {@link FlaskTemplateParser#unaryExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryOp(FlaskTemplateParser.UnaryOpContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unaryBase}
	 * labeled alternative in {@link FlaskTemplateParser#unaryExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryBase(FlaskTemplateParser.UnaryBaseContext ctx);
	/**
	 * Visit a parse tree produced by the {@code primary}
	 * labeled alternative in {@link FlaskTemplateParser#primaryExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrimary(FlaskTemplateParser.PrimaryContext ctx);
	/**
	 * Visit a parse tree produced by the {@code parenExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParenExpr(FlaskTemplateParser.ParenExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code identifierExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentifierExpr(FlaskTemplateParser.IdentifierExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code stringExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringExpr(FlaskTemplateParser.StringExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code numberExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumberExpr(FlaskTemplateParser.NumberExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code trueExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTrueExpr(FlaskTemplateParser.TrueExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code falseExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFalseExpr(FlaskTemplateParser.FalseExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code noneExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNoneExpr(FlaskTemplateParser.NoneExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code listExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitListExpr(FlaskTemplateParser.ListExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code dictExpr}
	 * labeled alternative in {@link FlaskTemplateParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDictExpr(FlaskTemplateParser.DictExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code filterExpr}
	 * labeled alternative in {@link FlaskTemplateParser#postfix}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFilterExpr(FlaskTemplateParser.FilterExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code callExpr}
	 * labeled alternative in {@link FlaskTemplateParser#postfix}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCallExpr(FlaskTemplateParser.CallExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code memberOp}
	 * labeled alternative in {@link FlaskTemplateParser#postfix}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMemberOp(FlaskTemplateParser.MemberOpContext ctx);
	/**
	 * Visit a parse tree produced by the {@code indexOp}
	 * labeled alternative in {@link FlaskTemplateParser#postfix}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIndexOp(FlaskTemplateParser.IndexOpContext ctx);
	/**
	 * Visit a parse tree produced by the {@code index}
	 * labeled alternative in {@link FlaskTemplateParser#sliceItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIndex(FlaskTemplateParser.IndexContext ctx);
	/**
	 * Visit a parse tree produced by the {@code slice}
	 * labeled alternative in {@link FlaskTemplateParser#sliceItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSlice(FlaskTemplateParser.SliceContext ctx);
	/**
	 * Visit a parse tree produced by the {@code argList}
	 * labeled alternative in {@link FlaskTemplateParser#argumentList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArgList(FlaskTemplateParser.ArgListContext ctx);
	/**
	 * Visit a parse tree produced by the {@code keywordArgument}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaArgument}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitKeywordArgument(FlaskTemplateParser.KeywordArgumentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code positionalArgument}
	 * labeled alternative in {@link FlaskTemplateParser#jinjaArgument}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPositionalArgument(FlaskTemplateParser.PositionalArgumentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code exprList}
	 * labeled alternative in {@link FlaskTemplateParser#expressionList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExprList(FlaskTemplateParser.ExprListContext ctx);
	/**
	 * Visit a parse tree produced by the {@code dictPairListNode}
	 * labeled alternative in {@link FlaskTemplateParser#dictPairList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDictPairListNode(FlaskTemplateParser.DictPairListNodeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code dictPairNode}
	 * labeled alternative in {@link FlaskTemplateParser#dictPair}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDictPairNode(FlaskTemplateParser.DictPairNodeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code styleWithAttributes}
	 * labeled alternative in {@link FlaskTemplateParser#cssStyle}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStyleWithAttributes(FlaskTemplateParser.StyleWithAttributesContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#cssTagAttributes}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCssTagAttributes(FlaskTemplateParser.CssTagAttributesContext ctx);
	/**
	 * Visit a parse tree produced by the {@code cssTagAttrNode}
	 * labeled alternative in {@link FlaskTemplateParser#cssTagAttribute}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCssTagAttrNode(FlaskTemplateParser.CssTagAttrNodeContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskTemplateParser#cssStyleContent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCssStyleContent(FlaskTemplateParser.CssStyleContentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code cssRuleNode}
	 * labeled alternative in {@link FlaskTemplateParser#cssRule}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCssRuleNode(FlaskTemplateParser.CssRuleNodeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code cssSelectorExpr}
	 * labeled alternative in {@link FlaskTemplateParser#cssSelectors}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCssSelectorExpr(FlaskTemplateParser.CssSelectorExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code cssSelectorNode}
	 * labeled alternative in {@link FlaskTemplateParser#cssSelector}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCssSelectorNode(FlaskTemplateParser.CssSelectorNodeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code cssDeclarationList}
	 * labeled alternative in {@link FlaskTemplateParser#cssDeclarations}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCssDeclarationList(FlaskTemplateParser.CssDeclarationListContext ctx);
	/**
	 * Visit a parse tree produced by the {@code cssDeclarationNode}
	 * labeled alternative in {@link FlaskTemplateParser#cssDeclaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCssDeclarationNode(FlaskTemplateParser.CssDeclarationNodeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code cssValueList}
	 * labeled alternative in {@link FlaskTemplateParser#cssValues}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCssValueList(FlaskTemplateParser.CssValueListContext ctx);
	/**
	 * Visit a parse tree produced by the {@code cssStringValue}
	 * labeled alternative in {@link FlaskTemplateParser#cssValue}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCssStringValue(FlaskTemplateParser.CssStringValueContext ctx);
	/**
	 * Visit a parse tree produced by the {@code cssNumericValue}
	 * labeled alternative in {@link FlaskTemplateParser#cssValue}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCssNumericValue(FlaskTemplateParser.CssNumericValueContext ctx);
	/**
	 * Visit a parse tree produced by the {@code cssColorValue}
	 * labeled alternative in {@link FlaskTemplateParser#cssValue}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCssColorValue(FlaskTemplateParser.CssColorValueContext ctx);
	/**
	 * Visit a parse tree produced by the {@code cssKeywordValue}
	 * labeled alternative in {@link FlaskTemplateParser#cssValue}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCssKeywordValue(FlaskTemplateParser.CssKeywordValueContext ctx);
}