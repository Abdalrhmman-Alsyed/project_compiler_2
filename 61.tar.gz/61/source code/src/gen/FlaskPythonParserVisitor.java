// Generated from FlaskPythonParser.g4 by ANTLR 4.13.2
package gen;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link FlaskPythonParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface FlaskPythonParserVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by the {@code programRoot}
	 * labeled alternative in {@link FlaskPythonParser#program}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProgramRoot(FlaskPythonParser.ProgramRootContext ctx);
	/**
	 * Visit a parse tree produced by the {@code importItem}
	 * labeled alternative in {@link FlaskPythonParser#programItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitImportItem(FlaskPythonParser.ImportItemContext ctx);
	/**
	 * Visit a parse tree produced by the {@code declarationItem}
	 * labeled alternative in {@link FlaskPythonParser#programItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDeclarationItem(FlaskPythonParser.DeclarationItemContext ctx);
	/**
	 * Visit a parse tree produced by the {@code functionItem}
	 * labeled alternative in {@link FlaskPythonParser#programItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctionItem(FlaskPythonParser.FunctionItemContext ctx);
	/**
	 * Visit a parse tree produced by the {@code statementItem}
	 * labeled alternative in {@link FlaskPythonParser#programItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStatementItem(FlaskPythonParser.StatementItemContext ctx);
	/**
	 * Visit a parse tree produced by the {@code newlineItem}
	 * labeled alternative in {@link FlaskPythonParser#programItem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNewlineItem(FlaskPythonParser.NewlineItemContext ctx);
	/**
	 * Visit a parse tree produced by the {@code importModule}
	 * labeled alternative in {@link FlaskPythonParser#importStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitImportModule(FlaskPythonParser.ImportModuleContext ctx);
	/**
	 * Visit a parse tree produced by the {@code fromImport}
	 * labeled alternative in {@link FlaskPythonParser#importStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFromImport(FlaskPythonParser.FromImportContext ctx);
	/**
	 * Visit a parse tree produced by the {@code declarationStmt}
	 * labeled alternative in {@link FlaskPythonParser#declaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDeclarationStmt(FlaskPythonParser.DeclarationStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code functionDecleration}
	 * labeled alternative in {@link FlaskPythonParser#functionDecl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctionDecleration(FlaskPythonParser.FunctionDeclerationContext ctx);
	/**
	 * Visit a parse tree produced by the {@code decoratorRule}
	 * labeled alternative in {@link FlaskPythonParser#decorator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDecoratorRule(FlaskPythonParser.DecoratorRuleContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#paramList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParamList(FlaskPythonParser.ParamListContext ctx);
	/**
	 * Visit a parse tree produced by the {@code varargParam}
	 * labeled alternative in {@link FlaskPythonParser#parameter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVarargParam(FlaskPythonParser.VarargParamContext ctx);
	/**
	 * Visit a parse tree produced by the {@code kwargParam}
	 * labeled alternative in {@link FlaskPythonParser#parameter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitKwargParam(FlaskPythonParser.KwargParamContext ctx);
	/**
	 * Visit a parse tree produced by the {@code normalParam}
	 * labeled alternative in {@link FlaskPythonParser#parameter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNormalParam(FlaskPythonParser.NormalParamContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#dottedName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDottedName(FlaskPythonParser.DottedNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#argumentList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArgumentList(FlaskPythonParser.ArgumentListContext ctx);
	/**
	 * Visit a parse tree produced by the {@code keywordArgument}
	 * labeled alternative in {@link FlaskPythonParser#argument}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitKeywordArgument(FlaskPythonParser.KeywordArgumentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code positionalArgument}
	 * labeled alternative in {@link FlaskPythonParser#argument}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPositionalArgument(FlaskPythonParser.PositionalArgumentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code assignmentStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignmentStmt(FlaskPythonParser.AssignmentStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code exprStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExprStmt(FlaskPythonParser.ExprStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ifStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfStmt(FlaskPythonParser.IfStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code forStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitForStmt(FlaskPythonParser.ForStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code whileStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhileStmt(FlaskPythonParser.WhileStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code tryStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTryStmt(FlaskPythonParser.TryStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code raiseStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRaiseStmt(FlaskPythonParser.RaiseStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code returnStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReturnStmt(FlaskPythonParser.ReturnStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code passStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPassStmt(FlaskPythonParser.PassStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code breakStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBreakStmt(FlaskPythonParser.BreakStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code continueStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitContinueStmt(FlaskPythonParser.ContinueStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code globalStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGlobalStmt(FlaskPythonParser.GlobalStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code withStmt}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWithStmt(FlaskPythonParser.WithStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code newLine}
	 * labeled alternative in {@link FlaskPythonParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNewLine(FlaskPythonParser.NewLineContext ctx);
	/**
	 * Visit a parse tree produced by the {@code assignmentRule}
	 * labeled alternative in {@link FlaskPythonParser#assignment}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignmentRule(FlaskPythonParser.AssignmentRuleContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#assignOp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignOp(FlaskPythonParser.AssignOpContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#leftHandSide}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLeftHandSide(FlaskPythonParser.LeftHandSideContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#exprStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExprStatement(FlaskPythonParser.ExprStatementContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ifStatementRule}
	 * labeled alternative in {@link FlaskPythonParser#ifStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfStatementRule(FlaskPythonParser.IfStatementRuleContext ctx);
	/**
	 * Visit a parse tree produced by the {@code forStatementRule}
	 * labeled alternative in {@link FlaskPythonParser#forStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitForStatementRule(FlaskPythonParser.ForStatementRuleContext ctx);
	/**
	 * Visit a parse tree produced by the {@code whileStatementRule}
	 * labeled alternative in {@link FlaskPythonParser#whileStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhileStatementRule(FlaskPythonParser.WhileStatementRuleContext ctx);
	/**
	 * Visit a parse tree produced by the {@code tryStatementRule}
	 * labeled alternative in {@link FlaskPythonParser#tryStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTryStatementRule(FlaskPythonParser.TryStatementRuleContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#exceptClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExceptClause(FlaskPythonParser.ExceptClauseContext ctx);
	/**
	 * Visit a parse tree produced by the {@code raiseStatementRule}
	 * labeled alternative in {@link FlaskPythonParser#raiseStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRaiseStatementRule(FlaskPythonParser.RaiseStatementRuleContext ctx);
	/**
	 * Visit a parse tree produced by the {@code withStatementRule}
	 * labeled alternative in {@link FlaskPythonParser#withStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWithStatementRule(FlaskPythonParser.WithStatementRuleContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#returnStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReturnStatement(FlaskPythonParser.ReturnStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#passStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPassStatement(FlaskPythonParser.PassStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#breakStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBreakStatement(FlaskPythonParser.BreakStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#continueStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitContinueStatement(FlaskPythonParser.ContinueStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#globalStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGlobalStatement(FlaskPythonParser.GlobalStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#suite}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSuite(FlaskPythonParser.SuiteContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#braceBlock}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBraceBlock(FlaskPythonParser.BraceBlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#indentBlock}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIndentBlock(FlaskPythonParser.IndentBlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#block}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlock(FlaskPythonParser.BlockContext ctx);
	/**
	 * Visit a parse tree produced by the {@code expressionRoot}
	 * labeled alternative in {@link FlaskPythonParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpressionRoot(FlaskPythonParser.ExpressionRootContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#logicalOrExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLogicalOrExpression(FlaskPythonParser.LogicalOrExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#logicalAndExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLogicalAndExpression(FlaskPythonParser.LogicalAndExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#equalityExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEqualityExpression(FlaskPythonParser.EqualityExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#comparisonExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComparisonExpression(FlaskPythonParser.ComparisonExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#additiveExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAdditiveExpression(FlaskPythonParser.AdditiveExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#multiplicativeExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMultiplicativeExpression(FlaskPythonParser.MultiplicativeExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unaryOp}
	 * labeled alternative in {@link FlaskPythonParser#unaryExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryOp(FlaskPythonParser.UnaryOpContext ctx);
	/**
	 * Visit a parse tree produced by the {@code simplePrimary}
	 * labeled alternative in {@link FlaskPythonParser#unaryExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSimplePrimary(FlaskPythonParser.SimplePrimaryContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#primaryExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrimaryExpression(FlaskPythonParser.PrimaryExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code indexExpr}
	 * labeled alternative in {@link FlaskPythonParser#postfix}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIndexExpr(FlaskPythonParser.IndexExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code attrExpr}
	 * labeled alternative in {@link FlaskPythonParser#postfix}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAttrExpr(FlaskPythonParser.AttrExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code callExpr}
	 * labeled alternative in {@link FlaskPythonParser#postfix}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCallExpr(FlaskPythonParser.CallExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#listLiteral}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitListLiteral(FlaskPythonParser.ListLiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#dictLiteral}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDictLiteral(FlaskPythonParser.DictLiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#dictEntry}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDictEntry(FlaskPythonParser.DictEntryContext ctx);
	/**
	 * Visit a parse tree produced by {@link FlaskPythonParser#setLiteral}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSetLiteral(FlaskPythonParser.SetLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code idAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdAtom(FlaskPythonParser.IdAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code stringAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringAtom(FlaskPythonParser.StringAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code intAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIntAtom(FlaskPythonParser.IntAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code floatAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFloatAtom(FlaskPythonParser.FloatAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code trueAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTrueAtom(FlaskPythonParser.TrueAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code falseAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFalseAtom(FlaskPythonParser.FalseAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code noneAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNoneAtom(FlaskPythonParser.NoneAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code listAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitListAtom(FlaskPythonParser.ListAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code dictAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDictAtom(FlaskPythonParser.DictAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code setAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSetAtom(FlaskPythonParser.SetAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code parenAtom}
	 * labeled alternative in {@link FlaskPythonParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParenAtom(FlaskPythonParser.ParenAtomContext ctx);
}