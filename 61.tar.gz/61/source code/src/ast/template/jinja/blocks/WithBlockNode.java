package ast.template.jinja.blocks;

import ast.template.NodeKind;
import ast.template.TemplateNode;
import ast.template.jinja.expressions.ExpressionNode;
import ast.visitors.TemplateASTVisitor;

import java.util.ArrayList;
import java.util.List;


public class WithBlockNode extends JinjaBlockNode {
    private String variable;          // null for a bare {% with expr %}
    private ExpressionNode expression;

    public WithBlockNode(int line, int column, ExpressionNode expression) {
        super(NodeKind.JINJA_WITH_BLOCK, line, column);
        this.expression = expression;
    }

    public String getVariable() { return variable; }
    public void setVariable(String variable) { this.variable = variable; }
    public boolean hasVariable() { return variable != null && !variable.isEmpty(); }

    public ExpressionNode getExpression() { return expression; }

    public void setExpression(ExpressionNode expression) { this.expression = expression; }


    @Override
    public <T> T accept(TemplateASTVisitor<T> visitor) {
        return visitor.visit(this);
    }

    @Override
    public List<TemplateNode> getChildren() {
        List<TemplateNode> kids = new ArrayList<>();
        if (expression != null) kids.add(expression);
        kids.addAll(getContent());
        return kids;
    }
}


